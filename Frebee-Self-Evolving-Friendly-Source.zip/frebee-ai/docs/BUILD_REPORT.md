# Build and test report

Date: 2026-11-25. Everything below was executed in this environment unless marked
otherwise.

## Android

| Check | Command | Result |
| --- | --- | --- |
| Debug APK build | `gradle assembleDebug` | PASS — `app/build/outputs/apk/debug/app-debug.apk` (19 MB) |
| Unit tests | `gradle :app:testDebugUnitTest` | PASS |
| APK metadata | `aapt2 dump badging` | package `com.frebee.ai`, versionCode 1, versionName 0.1.0, minSdk 26, targetSdk 35 |
| APK download | `GET /download/frebee-debug.apk` | PASS — 200, `application/vnd.android.package-archive`, 19,177,096 bytes, md5 `e2f59e5677fd59f50421e7576953251f` matches `dist/` |

Toolchain used: JDK 17.0.21, Gradle 8.9, Android SDK platform 35, build-tools 35.0.0,
AGP 8.7.3, Kotlin 2.0.21.

### CI fix

The "Build Frebee APK" workflow failed at "Set up Android SDK" on every run with:

```
TypeError: Input does not meet YAML 1.2 "Core Schema" specification: accept-android-sdk-licenses
```

`android-actions/setup-android@v4` parses that input as a boolean, and `"yes"` is not a
YAML 1.2 boolean. The workflow now passes unquoted `true` / `false`, pins Gradle 8.9 to
match the wrapper, runs unit tests before assembling, fails the job when no APK is
produced (`if-no-files-found: error`), and also runs on pull requests. A stray duplicate
workflow at `.github/.github/workflows/android.yml` was removed.

## Backend

| Check | Command | Result |
| --- | --- | --- |
| Import and OpenAPI generation | `python -c "import app.main"` | PASS — 56 documented paths |
| Test suite | `python -m pytest -q` | PASS — 62 tests |
| Live server | `uvicorn app.main:app --port 12000` | PASS — `/health`, `/`, `/api/docs` all 200 |
| Live chat stream | `POST /v1/chat/stream` with a registered account | PASS — `conversation`, `start`, `delta` events received |
| Local model generation | `FREBEE_LOCAL_MODEL_PATH=…/qwen2.5-3b-instruct-q4_k_m.gguf`, then `POST /v1/chat/stream` | PASS — `start` reports `provider: local_gguf`, streamed a coherent answer at ~12 tok/s on 4 CPU cores |
| Grounded research answer | `POST /v1/chat/stream` "What is the newest Python release and its version number?" | PASS — sources ranked python.org first; answer streamed as "Python 3.15 is the current stable release [2]" with three clickable citations in the dashboard |
| Memory capture and recall | Dashboard: "My name is Asha … I prefer short answers", then "What do you know about me?" | PASS — memory rows written, next reply reused them ("you're Asha building a Flutter app called TripKit") |
| Council mode | `POST /v1/chat/stream` with `mode: council` | PASS — draft streamed once, reviewer returned KEEP, status "Draft held", no duplicated output and no second full generation |
| Shared page cache | `sqlite3` read of the live database | PASS — 9 public pages cached from research, no user or query columns |
| Keyless web research | `research` mode question on HTTP caching | PASS — 5 sources fetched (Wikipedia, Stack Exchange, arXiv, Crossref) and passed to the model as numbered context |
| Keyless search merge logic | `tests/test_research_keyless.py` | PASS — dedupes across providers, drops non-http links, raises when every provider fails |
| Multi-turn continuity | `POST /v1/chat/stream` twice in one conversation: "write `slugify`", then "now add a max_length parameter to that same function" | PASS — turn 2 edits `slugify` and keeps the name; no re-explaining needed |
| Follow-up research gate | `tests/test_intelligence.py::test_should_research_skips_follow_up_instructions` | PASS — "do it again" / "now add a header" skip search; "what is the latest Flutter version?" still searches |
| Prompt window guard | `tests/test_intelligence.py::test_fit_context_keeps_the_prompt_inside_the_window` | PASS — oldest turns dropped, newest question kept, total under `n_ctx - max_tokens - 128` |
| Long conversation no longer crashes | 19-turn conversation in one thread | PASS — prompt trimmed with the model tokenizer, history capped with a recap; server stayed up (it previously aborted inside `llama_sampler_sample`) |
| Long conversation latency | same 19 turns, timed | 8-38 s per turn, no growth past the cap (was 20 → 81 s before the history cap) |
| Mode-based local routing | `POST /v1/chat/stream` in `balanced` and `coding` | PASS — balanced uses 1.5B, coding uses 3B from the same server |
| Attach menu | Dashboard, "+" button | PASS — Camera / Photos / Files menu opens, closes on Escape and outside click |
| Image understanding without a vision model | Uploaded a screenshot, asked "what text is visible?" | PASS — tesseract read the text, the answer used it and said OCR can misread characters |
| Local model picker | `GET /v1/models` | PASS — both GGUF files listed with size notes, default first |
| Reply latency (4 vCPU, 3B) | timed stream | ~10 s to first token, ~14 tok/s after that; 1.5B is roughly twice as fast |

### What the tests cover

- Registration, login, duplicate email, weak password, wrong password, guest sessions.
- Refresh-token rotation and rejection of reused tokens.
- Password reset request that does not reveal whether an account exists.
- Unauthenticated chat rejected; conversation, file, project, knowledge, memory and
  API-key isolation between two accounts.
- Chat in both JSON and SSE form, with messages persisted and a title generated.
- Upload, text extraction, deletion, owner-only access, oversize rejection.
- Memory create/update/delete.
- Project scaffold, file read/write, sandboxed command execution, ZIP archive.
- Path traversal rejected on read and write.
- Sandbox rejects disallowed commands and strips secret-looking environment variables.
- Knowledge indexing, hybrid search, per-user isolation.
- API keys: creation returns the secret once, listing is masked, the hash is stored,
  the key authenticates, revocation takes effect immediately, guests are refused.
- Evaluations pass (citation format, retrieval relevance, sandbox guards, injection
  wrapping) and are persisted.
- Admin endpoints reject non-admins.
- Coding agent completes a task with observable steps and changed files (mock provider).
- Prompt-injection attempt does not leak server configuration.
- Memory extraction: name, preference, project and workplace are read without bleeding
  into the next clause; ordinary chatter stores nothing.
- Research query building drops question scaffolding; title matches outrank body matches;
  sites whose host matches the subject (python.org for "python") are preferred.
- Research context labels each source with its URL and publication date.
- Council mode either rewrites with an explicit `reset` or reports the draft as held —
  never silently swaps the answer.

## Not verified here

- Live calls to OpenAI, Anthropic or Gemini: no keys were available. The adapters, model
  discovery and error handling are exercised through the provider protocol and the
  deterministic mock; live behaviour depends on your account.
- Web research against a real search API: no search key was configured.
- Speech transcription and synthesis: no OpenAI key was configured.
- Instrumented Android tests (`app/src/androidTest`): require a device or emulator, which
  this environment does not provide. The workflow runs JVM unit tests only.
- Release APK/AAB: needs your keystore; the recipe is in `docs/DEPLOYMENT.md`.
- The GitHub Actions run itself: the token available in this environment is read-only
  (`403 Resource not accessible by integration`), so the branch could not be pushed and
  no workflow run was triggered. The workflow file was parsed with a YAML loader (the
  licence inputs are booleans), and its inputs were checked against
  `android-actions/setup-android@v4/action.yml`. Push the branch to run it.

## Reproduce

```bash
# backend
cd backend && python -m pytest -q

# android (JDK 17, Android SDK 35)
./gradlew :app:testDebugUnitTest :app:assembleDebug
```
