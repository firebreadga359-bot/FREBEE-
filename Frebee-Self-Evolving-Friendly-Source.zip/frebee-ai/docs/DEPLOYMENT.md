# Deployment

Frebee is designed to run on a free tier first. Everything below assumes a single
backend instance; that is enough for personal or small-team use.

## What you need

| Component | Free-first choice | Notes |
| --- | --- | --- |
| Backend host | Render/Railway/Fly free tier, or a spare machine | 512 MB RAM is enough for chat; the sandbox needs more if you use the coding agent |
| Database | SQLite (default) | Switch to Postgres by changing `FREBEE_DATABASE_URL` |
| Storage | Local disk under `FREBEE_DATA_DIR` | Mount a persistent volume, or uploads vanish on redeploy |
| AI provider | Your own API key, or a local endpoint | Frebee ships no free inference |
| Web search | Tavily / Brave free tier, or self-hosted SearXNG | Optional; research returns 503 without one |
| Speech | OpenAI key | Optional |
| APK distribution | GitHub Actions artifact, or a self-hosted download | No Play Store requirement |

## 1. Backend

```bash
git clone <your fork> && cd frebee-android/backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -c "import secrets; print(secrets.token_urlsafe(48))"   # FREBEE_JWT_SECRET
python -c "import secrets; print(secrets.token_urlsafe(48))"   # FREBEE_ENCRYPTION_KEY
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Health check: `GET /health` returns `ok: true` plus whether providers and search are
configured. Point your platform's health probe at it.

### Platform notes

- **Render / Railway**: start command `uvicorn app.main:app --host 0.0.0.0 --port $PORT`,
  add a persistent disk at `/opt/render/project/src/backend/data` (Render) and set
  `FREBEE_DATA_DIR` to it. Free instances sleep; the first request is slow.
- **Fly.io**: keep one machine and a volume mounted at `/data`, set
  `FREBEE_DATA_DIR=/data`, `FREBEE_DATABASE_URL=sqlite:////data/frebee.db`.
- **Docker** (no Dockerfile is committed; this is the whole recipe):

```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY backend/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY backend/ .
ENV FREBEE_DATA_DIR=/data
EXPOSE 8000
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

## 2. Database

SQLite needs no work. For Postgres:

```
FREBEE_DATABASE_URL=postgresql+psycopg://user:pass@host:5432/frebee
```

Install `psycopg[binary]`, and note that tables are created on startup (no migrations
yet). Back up by dumping the database and copying `FREBEE_DATA_DIR` together — file
records reference paths on disk.

## 3. TLS

Terminate TLS at the proxy or platform router:

```nginx
server {
  listen 443 ssl;
  server_name frebee.example.com;
  client_max_body_size 30m;

  location / {
    proxy_pass http://127.0.0.1:8000;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_buffering off;          # required for smooth SSE streaming
    proxy_read_timeout 300s;
  }
}
```

Set `FREBEE_CORS_ORIGINS=https://frebee.example.com` once the dashboard has a real
origin, and `FREBEE_PUBLIC_BASE_URL` to the same value so emailed links work.

## 4. Android app

```bash
./gradlew :app:assembleDebug        # app/build/outputs/apk/debug/app-debug.apk
./gradlew :app:bundleRelease        # needs a signing config first
```

The debug APK is signed with the debug key and is fine for testing. A release build
needs your own keystore:

```bash
keytool -genkeypair -v -keystore frebee-release.jks -alias frebee \
  -keyalg RSA -keysize 2048 -validity 10000
```

Add to `app/build.gradle.kts` (and keep the file out of git):

```kotlin
signingConfigs {
    create("release") {
        storeFile = file(System.getenv("FREBEE_KEYSTORE") ?: "frebee-release.jks")
        storePassword = System.getenv("FREBEE_KEYSTORE_PASSWORD")
        keyAlias = System.getenv("FREBEE_KEY_ALIAS")
        keyPassword = System.getenv("FREBEE_KEY_PASSWORD")
    }
}
buildTypes { getByName("release") { signingConfig = signingConfigs.getByName("release") } }
```

Users set the backend URL on the sign-in screen or in Settings. Ship the APK with a URL
that matches your deployment so the default is not `10.0.2.2`.

## 5. CI

`.github/workflows/android.yml` runs on push, pull request and manual dispatch:

1. Java 17 (Temurin)
2. Android SDK with `platforms;android-35` and `build-tools;35.0.0`
3. Gradle 8.9
4. `:app:testDebugUnitTest`
5. `:app:assembleDebug`
6. Uploads `Frebee-debug-APK`

Download the APK from the run's Artifacts section.

Add a backend job if you want the API tested in CI too:

```yaml
  backend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: {python-version: "3.12"}
      - run: pip install -r backend/requirements.txt
      - run: python -m pytest -q
        working-directory: backend
```

## 6. Backups and recovery

- Nightly: `sqlite3 frebee.db ".backup '/backups/frebee-$(date +%F).db'"` plus
  `tar czf /backups/data-$(date +%F).tgz "$FREBEE_DATA_DIR"`.
- Restore: stop the service, restore both the database and the data directory (they must
  match), start the service, check `/health` and one conversation.
- Rotate `FREBEE_JWT_SECRET` to invalidate every session; rotate
  `FREBEE_ENCRYPTION_KEY` only with a migration that re-encrypts stored provider keys,
  otherwise existing credentials become unreadable.
