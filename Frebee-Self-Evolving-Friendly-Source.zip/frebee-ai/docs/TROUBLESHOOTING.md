# Troubleshooting

## Chat returns "No AI provider is configured"

The backend has no usable provider. Either:

- add a key in the app's Settings (stored encrypted per user), or
- set `FREBEE_OPENAI_API_KEY` / `FREBEE_ANTHROPIC_API_KEY` / `FREBEE_GEMINI_API_KEY`,
  or `FREBEE_LOCAL_BASE_URL` for a self-hosted OpenAI-compatible server, then restart.

`GET /health` shows `providers_configured`. `GET /v1/providers` shows what the server
and your account actually have.

## Provider test fails

- `401` — wrong or revoked key, or the key belongs to another project.
- `404` on a chat call — the model id is not available to your account. Discover valid
  ids with `GET /v1/models`.
- `429` — provider quota. Frebee reports the provider message instead of retrying
  forever; add credit or wait.
- Timeouts — check outbound network access from the host; corporate proxies usually
  need `HTTPS_PROXY` set for the service.

## Research says "No search provider is configured"

Set one of `FREBEE_TAVILY_API_KEY`, `FREBEE_BRAVE_API_KEY` or `FREBEE_SEARXNG_URL`.
SearXNG must be reachable from the backend and return JSON (`format=json` enabled).
A single failed page fetch does not fail the whole request; sources that could not be
read are simply absent.

## Voice buttons report 503

Speech uses the OpenAI audio API. Configure `FREBEE_OPENAI_API_KEY` (server) or add an
OpenAI credential for the account. `GET /v1/voice/status` reports what is available.
Realtime voice is not implemented; `realtime` is `false` by design.

## Uploads fail

- `400` — the file type is not supported or the content did not match its declared type.
- `413` — larger than `FREBEE_MAX_UPLOAD_BYTES`. Raise it on the server; reverse proxies
  also cap body size (`client_max_body_size`).
- `422` from `/v1/knowledge/file` — the document had no extractable text (scanned PDF
  without OCR, for example).

## Android build fails

Run the same steps CI runs:

```bash
export JAVA_HOME=/path/to/jdk17
./gradlew :app:testDebugUnitTest :app:assembleDebug --stacktrace
```

Common causes:

- `SDK location not found` — create `local.properties` with `sdk.dir=/path/to/android-sdk`
  or export `ANDROID_HOME`.
- `Unsupported class file major version` — you are on a JDK newer than 17 for the Gradle
  daemon; `java -version` must be 17.
- `compileSdk 35 not found` — install `platforms;android-35` with `sdkmanager`.
- Dependency resolution errors behind a proxy — Gradle needs `HTTPS_PROXY` too.

### The CI job failed at "Set up Android SDK"

The historical failure was `Input does not meet YAML 1.2 "Core Schema" specification:
accept-android-sdk-licenses` — the action expects a boolean, and `"yes"` is not one in
YAML 1.2. The workflow now passes `accept-android-sdk-licenses: true` (unquoted). If you
edit the workflow, keep those values unquoted booleans.

## Android app cannot reach the backend

- Emulator: use `http://10.0.2.2:8000`, not `localhost`.
- Physical device: use the machine's LAN IP and make sure the firewall allows port 8000.
- Android 9+ blocks cleartext HTTP by default for non-debug builds; use HTTPS, or keep
  the debug build for local testing.
- Check the "Server" field on the sign-in screen and in Settings; a trailing slash is
  trimmed, but a wrong scheme (`https` against an HTTP server) fails silently as a
  network error.

## Login works but every request is 401

The access token expired and the refresh failed. Sessions rotate: if two clients share
one refresh token, the second refresh is rejected. Sign in again, then use one client
per refresh token. If the backend was restarted with a new `FREBEE_JWT_SECRET`, every
existing session is invalid by design.

## 429 "Too many requests"

`FREBEE_RATE_LIMIT_PER_MINUTE` (default 120) or `FREBEE_AUTH_RATE_LIMIT_PER_MINUTE`
(default 20) was exceeded. Raise them, or place a proxy in front. The limiter is per
process; multiple instances each keep their own counters.

## Provider credentials disappeared after a restart

`FREBEE_ENCRYPTION_KEY` changed. Stored provider keys are encrypted with it and cannot
be decrypted with a different value. Keep the key stable, and re-add credentials if it
was lost.

## Coding agent stops with "protocol_error"

The model did not return the required JSON action. Small or heavily-tuned models often
fail this. Use a stronger model, or reduce the task to one clear instruction. The agent
reports exactly which reply it could not parse in the response's `errors` list.

## "command is not allowlisted"

Only a fixed set of build and inspection commands can run in a project sandbox. That is
intentional. If you need another tool, add it to `ALLOWED_COMMANDS` in
`backend/app/services/sandbox.py` after considering what it can do.

## Tests fail with 429 in CI

The test suite raises rate limits through environment variables in
`tests/conftest.py`. If you add tests that create many accounts, keep that override.

## Resetting a local install

```bash
rm -f backend/frebee.db && rm -rf backend/data
```

This deletes all local accounts, conversations, uploads and project workspaces.
