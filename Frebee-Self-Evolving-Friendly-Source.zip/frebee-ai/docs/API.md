# Frebee API

Base URL: `http://localhost:8000`. Interactive reference: `/api/docs` (OpenAPI at
`/api/openapi.json`). All responses are JSON unless stated otherwise.

## Authentication

Two credential types are accepted:

| Header | Credential | Notes |
| --- | --- | --- |
| `Authorization: Bearer <jwt>` | Session access token | 30 minute lifetime, refreshable |
| `X-Api-Key: fbk_live_…` | Frebee API key | Scoped, revocable, hashed at rest |

Session tokens come from `POST /v1/auth/register`, `/v1/auth/login`, `/v1/auth/guest`
and `POST /v1/auth/refresh`. API keys come from `POST /v1/api-keys` and are shown once.

Errors use the FastAPI shape: `{"detail": "human readable message"}` with a matching
status code (400 validation, 401 unauthenticated, 403 forbidden, 404 not found,
409 conflict, 413 too large, 422 unprocessable, 429 rate limited, 5xx server).

## Auth

| Method | Path | Purpose |
| --- | --- | --- |
| POST | `/v1/auth/register` | Create an account, returns a token pair |
| POST | `/v1/auth/login` | Password login |
| POST | `/v1/auth/guest` | Temporary guest session (no API keys, no memory) |
| POST | `/v1/auth/refresh` | Rotate a refresh token (old one is revoked) |
| POST | `/v1/auth/logout` | Revoke one refresh session |
| POST | `/v1/auth/verify-email` | Consume an email verification token |
| POST | `/v1/auth/resend-verification` | Send a new verification mail |
| POST | `/v1/auth/password-reset/request` | Always answers 202 (no account enumeration) |
| POST | `/v1/auth/password-reset/confirm` | Set a new password with a reset token |
| GET | `/v1/auth/me` | Current profile |
| PATCH | `/v1/auth/me` | Update display name, memory preference |
| DELETE | `/v1/auth/me` | Delete the account and its data |
| GET | `/v1/auth/export` | Full data export (conversations, memory, files index) |
| GET | `/v1/auth/sessions` | List active refresh sessions |
| DELETE | `/v1/auth/sessions/{id}` | Revoke one session |

```bash
curl -s -X POST localhost:8000/v1/auth/register \
  -H 'Content-Type: application/json' \
  -d '{"email":"me@example.com","password":"a long password"}'
# {"access_token":"…","refresh_token":"…","token_type":"bearer","expires_in":1800,"user":{…}}
```

## Chat

### `POST /v1/chat` — complete answer in one response

```json
{"message": "Explain HTTP caching", "conversation_id": null, "mode": "balanced",
 "model": null, "provider": null, "attachment_ids": [], "research": false}
```

Response: `{"conversation_id","text","citations","usage","provider","model","error"}`.

### `POST /v1/chat/stream` — server-sent events

Same body. The response is `text/event-stream`; each event is `data: {json}` followed
by a blank line.

| Event | Payload |
| --- | --- |
| `conversation` | `{"conversation_id": "…"}` (first event) |
| `start` | `{"provider","model","mode"}` |
| `status` | `{"message"}` progress notes (research, retrieval, fallback) |
| `sources` | `{"sources":[{"index","title","url"}]}` when research ran |
| `delta` | `{"text":"…"}` incremental answer text |
| `done` | `{"citations","usage","provider","model","fallback_used"}` |
| `error` | `{"message"}` recoverable error |
| `done_stream` | Terminator |

```bash
curl -N -X POST localhost:8000/v1/chat/stream \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"message":"Hello","mode":"quick"}'
```

Modes: `quick`, `balanced`, `deep`, `research`, `coding`, `autonomous`.

## Conversations

| Method | Path | Notes |
| --- | --- | --- |
| GET | `/v1/conversations?limit=&offset=&q=&archived=` | Paginated list, `q` searches titles and messages |
| POST | `/v1/conversations` | `{"title"}` |
| GET | `/v1/conversations/{id}` | Conversation plus messages and citations |
| PATCH | `/v1/conversations/{id}` | Rename, archive |
| DELETE | `/v1/conversations/{id}` | Delete with messages |
| DELETE | `/v1/conversations/{id}/messages/{message_id}` | Delete one message |

## Files

| Method | Path | Notes |
| --- | --- | --- |
| POST | `/v1/files` | `multipart/form-data`, field `file`, max `FREBEE_MAX_UPLOAD_BYTES` |
| GET | `/v1/files` | List your uploads |
| GET | `/v1/files/{id}/text` | Extracted text (PDF, DOCX, plain text, code) |
| GET | `/v1/files/{id}/download` | Original bytes |
| DELETE | `/v1/files/{id}` | Remove record and stored bytes |

MIME type is sniffed from content, not trusted from the extension.

## Memory

| Method | Path | Notes |
| --- | --- | --- |
| GET | `/v1/memory?q=` | List entries and the account's memory preference |
| PUT | `/v1/memory` | `{"scope":"user\|project\|conversation","key","value","scope_id"}` |
| DELETE | `/v1/memory/{id}` | Delete one entry |

## Knowledge and research

| Method | Path | Notes |
| --- | --- | --- |
| POST | `/v1/knowledge/url` | Fetch a public page and index its text |
| POST | `/v1/knowledge/text` | Index a note |
| POST | `/v1/knowledge/file` | Index an uploaded file's extracted text |
| GET | `/v1/knowledge` | List sources with chunk counts |
| POST | `/v1/knowledge/search` | Hybrid lexical + vector search |
| DELETE | `/v1/knowledge/{id}` | Delete source and chunks |
| POST | `/v1/research` | Run a web search and return ranked sources plus context |

`/v1/research` answers 503 when no search provider is configured.

## Projects and coding agent

| Method | Path | Notes |
| --- | --- | --- |
| GET/POST | `/v1/projects` | List / create (`{"name","kind","description"}`); create scaffolds files |
| GET/PATCH/DELETE | `/v1/projects/{id}` | Detail includes the file list |
| GET | `/v1/projects/{id}/file?path=` | Read a file inside the workspace |
| PUT | `/v1/projects/{id}/file` | Write `{"path","content"}` (max 400 KB) |
| POST | `/v1/projects/{id}/run` | Run one allowlisted command, returns `exit_code`, `stdout`, `stderr` |
| POST | `/v1/projects/{id}/agent` | Run the coding agent: `{"task","model","provider","max_steps"}` |
| GET | `/v1/projects/{id}/archive` | ZIP of the workspace |

The agent response reports every step (`tool`, `ok`, `summary`), changed files, executed
commands, errors and why it stopped. It never claims a build passed without an observed
`exit_code`.

## Providers, models, keys, usage

| Method | Path | Notes |
| --- | --- | --- |
| GET | `/v1/providers` | Configured providers (server and your own), masked keys |
| POST | `/v1/providers/credentials` | `{"kind","api_key","base_url","default_model"}`; stores an encrypted key and tests it |
| POST | `/v1/providers/credentials/{id}/test` | Re-test connectivity |
| PATCH | `/v1/providers/credentials/{id}` | Change model or make it the default |
| DELETE | `/v1/providers/credentials/{id}` | Remove the credential |
| GET | `/v1/models?provider=` | Discovered models with capabilities |
| GET/POST | `/v1/api-keys` | List (masked) / create a Frebee key (`secret` returned once) |
| DELETE | `/v1/api-keys/{id}` | Revoke |
| GET | `/v1/usage` | Token and request counters |

## Voice

| Method | Path | Notes |
| --- | --- | --- |
| GET | `/v1/voice/status` | Which speech features are available |
| POST | `/v1/voice/transcribe` | `multipart/form-data` audio upload |
| POST | `/v1/voice/speak` | `{"text","voice","speed"}` → `audio/mpeg` |

Both return 503 with a clear message when no OpenAI key is available.

## Evaluations and administration

| Method | Path | Notes |
| --- | --- | --- |
| POST | `/v1/evals/run` | Run the core checks, persist the result |
| GET | `/v1/evals` | Evaluation history |
| GET | `/v1/admin/health` | Counts, providers, search configuration (admin only) |
| GET | `/v1/admin/metrics` | Aggregate usage and recent errors (admin only) |
| GET | `/v1/admin/audit?limit=` | Audit log (admin only) |
| GET/PATCH | `/v1/admin/flags[/{key}]` | Feature flags (admin only) |
| GET | `/health` | Public liveness and configuration summary |
| GET | `/download/frebee-debug.apk` | Serves the debug APK committed under `dist/`; 404 when none is present |
