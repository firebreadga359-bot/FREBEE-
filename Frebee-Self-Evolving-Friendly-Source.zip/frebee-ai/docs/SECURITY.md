# Security and privacy

This document describes what Frebee actually does. It is written to be verifiable
against the code, not aspirational.

## Identity and sessions

- Passwords are hashed with scrypt (`N=2^14, r=8, p=1`, 16-byte random salt) and
  compared in constant time. Plaintext passwords are never stored or logged.
- Access tokens are HS256 JWTs signed with `FREBEE_JWT_SECRET`, valid for 30 minutes,
  and carry only the user id, role and expiry.
- Refresh tokens are opaque 256-bit random strings. Only their SHA-256 hash is stored.
  Every refresh revokes the old token (rotation); reuse of a rotated token returns 401.
- Sessions are listed per account and can be revoked individually or by logout.
- Guest sessions expire after `FREBEE_GUEST_TOKEN_DAYS` (default 7) and cannot create
  API keys or persistent memory.
- `role` is stored server-side and checked by `require_admin`. A client-supplied role
  field is never trusted.

## Authorisation

Every protected route depends on `get_principal`, which accepts either a session JWT or
a Frebee API key. Every object lookup filters by `user_id`; a foreign id returns 404
rather than 403 so existence is not disclosed. Tests cover conversation, file, project,
knowledge, memory and API-key isolation between two accounts.

API keys carry explicit scopes (`chat.read`, `chat.write`, `files.read`, `files.write`,
`projects.read`, `projects.write`). A key without the required scope gets 403.

## Secrets

- Provider API keys are encrypted with AES-256-GCM before they are written to the
  database. The key is derived from `FREBEE_ENCRYPTION_KEY`. Reads return only a masked
  value such as `sk-…f4a2`.
- Frebee API keys are stored as SHA-256 hashes; the plaintext is returned once at
  creation and cannot be retrieved later.
- The Android app never stores provider keys. It talks to the backend with the user's
  session token and keeps that token in `EncryptedSharedPreferences`.
- Logs redact `sk-…` and `fbk_live_…` patterns (`security.redact`).
- The sandbox strips environment variables whose names look like credentials before
  running any command.

## Input handling

- Request bodies are validated with Pydantic models (lengths, patterns, enumerations).
- Uploads are limited by `FREBEE_MAX_UPLOAD_BYTES` (25 MB default) and classified by
  sniffed content type, not by file extension.
- Project file paths are resolved and checked against the project root; `..` and
  absolute paths are rejected.
- Only allowlisted commands can run in the sandbox (`python`, `npm`, `gradle`, `git`,
  `ls`, `pytest`, …), with a timeout and an output cap. Shell metacharacter abuse is
  rejected, not escaped and executed.

## Prompt injection

Web pages, uploaded files, knowledge chunks and tool output are wrapped in
`<untrusted> … </untrusted>` blocks. The system prompt states that content inside those
blocks is data and must never be followed as instructions. An evaluation case asserts
that the identity/security rules survive a "SYSTEM OVERRIDE" attempt.

This reduces, but does not eliminate, the risk. Treat model output as untrusted too:
the coding agent can only touch one project directory and only run allowlisted commands.

## Rate limiting and abuse control

In-process sliding-window limits: `FREBEE_RATE_LIMIT_PER_MINUTE` for general routes and
`FREBEE_AUTH_RATE_LIMIT_PER_MINUTE` for authentication. Chat endpoints additionally cap
per-user requests per minute.

Limitation: the limiter is per process. For more than one instance, put a shared store
(Redis) or an edge proxy in front, or run a single instance.

## Data lifecycle

- `GET /v1/auth/export` returns the account's conversations, memory, knowledge sources
  and file metadata as JSON.
- `DELETE /v1/auth/me` deletes the account; conversations, messages, memory, files,
  knowledge chunks, credentials and keys cascade.
- Uploaded bytes are deleted when a file record is deleted.
- Conversations can be deleted individually; memory entries can be deleted individually.
- The default configuration keeps data until the user deletes it. Operators who need
  retention limits should schedule a cleanup job against their own database.

## Transport

The application speaks plain HTTP by default for local development. In any deployment
terminate TLS in front of it (reverse proxy, PaaS router) and set
`FREBEE_CORS_ORIGINS` to your dashboard origin instead of `*`. HSTS, CSP and cookie
hardening are the proxy's job; the app already sends `X-Content-Type-Options`,
`X-Frame-Options`, `Referrer-Policy` and `Cache-Control: no-store` on API responses.

## Not claimed

- No end-to-end encryption. The server can read conversations in order to send them to
  the model provider you configure.
- No WAF, DDoS protection, or secrets manager integration.
- No audit trail immutability; audit rows are ordinary database rows.
- No automatic retraining on user data. Conversations are never used for training.

## Reporting

Found a problem? Open a private security advisory on the repository instead of a public
issue, and include the request that reproduces it.
