from __future__ import annotations

import asyncio

import pytest

from app.services import research


def test_duckduckgo_redirect_is_unwrapped():
    href = "//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fpage&rut=abc"
    assert research._duckduckgo_target(href) == "https://example.com/page"


def test_duckduckgo_direct_link_is_kept():
    assert research._duckduckgo_target("https://example.com/x") == "https://example.com/x"


def test_duckduckgo_non_http_links_are_dropped():
    assert research._duckduckgo_target("/relative/path") == ""
    assert research._duckduckgo_target("javascript:alert(1)") == ""


def test_keyless_search_merges_and_dedupes(monkeypatch):
    async def fake_wikipedia(query, limit):
        return [
            {"title": "Shared", "url": "https://example.com/shared", "snippet": "a", "published": None},
            {"title": "Wiki only", "url": "https://example.com/wiki", "snippet": "b", "published": None},
        ], "wikipedia"

    async def fake_stackexchange(query, limit):
        return [
            {"title": "Shared", "url": "https://example.com/shared", "snippet": "dup", "published": None},
            {"title": "SO only", "url": "https://example.com/so", "snippet": "c", "published": None},
        ], "stackexchange"

    async def empty(query, limit):
        return [], "empty"

    monkeypatch.setattr(research, "_wikipedia", fake_wikipedia)
    monkeypatch.setattr(research, "_stackexchange", fake_stackexchange)
    monkeypatch.setattr(research, "_duckduckgo", empty)
    monkeypatch.setattr(research, "_arxiv", empty)
    monkeypatch.setattr(research, "_crossref", empty)

    results, provider = asyncio.run(research._keyless("how do caches work", limit=4))

    urls = [item["url"] for item in results]
    # Round-robin across providers, duplicates dropped.
    assert urls == ["https://example.com/shared", "https://example.com/wiki", "https://example.com/so"]
    assert "wikipedia" in provider and "stackexchange" in provider


def test_keyless_search_reports_when_everything_fails(monkeypatch):
    async def boom(query, limit):
        raise research.SearchUnavailable("blocked")

    for name in ("_wikipedia", "_stackexchange", "_duckduckgo", "_arxiv", "_crossref"):
        monkeypatch.setattr(research, name, boom)

    with pytest.raises(research.SearchUnavailable):
        asyncio.run(research._keyless("anything", limit=3))
