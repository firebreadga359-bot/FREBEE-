from __future__ import annotations

import json

from fastapi.testclient import TestClient


def test_health(client: TestClient) -> None:
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["ok"] is True
    assert body["providers_configured"] is True


def test_register_login_and_me(client: TestClient) -> None:
    email = "alice@example.com"
    created = client.post("/v1/auth/register", json={"email": email, "password": "a strong password"})
    assert created.status_code == 201
    assert created.json()["user"]["email"] == email

    login = client.post("/v1/auth/login", json={"email": email, "password": "a strong password"})
    assert login.status_code == 200
    token = login.json()["access_token"]

    me = client.get("/v1/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me.status_code == 200
    assert me.json()["email"] == email
    assert me.json()["role"] == "user"


def test_duplicate_email_rejected(client: TestClient) -> None:
    payload = {"email": "dupe@example.com", "password": "a strong password"}
    assert client.post("/v1/auth/register", json=payload).status_code == 201
    assert client.post("/v1/auth/register", json=payload).status_code == 409


def test_weak_password_rejected(client: TestClient) -> None:
    response = client.post("/v1/auth/register", json={"email": "weak@example.com", "password": "short"})
    assert response.status_code in {400, 422}


def test_wrong_password_rejected(client: TestClient) -> None:
    client.post("/v1/auth/register", json={"email": "bob@example.com", "password": "a strong password"})
    response = client.post("/v1/auth/login", json={"email": "bob@example.com", "password": "nope nope nope"})
    assert response.status_code == 401


def test_unauthenticated_chat_rejected(client: TestClient) -> None:
    response = client.post("/v1/chat", json={"message": "hello"})
    assert response.status_code == 401


def test_refresh_rotates_and_rejects_reuse(client: TestClient) -> None:
    tokens = client.post(
        "/v1/auth/register", json={"email": "rotate@example.com", "password": "a strong password"}
    ).json()
    first = client.post("/v1/auth/refresh", json={"refresh_token": tokens["refresh_token"]})
    assert first.status_code == 200
    second = client.post("/v1/auth/refresh", json={"refresh_token": tokens["refresh_token"]})
    assert second.status_code == 401


def test_password_reset_request_does_not_leak_accounts(client: TestClient) -> None:
    known = client.post("/v1/auth/password-reset/request", json={"email": "rotate@example.com"})
    unknown = client.post("/v1/auth/password-reset/request", json={"email": "missing@example.com"})
    assert known.status_code == unknown.status_code == 202
    assert known.json() == unknown.json()


def test_conversation_isolation(client: TestClient, auth) -> None:
    owner = auth()
    stranger = auth()
    created = client.post("/v1/conversations", json={"title": "Private"}, headers=owner["headers"])
    assert created.status_code == 201
    conversation_id = created.json()["id"]

    assert client.get(f"/v1/conversations/{conversation_id}", headers=owner["headers"]).status_code == 200
    assert client.get(f"/v1/conversations/{conversation_id}", headers=stranger["headers"]).status_code == 404
    assert client.delete(f"/v1/conversations/{conversation_id}", headers=stranger["headers"]).status_code == 404


def test_chat_stream_persists_messages(client: TestClient, auth) -> None:
    user = auth()
    response = client.post(
        "/v1/chat", json={"message": "Explain build caching in two sentences."}, headers=user["headers"]
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["conversation_id"]
    assert body["text"].strip()
    assert body["error"] == ""

    detail = client.get(f"/v1/conversations/{body['conversation_id']}", headers=user["headers"]).json()
    roles = [message["role"] for message in detail["messages"]]
    assert roles == ["user", "assistant"]
    assert detail["title"]


def test_chat_sse_stream(client: TestClient, auth) -> None:
    user = auth()
    with client.stream(
        "POST", "/v1/chat/stream", json={"message": "Say hello.", "mode": "quick"}, headers=user["headers"]
    ) as response:
        assert response.status_code == 200
        events = []
        for line in response.iter_lines():
            if not line or not line.startswith("data:"):
                continue
            events.append(json.loads(line[5:].strip()))
    kinds = [event["type"] for event in events]
    assert "conversation" in kinds
    assert "delta" in kinds
    assert "done" in kinds
    assert kinds[-1] == "done_stream"
