import pytest

from app.services.evolution import (
    approve_upgrade,
    get_evolution_status,
    record_evaluation,
    record_major_evidence,
)


def test_major_upgrade_requires_repeated_high_confidence_evidence(tmp_path):
    path = tmp_path / "registry.json"
    first = record_major_evidence(path, topic="reasoning", summary="Finding A", source="source-a", confidence=.95, threshold=3)
    assert first["upgrade_ready_for_review"] is False
    duplicate = record_major_evidence(path, topic="reasoning", summary="Finding A again", source="source-a", confidence=.99, threshold=3)
    assert duplicate["evidence_count"] == 1
    record_major_evidence(path, topic="reasoning", summary="Finding B", source="source-b", confidence=.9, threshold=3)
    third = record_major_evidence(path, topic="reasoning", summary="Finding C", source="source-c", confidence=.9, threshold=3)
    assert third["upgrade_ready_for_review"] is True
    assert third["proposal"]["status"] == "proposed"


def test_model_upgrade_needs_passing_evaluation_and_explicit_approval(tmp_path):
    path = tmp_path / "registry.json"
    result = None
    for i in range(2):
        result = record_major_evidence(path, topic="vision", summary=f"Evidence {i}", source=f"s{i}", confidence=.9, threshold=2)
    proposal = result["proposal"]
    with pytest.raises(ValueError):
        approve_upgrade(path, proposal["id"], approved_by="owner")
    evaluated = record_evaluation(path, proposal["id"], passed=True, metrics={"accuracy": .92, "safety": .99})
    assert evaluated["status"] == "awaiting_approval"
    approved = approve_upgrade(path, proposal["id"], approved_by="owner")
    assert approved["status"] == "active"
    assert get_evolution_status(path)["current_version"] == proposal["candidate_version"]


def test_failed_evaluation_rejects_candidate(tmp_path):
    path = tmp_path / "registry.json"
    result = None
    for i in range(2):
        result = record_major_evidence(path, topic="coding", summary=f"Evidence {i}", source=f"s{i}", confidence=.9, threshold=2)
    proposal = result["proposal"]
    record_evaluation(path, proposal["id"], passed=False, metrics={"accuracy": .4})
    with pytest.raises(ValueError):
        approve_upgrade(path, proposal["id"], approved_by="owner")
