"""Tests for the parts that decide when to look outside the model and what it keeps."""

from __future__ import annotations

import json

from fastapi.testclient import TestClient

from app.db import SessionLocal
from app.services import orchestrator, research as research_service, retrieval
from app.services.orchestrator import memory_facts
from app.services.research import _host_matches_terms, _relevance, search_terms


def test_should_research_flags_questions_about_changing_facts() -> None:
    assert orchestrator.should_research("What is the latest Python release?", "balanced")
    assert orchestrator.should_research("How much does the Pixel 9 cost in 2025", "balanced")
    assert orchestrator.should_research("Who won the 2024 election", "deep")
    assert orchestrator.should_research("compare FastAPI vs Flask for this service", "coding")


def test_should_research_leaves_stable_knowledge_alone() -> None:
    assert not orchestrator.should_research("Explain how a hash table works", "balanced")
    assert not orchestrator.should_research("What is the difference between a list and a tuple?", "deep")
    assert not orchestrator.should_research("Write a function that reverses a string", "coding")


def test_looks_uncertain_reads_hedges() -> None:
    assert orchestrator.looks_uncertain("I'm not sure, my knowledge cutoff is 2024.")
    assert orchestrator.looks_uncertain("I cannot browse the internet, so I don't know.")
    assert not orchestrator.looks_uncertain("A tuple is immutable; a list is not.")


def test_explicit_facts_become_memory(client: TestClient, auth) -> None:
    user = auth()
    response = client.post(
        "/v1/chat",
        json={"message": "Hi! My name is Asha and I prefer tabs over spaces."},
        headers=user["headers"],
    )
    assert response.status_code == 200, response.text

    memories = client.get("/v1/memory", headers=user["headers"]).json()["items"]
    by_key = {item["key"]: item["value"] for item in memories}
    assert by_key.get("name") == "Asha"
    assert "tabs" in by_key.get("preference", "")


def test_memory_capture_respects_the_switch(client: TestClient, auth) -> None:
    user = auth()
    client.put("/v1/memory/settings", json={"enabled": False}, headers=user["headers"])
    client.post("/v1/chat", json={"message": "My name is Ravi."}, headers=user["headers"])
    memories = client.get("/v1/memory", headers=user["headers"]).json()["items"]
    assert not [item for item in memories if item["key"] == "name"]


def test_council_mode_streams_a_review(client: TestClient, auth) -> None:
    user = auth()
    with client.stream(
        "POST",
        "/v1/chat/stream",
        json={"message": "Explain indexing in two sentences.", "mode": "council"},
        headers=user["headers"],
    ) as response:
        events = [
            json.loads(line[5:].strip())
            for line in response.iter_lines()
            if line.startswith("data:")
        ]
    statuses = [event for event in events if event["type"] == "status"]
    assert any(event.get("stage") == "council" for event in statuses)
    revised = any(event["type"] == "reset" for event in events)
    held = any(event.get("message", "").startswith("Draft held") for event in statuses)
    # Either the review rewrites the draft (reset + restream) or it is held as-is; both
    # are valid, silently replacing the answer without a reset is not.
    assert revised or held
    assert any(event["type"] == "done" for event in events)


def test_shared_page_cache_is_searchable_and_holds_no_user_data() -> None:
    db = SessionLocal()
    try:
        url = "https://example.org/cache-test-page"
        text = (
            "SQLite write-ahead logging keeps readers from blocking the writer. "
            "The WAL file holds uncommitted pages until a checkpoint runs. " * 6
        )
        stored = retrieval.cache_web_pages(db, [(url, "SQLite WAL notes", text)])
        assert stored in {0, 1}
        hits = retrieval.search_web_cache(db, "how does sqlite write ahead logging checkpoint work")
        assert [hit.url for hit in hits] == [url]
        row = db.get(retrieval.WebPage, url)
        assert row is not None
        assert "user_id" not in row.__table__.columns
    finally:
        db.close()


def test_knowledge_source_is_not_duplicated_for_the_same_url() -> None:
    db = SessionLocal()
    try:
        from app.models import User

        user = User(
            id="dedupe-user", email="dedupe@example.com", password_hash="x", created_at=0, updated_at=0,
        )
        db.add(user)
        db.commit()
        url = "https://example.org/same-page"
        first = retrieval.index_source(db, user.id, "web", url, "Same page", "Content about caching. " * 40)
        second = retrieval.index_source(db, user.id, "web", url, "Same page", "Content about caching. " * 40)
        assert first.id == second.id
    finally:
        db.rollback()
        db.close()


def test_memory_facts_reads_self_description_without_bleed():
    facts = memory_facts(
        "Hi! My name is Asha. I'm building a Flutter app called TripKit and I prefer short answers."
    )
    assert dict(facts)["name"] == "Asha"
    assert dict(facts)["project"] == "a Flutter app called TripKit"
    assert dict(facts)["preference"] == "short answers"


def test_memory_facts_keeps_two_word_names():
    assert dict(memory_facts("my name is Asha Menon and I work at Acme")) == {
        "name": "Asha Menon",
        "workplace": "Acme",
    }


def test_memory_facts_ignores_chatter_without_facts():
    assert memory_facts("what is the weather like today?") == []


def test_search_terms_strips_question_scaffolding():
    assert search_terms("What is the newest Python release and its version number?") == [
        "python",
        "release",
        "version",
        "number",
    ]


def test_relevance_prefers_title_matches():
    terms = ["sqlite", "wal"]
    on_topic = {"title": "Write-Ahead Logging - SQLite", "snippet": ""}
    off_topic = {"title": "Database overview", "snippet": "covers sqlite, wal, rocksdb"}
    assert _relevance(on_topic, terms) > _relevance(off_topic, terms)


def test_host_match_rewards_official_documentation():
    assert _host_matches_terms("https://www.python.org/doc/versions/", ["python", "version"])
    assert not _host_matches_terms("https://en.wikipedia.org/wiki/Software_versioning", ["python"])


def test_context_labels_sources_and_dates():
    result = research_service.ResearchResult()
    result.sources.append(
        research_service.Source(
            index=1,
            title="Python documentation by version",
            url="https://www.python.org/doc/versions/",
            snippet="",
            published="2026-10-25",
            score=2.0,
            text="Python 3.15.2",
        )
    )
    context = research_service.build_context(result)
    assert "[1] Python documentation by version" in context
    assert "Published: 2026-10-25" in context
    assert "Python 3.15.2" in context


def test_should_research_skips_follow_up_instructions() -> None:
    assert not orchestrator.should_research("do it again", "balanced", has_history=True)
    assert not orchestrator.should_research("now add a header to it", "coding", has_history=True)
    assert not orchestrator.should_research("make it blue like before", "balanced", has_history=True)
    # Without history the same words are a fresh request and still get the normal treatment.
    assert not orchestrator.should_research("do it again", "balanced", has_history=False)
    # A real question in an existing conversation is still researched.
    assert orchestrator.should_research(
        "what is the latest Flutter version?", "balanced", has_history=True
    )


class _FakeModel:
    """Stands in for Llama: one token per word, so token maths is easy to check."""

    def tokenize(self, data: bytes, add_bos: bool = True) -> list[int]:
        return [0] * len(data.decode().split())


def test_fit_context_keeps_the_prompt_inside_the_window() -> None:
    from app.providers.local_gguf import _count_tokens, _fit_context

    payload = [{"role": "system", "content": " ".join(["rule"] * 200)}]
    payload += [{"role": "user", "content": f"question {index} " + "word " * 50} for index in range(20)]
    payload += [{"role": "assistant", "content": "answer " * 50}]
    payload += [{"role": "user", "content": "the newest question"}]

    fitted = _fit_context(payload, _FakeModel(), n_ctx=1024, max_tokens=256)

    assert _count_tokens(_FakeModel(), fitted) <= 1024 - 256 - 128
    assert fitted[-1]["content"] == "the newest question"
    assert fitted[0]["role"] == "system"
    # The oldest turns go first and the newest stay.
    assert len(fitted) < len(payload)


def test_local_provider_lists_and_resolves_models(tmp_path) -> None:
    from app.providers.local_gguf import LocalGgufProvider

    for name, size in (("small-q4.gguf", 4000), ("large-q4.gguf", 8000)):
        (tmp_path / name).write_bytes(b"x" * size)
    provider = LocalGgufProvider(str(tmp_path / "large-q4.gguf"))

    assert provider.resolve_model(None) == "large-q4"
    assert provider.resolve_model("small-q4") == "small-q4"
    assert provider.resolve_model("no-such-model") == "large-q4"


def test_image_text_is_extracted_with_ocr(tmp_path) -> None:
    import shutil

    from PIL import Image, ImageDraw, ImageFont

    from app.services.uploads import ocr_image

    if not shutil.which("tesseract"):
        return  # OCR is optional; nothing to assert without the binary.

    font = ImageFont.load_default(size=40)
    image = Image.new("RGB", (1200, 240), "white")
    ImageDraw.Draw(image).text((20, 40), "Traceback KeyError user_id", fill="black", font=font)
    ImageDraw.Draw(image).text((20, 130), "line 42 in chat.py", fill="black", font=font)
    path = tmp_path / "screenshot.png"
    image.save(path)

    text = ocr_image(path)

    assert "KeyError" in text
    assert "line 42" in text


def test_blank_image_yields_no_ocr_text(tmp_path) -> None:
    import shutil

    from PIL import Image

    from app.services.uploads import ocr_image

    if not shutil.which("tesseract"):
        return

    path = tmp_path / "blank.png"
    Image.new("RGB", (400, 200), "white").save(path)

    assert ocr_image(path) == ""


def test_heavy_modes_use_the_larger_local_model(tmp_path) -> None:
    from app.providers.local_gguf import LocalGgufProvider

    (tmp_path / "fast-1.5b.gguf").write_bytes(b"x" * 1000)
    (tmp_path / "slow-3b.gguf").write_bytes(b"x" * 3000)
    provider = LocalGgufProvider(str(tmp_path / "fast-1.5b.gguf"))

    assert provider.preferred_for_mode("balanced") == "fast-1.5b"
    assert provider.preferred_for_mode("coding") == "slow-3b"
    assert provider.preferred_for_mode("deep") == "slow-3b"
