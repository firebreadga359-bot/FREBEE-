from __future__ import annotations

import os
import tempfile
from pathlib import Path

import pytest

TMP = Path(tempfile.mkdtemp(prefix="frebee-test-"))

os.environ.update({
    "FREBEE_DATABASE_URL": f"sqlite:///{TMP / 'test.db'}",
    "FREBEE_DATA_DIR": str(TMP / "data"),
    "FREBEE_JWT_SECRET": "test-secret-key-that-is-long-enough-32b",
    "FREBEE_ENCRYPTION_KEY": "test-encryption-key",
    "FREBEE_ALLOW_MOCK_PROVIDER": "true",
    "FREBEE_REQUIRE_EMAIL_VERIFICATION": "false",
    "FREBEE_ALLOW_GUEST": "true",
    "FREBEE_ENVIRONMENT": "test",
    "FREBEE_AUTH_RATE_LIMIT_PER_MINUTE": "10000",
    "FREBEE_RATE_LIMIT_PER_MINUTE": "10000",
    # Keep the suite hermetic: no public web, no local model file, mock provider only.
    "FREBEE_ALLOW_KEYLESS_SEARCH": "false",
    "FREBEE_LOCAL_MODEL_PATH": "",
    "FREBEE_LOCAL_MODEL": "",
    "FREBEE_LOCAL_BASE_URL": "",
    "FREBEE_DEFAULT_PROVIDER": "",
})

from fastapi.testclient import TestClient  # noqa: E402

from app.db import init_db  # noqa: E402
from app.deps import limiter  # noqa: E402
from app.main import app  # noqa: E402


@pytest.fixture(scope="session", autouse=True)
def _database() -> None:
    init_db()


@pytest.fixture()
def client() -> TestClient:
    limiter.reset()
    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture()
def auth(client: TestClient):
    def _make(email: str | None = None) -> dict:
        address = email or f"user{os.urandom(4).hex()}@example.com"
        response = client.post("/v1/auth/register", json={"email": address, "password": "correct horse battery"})
        assert response.status_code == 201, response.text
        tokens = response.json()
        return {"headers": {"Authorization": f"Bearer {tokens['access_token']}"}, "email": address, "tokens": tokens}

    return _make
