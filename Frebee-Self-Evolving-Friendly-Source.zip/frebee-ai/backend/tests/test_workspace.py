from __future__ import annotations

import io

from fastapi.testclient import TestClient

from app.services import sandbox


def test_upload_read_and_delete(client: TestClient, auth) -> None:
    user = auth()
    upload = client.post(
        "/v1/files",
        files={"file": ("notes.txt", io.BytesIO(b"Frebee keeps attachments safe."), "text/plain")},
        headers=user["headers"],
    )
    assert upload.status_code == 201, upload.text
    record = upload.json()
    assert record["kind"] == "text"

    text = client.get(f"/v1/files/{record['id']}/text", headers=user["headers"])
    assert text.status_code == 200
    assert "attachments" in text.json()["text"]

    assert client.delete(f"/v1/files/{record['id']}", headers=user["headers"]).status_code == 204
    assert client.get(f"/v1/files/{record['id']}/text", headers=user["headers"]).status_code == 404


def test_upload_is_private_to_owner(client: TestClient, auth) -> None:
    owner = auth()
    stranger = auth()
    record = client.post(
        "/v1/files",
        files={"file": ("private.txt", io.BytesIO(b"secret"), "text/plain")},
        headers=owner["headers"],
    ).json()
    assert client.get(f"/v1/files/{record['id']}/text", headers=stranger["headers"]).status_code == 404


def test_memory_crud(client: TestClient, auth) -> None:
    user = auth()
    created = client.put(
        "/v1/memory",
        json={"scope": "user", "key": "editor", "value": "prefers Kotlin"},
        headers=user["headers"],
    )
    assert created.status_code == 200
    listed = client.get("/v1/memory", headers=user["headers"]).json()
    assert listed["items"][0]["value"] == "prefers Kotlin"

    updated = client.put(
        "/v1/memory",
        json={"scope": "user", "key": "editor", "value": "prefers Compose"},
        headers=user["headers"],
    ).json()
    assert updated["updated"] is True

    memory_id = listed["items"][0]["id"]
    assert client.delete(f"/v1/memory/{memory_id}", headers=user["headers"]).status_code == 204
    assert client.get("/v1/memory", headers=user["headers"]).json()["items"] == []


def test_project_scaffold_run_and_archive(client: TestClient, auth) -> None:
    user = auth()
    created = client.post(
        "/v1/projects", json={"name": "demo", "kind": "web", "description": "demo site"}, headers=user["headers"]
    )
    assert created.status_code == 201, created.text
    project = created.json()
    assert project["scaffolded"]

    detail = client.get(f"/v1/projects/{project['id']}", headers=user["headers"]).json()
    assert detail["files"]

    written = client.put(
        f"/v1/projects/{project['id']}/file",
        json={"path": "NOTES.md", "content": "# Demo\n"},
        headers=user["headers"],
    )
    assert written.status_code == 200

    read = client.get(
        f"/v1/projects/{project['id']}/file", params={"path": "NOTES.md"}, headers=user["headers"]
    )
    assert read.json()["content"] == "# Demo\n"

    run = client.post(
        f"/v1/projects/{project['id']}/run",
        json={"command": "python3 -c 'print(2 + 2)'"},
        headers=user["headers"],
    )
    assert run.status_code == 200, run.text
    assert run.json()["exit_code"] == 0
    assert "4" in run.json()["stdout"]

    archive = client.get(f"/v1/projects/{project['id']}/archive", headers=user["headers"])
    assert archive.status_code == 200
    assert archive.headers["content-type"] == "application/zip"
    assert archive.content[:2] == b"PK"


def test_project_path_traversal_blocked(client: TestClient, auth) -> None:
    user = auth()
    project = client.post("/v1/projects", json={"name": "guard"}, headers=user["headers"]).json()
    response = client.get(
        f"/v1/projects/{project['id']}/file", params={"path": "../../etc/passwd"}, headers=user["headers"]
    )
    assert response.status_code == 400
    write = client.put(
        f"/v1/projects/{project['id']}/file",
        json={"path": "../escape.txt", "content": "x"},
        headers=user["headers"],
    )
    assert write.status_code == 400


def test_project_isolation(client: TestClient, auth) -> None:
    owner = auth()
    stranger = auth()
    project = client.post("/v1/projects", json={"name": "mine"}, headers=owner["headers"]).json()
    assert client.get(f"/v1/projects/{project['id']}", headers=stranger["headers"]).status_code == 404
    assert client.post(
        f"/v1/projects/{project['id']}/run", json={"command": "echo hi"}, headers=stranger["headers"]
    ).status_code == 404


def test_sandbox_blocks_disallowed_commands(tmp_path) -> None:
    for command in ("rm -rf /", "curl http://example.com", "sudo ls", "bash -c 'id'"):
        try:
            sandbox.run(command, tmp_path)
        except sandbox.SandboxError:
            continue
        raise AssertionError(f"{command} should have been rejected")


def test_sandbox_strips_secret_environment(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("FREBEE_OPENAI_API_KEY", "sk-should-not-leak")
    result = sandbox.run("python3 -c 'import os; print(os.environ.get(\"FREBEE_OPENAI_API_KEY\", \"absent\"))'", tmp_path)
    assert result.exit_code == 0
    assert "sk-should-not-leak" not in result.stdout
