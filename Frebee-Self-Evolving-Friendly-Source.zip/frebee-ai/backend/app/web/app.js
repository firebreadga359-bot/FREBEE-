const store = {
  get access() { return localStorage.getItem("frebee.access") || ""; },
  get refresh() { return localStorage.getItem("frebee.refresh") || ""; },
  set(tokens) {
    localStorage.setItem("frebee.access", tokens.access_token);
    localStorage.setItem("frebee.refresh", tokens.refresh_token);
  },
  clear() {
    localStorage.removeItem("frebee.access");
    localStorage.removeItem("frebee.refresh");
  },
};

const state = {
  conversationId: null,
  conversationTitle: "",
  attachments: [],
  authMode: "login",
  controller: null,
  streaming: false,
};

const $ = (id) => document.getElementById(id);

/* ------------------------------------------------------------------ utils */

function status(text, isError = false) {
  const el = $("status");
  el.textContent = text || "";
  el.classList.toggle("error", Boolean(isError));
}

function nearBottom() {
  const box = $("scroll");
  return box.scrollHeight - box.scrollTop - box.clientHeight < 140;
}

function scrollToBottom(force = false) {
  const box = $("scroll");
  if (force || nearBottom()) box.scrollTop = box.scrollHeight;
}

function setChatTitle(title) {
  state.conversationTitle = title || "";
  $("chatTitle").textContent = title || "New chat";
  document.title = title ? `${title} — Frebee` : "Frebee";
}

/* --------------------------------------------------------------- messages */

function clearThread() {
  $("messages").innerHTML = "";
  $("messages").classList.remove("is-empty");
}

function showEmptyState() {
  clearThread();
  const wrap = document.createElement("div");
  wrap.className = "empty";
  wrap.innerHTML = `
    <div class="empty-logo">◆</div>
    <h1>What can I help with?</h1>
    <p>Ask anything, research a topic, or describe software you want built.</p>
    <div class="suggestions">
      <button class="suggestion" type="button" data-prompt="Explain how HTTP caching works, with a short example.">Explain how HTTP caching works</button>
      <button class="suggestion" type="button" data-prompt="Research the current state of on-device language models and cite your sources.">Research a topic with sources</button>
      <button class="suggestion" type="button" data-prompt="Build a small FastAPI service with a health check and a test.">Build a small API</button>
      <button class="suggestion" type="button" data-prompt="Review this Kotlin code for bugs and suggest a fix: ">Review my code</button>
    </div>`;
  wrap.querySelectorAll(".suggestion").forEach((button) => {
    button.onclick = () => {
      $("input").value = button.dataset.prompt;
      autoGrow();
      $("input").focus();
    };
  });
  $("messages").classList.add("is-empty");
  $("messages").appendChild(wrap);
}

function addUserMessage(text) {
  const node = document.createElement("div");
  node.className = "msg user";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  node.appendChild(bubble);
  $("messages").appendChild(node);
  scrollToBottom(true);
  return node;
}

function addAssistantMessage() {
  const node = document.createElement("div");
  node.className = "msg assistant";
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = "◆";
  const body = document.createElement("div");
  body.className = "body";
  node.append(avatar, body);
  $("messages").appendChild(node);
  scrollToBottom(true);
  return { node, body };
}

function addCitations(container, citations) {
  if (!citations || !citations.length) return;
  const wrap = document.createElement("div");
  wrap.className = "citations";
  for (const source of citations) {
    const link = document.createElement("a");
    link.href = FrebeeMarkdown.safeUrl(source.url) || "#";
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = `[${source.index}] ${source.title || source.url}`;
    wrap.appendChild(link);
  }
  container.appendChild(wrap);
}

function addMessageActions(node, text) {
  const actions = document.createElement("div");
  actions.className = "msg-actions";
  const copy = document.createElement("button");
  copy.type = "button";
  copy.textContent = "Copy";
  copy.onclick = () => FrebeeMarkdown.copyText(text, copy);
  actions.appendChild(copy);
  node.appendChild(actions);
}

function renderHistoryMessage(message) {
  if (message.role === "user") {
    addUserMessage(message.content);
    return;
  }
  const { node, body } = addAssistantMessage();
  FrebeeMarkdown.render(body, message.content || "");
  addCitations(body, message.citations || []);
  addMessageActions(node, message.content || "");
}

/* ---------------------------------------------------------- conversations */

function groupLabel(timestamp) {
  const value = Number(timestamp) || 0;
  if (!value) return "Earlier";
  const date = new Date(value < 1e12 ? value * 1000 : value);
  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);
  if (date >= startOfToday) return "Today";
  const days = Math.floor((startOfToday - date) / 86400000);
  if (days < 1) return "Yesterday";
  if (days < 7) return "Previous 7 days";
  if (days < 30) return "Previous 30 days";
  return "Earlier";
}

function renderConversations(items) {
  const container = $("conversations");
  container.innerHTML = "";
  if (!items.length) {
    const hint = document.createElement("p");
    hint.className = "muted";
    hint.style.padding = "10px 8px";
    hint.textContent = "No conversations yet.";
    container.appendChild(hint);
    return;
  }

  let currentGroup = "";
  for (const item of items) {
    const group = groupLabel(item.updated_at || item.created_at);
    if (group !== currentGroup) {
      currentGroup = group;
      const heading = document.createElement("div");
      heading.className = "conv-group";
      heading.textContent = group;
      container.appendChild(heading);
    }

    const row = document.createElement("div");
    row.className = "conv" + (item.id === state.conversationId ? " active" : "");
    row.tabIndex = 0;

    const title = document.createElement("span");
    title.className = "conv-title";
    title.textContent = item.title || "Untitled";
    title.title = item.title || "Untitled";

    const actions = document.createElement("span");
    actions.className = "conv-actions";

    const rename = document.createElement("button");
    rename.className = "mini";
    rename.type = "button";
    rename.title = "Rename";
    rename.textContent = "✎";
    rename.onclick = async (event) => {
      event.stopPropagation();
      const next = prompt("Rename conversation", item.title || "Untitled");
      if (!next || !next.trim()) return;
      try {
        await apiJson(`/v1/conversations/${item.id}`, {
          method: "PATCH",
          body: JSON.stringify({ title: next.trim() }),
        });
        if (item.id === state.conversationId) setChatTitle(next.trim());
        await loadConversations($("search").value.trim());
      } catch (error) {
        status(error.message, true);
      }
    };

    const remove = document.createElement("button");
    remove.className = "mini";
    remove.type = "button";
    remove.title = "Delete";
    remove.textContent = "🗑";
    remove.onclick = async (event) => {
      event.stopPropagation();
      if (!confirm(`Delete "${item.title || "Untitled"}"? This cannot be undone.`)) return;
      try {
        await api(`/v1/conversations/${item.id}`, { method: "DELETE" });
        if (item.id === state.conversationId) startNewChat();
        await loadConversations($("search").value.trim());
      } catch (error) {
        status(error.message, true);
      }
    };

    actions.append(rename, remove);
    row.append(title, actions);
    row.onclick = () => openConversation(item.id);
    row.onkeydown = (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        openConversation(item.id);
      }
    };
    container.appendChild(row);
  }
}

async function loadConversations(query = "") {
  const data = await apiJson(`/v1/conversations?limit=50${query ? `&q=${encodeURIComponent(query)}` : ""}`);
  renderConversations(data.items || []);
}

async function openConversation(id) {
  try {
    const data = await apiJson(`/v1/conversations/${id}`);
    state.conversationId = id;
    setChatTitle(data.title || "Untitled");
    clearThread();
    for (const message of data.messages || []) renderHistoryMessage(message);
    scrollToBottom(true);
    await loadConversations($("search").value.trim());
    closeDrawer();
  } catch (error) {
    status(error.message, true);
  }
}

function startNewChat() {
  state.conversationId = null;
  state.attachments = [];
  $("attachments").innerHTML = "";
  setChatTitle("");
  showEmptyState();
  status("");
  $("input").focus();
  closeDrawer();
}

/* ------------------------------------------------------------------- auth */

async function refreshTokens() {
  if (!store.refresh) return false;
  const response = await fetch("/v1/auth/refresh", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: store.refresh }),
  });
  if (!response.ok) return false;
  store.set(await response.json());
  return true;
}

async function api(path, options = {}, retry = true) {
  const headers = { ...(options.headers || {}) };
  if (store.access) headers.Authorization = `Bearer ${store.access}`;
  if (options.body && !(options.body instanceof FormData)) headers["Content-Type"] = "application/json";
  const response = await fetch(path, { ...options, headers });
  if (response.status === 401 && retry && (await refreshTokens())) return api(path, options, false);
  return response;
}

async function apiJson(path, options) {
  const response = await api(path, options);
  const text = await response.text();
  let payload = null;
  try { payload = text ? JSON.parse(text) : null; } catch { payload = { detail: text }; }
  if (!response.ok) throw new Error((payload && payload.detail) || `Request failed (${response.status})`);
  return payload;
}

function openAuth() {
  if (!$("authDialog").open) $("authDialog").showModal();
}

function setAuthMode(mode) {
  state.authMode = mode;
  $("authTitle").textContent = mode === "login" ? "Sign in to Frebee" : "Create your Frebee account";
  $("authSubmit").textContent = mode === "login" ? "Sign in" : "Create account";
  $("toggleAuth").textContent = mode === "login" ? "Create account" : "I already have an account";
}

$("toggleAuth").onclick = () => setAuthMode(state.authMode === "login" ? "register" : "login");

$("authForm").onsubmit = async (event) => {
  event.preventDefault();
  $("authError").textContent = "";
  const body = { email: $("email").value.trim(), password: $("password").value };
  try {
    const tokens = await apiJson(`/v1/auth/${state.authMode === "login" ? "login" : "register"}`, {
      method: "POST",
      body: JSON.stringify(body),
    });
    store.set(tokens);
    $("authDialog").close();
    await boot();
  } catch (error) {
    $("authError").textContent = error.message;
  }
};

$("guest").onclick = async () => {
  try {
    const tokens = await apiJson("/v1/auth/guest", { method: "POST" });
    store.set(tokens);
    $("authDialog").close();
    await boot();
    status("Guest session: conversations are temporary and memory is off.");
  } catch (error) {
    $("authError").textContent = error.message;
  }
};

$("logoutBtn").onclick = async () => {
  try {
    await api("/v1/auth/logout", { method: "POST", body: JSON.stringify({ refresh_token: store.refresh }) });
  } catch { /* ignore */ }
  store.clear();
  location.reload();
};

/* ------------------------------------------------------------------ theme */

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  localStorage.setItem("frebee.theme", theme);
  $("themeLabel").textContent = theme === "dark" ? "Dark" : "Light";
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", theme === "dark" ? "#0d0d0f" : "#ffffff");
}

$("theme").onclick = () => {
  applyTheme(document.documentElement.dataset.theme === "dark" ? "light" : "dark");
};

/* ----------------------------------------------------------------- drawer */

function openDrawer() { document.body.classList.add("drawer-open"); }
function closeDrawer() { document.body.classList.remove("drawer-open"); }

$("openSidebar").onclick = openDrawer;
$("closeSidebar").onclick = closeDrawer;
$("backdrop").onclick = closeDrawer;
$("brandHome").onclick = (event) => { event.preventDefault(); startNewChat(); };
$("newChat").onclick = startNewChat;

/* --------------------------------------------------------------- composer */

function autoGrow() {
  const input = $("input");
  input.style.height = "auto";
  input.style.height = `${Math.min(input.scrollHeight, 200)}px`;
}

$("input").addEventListener("input", autoGrow);

$("input").addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
    event.preventDefault();
    $("composer").requestSubmit();
  }
});

$("search").oninput = (event) => loadConversations(event.target.value.trim());

const attachButton = $("attachButton");
const attachMenu = $("attachMenu");
const attachInputs = { camera: $("cameraInput"), photos: $("photoInput"), files: $("fileInput") };

const closeAttachMenu = () => {
  attachMenu.hidden = true;
  attachButton.setAttribute("aria-expanded", "false");
};

attachButton.onclick = () => {
  const open = attachMenu.hidden;
  attachMenu.hidden = !open;
  attachButton.setAttribute("aria-expanded", String(open));
};

attachMenu.querySelectorAll("button[data-source]").forEach((item) => {
  item.onclick = () => {
    closeAttachMenu();
    attachInputs[item.dataset.source].click();
  };
});

document.addEventListener("click", (event) => {
  if (!attachMenu.hidden && !event.target.closest(".attach-wrap")) closeAttachMenu();
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !attachMenu.hidden) closeAttachMenu();
});

async function uploadFiles(fileList) {
  const files = Array.from(fileList || []);
  if (!files.length) return;
  for (const [index, file] of files.entries()) {
    const form = new FormData();
    form.append("file", file);
    status(files.length > 1 ? `Uploading ${index + 1}/${files.length}: ${file.name}…` : `Uploading ${file.name}…`);
    try {
      const record = await apiJson("/v1/files", { method: "POST", body: form });
      state.attachments.push(record);
      renderAttachments();
      status(`Attached ${record.name}`);
    } catch (error) {
      status(`${file.name}: ${error.message}`, true);
    }
  }
}

Object.values(attachInputs).forEach((input) => {
  input.onchange = async (event) => {
    await uploadFiles(event.target.files);
    event.target.value = "";
  };
});

function renderAttachments() {
  const wrap = $("attachments");
  wrap.innerHTML = "";
  state.attachments.forEach((record, index) => {
    const chip = document.createElement("span");
    chip.className = "chip";
    chip.append(document.createTextNode(record.name));
    const remove = document.createElement("button");
    remove.type = "button";
    remove.textContent = "✕";
    remove.title = "Remove";
    remove.onclick = () => {
      state.attachments.splice(index, 1);
      renderAttachments();
    };
    chip.appendChild(remove);
    wrap.appendChild(chip);
  });
}

$("stop").onclick = () => {
  if (state.controller) state.controller.abort();
  status("Stopped.");
};

$("composer").onsubmit = async (event) => {
  event.preventDefault();
  const text = $("input").value.trim();
  if (!text || state.streaming) return;

  $("input").value = "";
  autoGrow();
  if (document.querySelector("#messages .empty")) clearThread();

  addUserMessage(text);
  if (!state.conversationTitle) setChatTitle(text.length > 60 ? `${text.slice(0, 57)}…` : text);

  const { node, body } = addAssistantMessage();
  const caret = document.createElement("span");
  caret.className = "caret";
  body.appendChild(caret);

  let buffer = "";
  let lastRender = 0;
  let pendingRender = null;
  let finished = false;

  const paint = (force = false) => {
    const now = performance.now();
    if (!force && now - lastRender < 70) {
      if (!pendingRender) {
        pendingRender = setTimeout(() => { pendingRender = null; paint(true); }, 70);
      }
      return;
    }
    lastRender = now;
    const stick = nearBottom();
    // Rendering replaces the body's markup, so carry the source list across.
    const citations = body.querySelector(".citations");
    FrebeeMarkdown.render(body, buffer);
    if (citations) body.appendChild(citations);
    if (!finished) body.appendChild(caret);
    if (stick) scrollToBottom(true);
  };

  state.streaming = true;
  state.controller = new AbortController();
  $("stop").classList.remove("hidden");
  $("send").disabled = true;
  status("Thinking…");

  try {
    const response = await api("/v1/chat/stream", {
      method: "POST",
      body: JSON.stringify({
        message: text,
        conversation_id: state.conversationId,
        mode: $("mode").value,
        attachment_ids: state.attachments.map((item) => item.id),
      }),
      signal: state.controller.signal,
    });

    if (!response.ok) {
      const payload = await response.json().catch(() => ({}));
      throw new Error(payload.detail || `Request failed (${response.status})`);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let pending = "";

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      pending += decoder.decode(value, { stream: true });
      const parts = pending.split("\n\n");
      pending = parts.pop();
      for (const part of parts) {
        const line = part.trim();
        if (!line.startsWith("data:")) continue;
        const event = JSON.parse(line.slice(5).trim());
        if (event.type === "conversation") {
          state.conversationId = event.conversation_id;
        } else if (event.type === "delta") {
          buffer += event.text;
          paint();
        } else if (event.type === "status") {
          status(event.message || "");
        } else if (event.type === "reset") {
          // The backend is replacing the draft (after research, or a council review).
          buffer = "";
          body.innerHTML = "";
          body.appendChild(caret);
          status("");
        } else if (event.type === "sources") {
          body.querySelectorAll(".citations").forEach((item) => item.remove());
          addCitations(body, event.sources || []);
        } else if (event.type === "error") {
          status(event.message, true);
        } else if (event.type === "done") {
          if (event.citations && event.citations.length) addCitations(body, event.citations);
          if (event.usage) {
            status(`Tokens: ${event.usage.prompt_tokens || 0} in / ${event.usage.completion_tokens || 0} out`);
          } else {
            status("");
          }
        }
      }
    }

    finished = true;
    if (pendingRender) {
      clearTimeout(pendingRender);
      pendingRender = null;
    }
    paint(true);
    caret.remove();
    if (!buffer.trim()) FrebeeMarkdown.render(body, "_No answer was returned._");
    addMessageActions(node, buffer);
    if (state.attachments.length) {
      state.attachments = [];
      renderAttachments();
    }
    await loadConversations($("search").value.trim());
  } catch (error) {
    finished = true;
    caret.remove();
    if (error.name === "AbortError") {
      if (buffer) addMessageActions(node, buffer);
    } else {
      status(error.message, true);
      FrebeeMarkdown.render(body, `**Request failed.** ${error.message}`);
    }
  } finally {
    if (pendingRender) clearTimeout(pendingRender);
    state.streaming = false;
    state.controller = null;
    $("stop").classList.add("hidden");
    $("send").disabled = false;
  }
};

/* --------------------------------------------------------------- settings */

$("settingsBtn").onclick = async () => {
  closeDrawer();
  $("settingsDialog").showModal();
  try {
    const data = await apiJson("/v1/providers");
    $("providerStatus").textContent = data.items.length
      ? data.items.map((item) => `${item.kind} (${item.source}) — ${item.configured ? item.status : "not configured"}`).join("\n")
      : "No provider configured yet. Add a key below, or ask the operator for a server key.";
  } catch (error) {
    $("providerStatus").textContent = error.message;
  }
};

$("closeSettings").onclick = () => $("settingsDialog").close();

$("providerForm").onsubmit = async (event) => {
  event.preventDefault();
  $("providerMessage").textContent = "Testing connection…";
  try {
    const result = await apiJson("/v1/providers/credentials", {
      method: "POST",
      body: JSON.stringify({
        kind: $("providerKind").value,
        api_key: $("providerKey").value,
        base_url: $("providerBase").value,
        default_model: $("providerModel").value,
      }),
    });
    $("providerMessage").textContent = `${result.status}: ${result.message}`;
    $("providerKey").value = "";
  } catch (error) {
    $("providerMessage").textContent = error.message;
  }
};

$("createKey").onclick = async () => {
  try {
    const data = await apiJson("/v1/api-keys", {
      method: "POST",
      body: JSON.stringify({ label: "Web dashboard key", scopes: ["chat.read", "chat.write"] }),
    });
    $("keyOutput").textContent = `${data.secret}\n\n${data.warning || "Shown once. Store it now."}`;
  } catch (error) {
    $("keyOutput").textContent = error.message;
  }
};

$("runEvals").onclick = async () => {
  $("evalOutput").textContent = "Running…";
  try {
    const result = await apiJson("/v1/evals/run", { method: "POST" });
    $("evalOutput").textContent = `score ${result.score} (${result.passed}/${result.total})\n` +
      result.cases.map((item) => `${item.passed ? "PASS" : "FAIL"} ${item.name}: ${item.detail}`).join("\n");
  } catch (error) {
    $("evalOutput").textContent = error.message;
  }
};

/* ------------------------------------------------------------------- boot */

function prettyModelName(name) {
  if (!name) return "";
  const base = name.replace(/[-_]q\d+(_k(_m)?|_0)?$/i, "");
  return base
    .split(/[-_]/)
    .filter((part) => part && !/^(instruct|chat|it|gguf|v\d+)$/i.test(part))
    .join(" ")
    .replace(/\b(\d+(?:\.\d+)?)b\b/gi, (_, size) => `${size}B`)
    .replace(/\bqwen(\d)/i, "Qwen$1");
}

async function boot() {
  if (!store.access) {
    openAuth();
    setAuthMode("login");
    return;
  }
  try {
    const me = await apiJson("/v1/auth/me");
    $("logoutBtn").classList.remove("hidden");
    $("account").classList.remove("hidden");
    $("accountName").textContent = me.display_name || me.email || "Account";
    $("accountMeta").textContent = me.is_guest ? "guest session" : (me.email || "");
    $("accountAvatar").textContent = (me.display_name || me.email || "F").trim().charAt(0).toUpperCase();

    await loadConversations();
    const health = await fetch("/health").then((response) => response.json()).catch(() => null);
    if (health && !health.providers_configured) {
      status("No AI provider is configured yet. Open Settings to add your own key.");
    }
    if (health && health.local_model) {
      const badge = $("modelBadge");
      badge.textContent = `Local model: ${prettyModelName(health.local_model_name) || "on server"}`;
      badge.title =
        "Answers are generated by an open-weights model running on this server. No API key is used. " +
        "On a CPU-only host expect 10-40 seconds per answer; pick a smaller model in Settings for speed.";
      badge.hidden = false;
    }
    if (me.is_guest) status("Guest session: conversations are temporary and memory is off.");
    $("input").focus();
  } catch (error) {
    store.clear();
    openAuth();
    setAuthMode("login");
  }
}

applyTheme(localStorage.getItem("frebee.theme") || "dark");
showEmptyState();
boot();
