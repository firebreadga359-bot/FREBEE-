/* Minimal, safe markdown renderer for assistant replies.
   Everything is HTML-escaped before formatting tags are added, so model output
   cannot inject markup. Links are restricted to http, https and mailto. */
const FrebeeMarkdown = (() => {
  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function safeUrl(raw) {
    try {
      const url = new URL(raw, location.origin);
      return ["http:", "https:", "mailto:"].includes(url.protocol) ? url.href : null;
    } catch {
      return null;
    }
  }

  function inline(text) {
    let out = escapeHtml(text);
    out = out.replace(/`([^`\n]+)`/g, '<code class="inline">$1</code>');
    out = out.replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>");
    out = out.replace(/(^|[\s(])\*([^*\n]+)\*/g, "$1<em>$2</em>");
    out = out.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => {
      const safe = safeUrl(url);
      if (!safe) return label;
      return `<a href="${escapeHtml(safe)}" target="_blank" rel="noopener noreferrer">${label}</a>`;
    });
    return out.replace(/\n/g, "<br />");
  }

  function toHtml(text, codeStore) {
    const lines = String(text).replace(/\r\n/g, "\n").split("\n");
    let html = "";
    let paragraph = [];
    let index = 0;

    const flush = () => {
      if (paragraph.length) {
        html += `<p>${inline(paragraph.join("\n"))}</p>`;
        paragraph = [];
      }
    };

    while (index < lines.length) {
      const line = lines[index];
      const fence = line.match(/^```(\w+)?\s*$/);

      if (fence) {
        flush();
        const lang = fence[1] || "";
        const buffer = [];
        index += 1;
        while (index < lines.length && !/^```\s*$/.test(lines[index])) {
          buffer.push(lines[index]);
          index += 1;
        }
        index += 1;
        const code = buffer.join("\n");
        const slot = codeStore.push(code) - 1;
        html +=
          `<div class="code"><div class="code-head"><span>${escapeHtml(lang || "code")}</span>` +
          `<button class="copy" type="button" data-code="${slot}">Copy</button></div>` +
          `<pre><code>${escapeHtml(code)}</code></pre></div>`;
        continue;
      }

      const heading = line.match(/^(#{1,6})\s+(.*)$/);
      if (heading) {
        flush();
        const level = Math.min(heading[1].length, 3);
        html += `<h${level}>${inline(heading[2])}</h${level}>`;
        index += 1;
        continue;
      }

      if (/^\s*[-*+]\s+/.test(line)) {
        flush();
        const items = [];
        while (index < lines.length && /^\s*[-*+]\s+/.test(lines[index])) {
          items.push(lines[index].replace(/^\s*[-*+]\s+/, ""));
          index += 1;
        }
        html += `<ul>${items.map((item) => `<li>${inline(item)}</li>`).join("")}</ul>`;
        continue;
      }

      if (/^\s*\d+[.)]\s+/.test(line)) {
        flush();
        const items = [];
        while (index < lines.length && /^\s*\d+[.)]\s+/.test(lines[index])) {
          items.push(lines[index].replace(/^\s*\d+[.)]\s+/, ""));
          index += 1;
        }
        html += `<ol>${items.map((item) => `<li>${inline(item)}</li>`).join("")}</ol>`;
        continue;
      }

      if (/^>\s?/.test(line)) {
        flush();
        const quote = [];
        while (index < lines.length && /^>\s?/.test(lines[index])) {
          quote.push(lines[index].replace(/^>\s?/, ""));
          index += 1;
        }
        html += `<blockquote>${inline(quote.join(" "))}</blockquote>`;
        continue;
      }

      if (
        /^\s*\|.*\|\s*$/.test(line) &&
        index + 1 < lines.length &&
        /^\s*\|?[\s:|-]+\|?\s*$/.test(lines[index + 1]) &&
        lines[index + 1].includes("-")
      ) {
        flush();
        const cells = (row) =>
          row.trim().replace(/^\|/, "").replace(/\|$/, "").split("|").map((cell) => cell.trim());
        const header = cells(line);
        index += 2;
        const rows = [];
        while (index < lines.length && /^\s*\|.*\|\s*$/.test(lines[index])) {
          rows.push(cells(lines[index]));
          index += 1;
        }
        html +=
          `<table><thead><tr>${header.map((cell) => `<th>${inline(cell)}</th>`).join("")}</tr></thead>` +
          `<tbody>${rows
            .map((row) => `<tr>${row.map((cell) => `<td>${inline(cell)}</td>`).join("")}</tr>`)
            .join("")}</tbody></table>`;
        continue;
      }

      if (/^\s*(-{3,}|\*{3,})\s*$/.test(line)) {
        flush();
        html += "<hr />";
        index += 1;
        continue;
      }

      if (!line.trim()) {
        flush();
        index += 1;
        continue;
      }

      paragraph.push(line);
      index += 1;
    }

    flush();
    return html;
  }

  async function copyText(text, button) {
    const original = button.textContent;
    try {
      await navigator.clipboard.writeText(text);
      button.textContent = "Copied";
    } catch {
      button.textContent = "Copy failed";
    }
    setTimeout(() => { button.textContent = original; }, 1600);
  }

  function render(container, text) {
    const codeStore = [];
    container.innerHTML = toHtml(text, codeStore);
    container.querySelectorAll("button.copy").forEach((button) => {
      button.onclick = () => copyText(codeStore[Number(button.dataset.code)] || "", button);
    });
  }

  return { render, copyText, escapeHtml, safeUrl };
})();
