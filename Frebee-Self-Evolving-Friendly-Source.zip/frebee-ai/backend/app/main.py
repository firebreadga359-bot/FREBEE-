from __future__ import annotations

import logging
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .api import auth, chat, knowledge, settings_api, workspace
from .config import get_settings
from .db import init_db

settings = get_settings()
logging.basicConfig(
    level=logging.DEBUG if settings.debug else logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
logger = logging.getLogger("frebee")


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    logger.info("Frebee backend ready (env=%s)", settings.environment)
    yield


app = FastAPI(
    title="Frebee AI backend",
    version="0.1.0",
    description=(
        "Chat, research, files, memory, projects and a sandboxed coding agent. "
        "See docs/API.md for request and response formats."
    ),
    docs_url="/api/docs",
    openapi_url="/api/openapi.json",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-Api-Key", "X-Request-Id"],
)


@app.middleware("http")
async def harden(request: Request, call_next):
    request_id = request.headers.get("x-request-id") or uuid.uuid4().hex[:16]
    started = time.perf_counter()
    response = await call_next(request)
    response.headers["X-Request-Id"] = request_id
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["X-Frame-Options"] = "DENY"
    if request.url.path.startswith("/api"):
        response.headers["Cache-Control"] = "no-store"
    elapsed = (time.perf_counter() - started) * 1000
    if elapsed > 5000:
        logger.warning("slow request %s %s %.0fms", request.method, request.url.path, elapsed)
    return response


@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception) -> JSONResponse:
    logger.exception("unhandled error on %s", request.url.path)
    return JSONResponse(
        status_code=500,
        content={"detail": "Something went wrong on the server. The incident was logged."},
    )



for module in (auth, chat, workspace, knowledge, settings_api):
    app.include_router(module.router)


@app.get("/health", tags=["health"])
def health() -> dict:
    return {
        "ok": True,
        "service": "frebee-backend",
        "version": app.version,
        "environment": settings.environment,
        "providers_configured": bool(
            settings.openai_api_key
            or settings.anthropic_api_key
            or settings.gemini_api_key
            or settings.local_base_url
            or (settings.local_model_path and Path(settings.local_model_path).is_file())
            or settings.allow_mock_provider
        ),
        "search_configured": bool(
            settings.tavily_api_key
            or settings.brave_api_key
            or settings.searxng_url
            or settings.allow_keyless_search
        ),
        "local_model": bool(
            settings.local_model_path and Path(settings.local_model_path).is_file()
        ),
        "local_model_name": (
            settings.local_model or Path(settings.local_model_path).stem
            if settings.local_model_path
            else ""
        ),
    }


DIST_DIR = Path(__file__).resolve().parents[2] / "dist"


@app.get("/download/frebee-debug.apk", include_in_schema=False)
def download_apk() -> FileResponse:
    """Serves the debug APK committed under dist/ when one exists on this host."""
    candidates = [DIST_DIR / "frebee-0.1.0-debug.apk", *sorted(DIST_DIR.glob("*.apk"))]
    for path in candidates:
        if path.is_file():
            return FileResponse(
                path,
                media_type="application/vnd.android.package-archive",
                filename=path.name,
            )
    raise HTTPException(status_code=404, detail="No APK has been built on this server.")


@app.get("/download/frebee-source.zip", include_in_schema=False)
def download_source() -> FileResponse:
    """Serves the source archive built from the tracked files of this checkout."""
    path = DIST_DIR / "frebee-ai-source.zip"
    if not path.is_file():
        raise HTTPException(status_code=404, detail="No source archive has been built on this server.")
    return FileResponse(path, media_type="application/zip", filename=path.name)


WEB_DIR = Path(__file__).parent / "web"
if WEB_DIR.exists():
    app.mount("/app", StaticFiles(directory=WEB_DIR, html=True), name="web")

    @app.get("/", include_in_schema=False)
    def index() -> FileResponse:
        return FileResponse(WEB_DIR / "index.html")
