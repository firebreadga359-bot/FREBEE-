from __future__ import annotations

import uuid

from sqlalchemy.orm import Session

from .models import AuditEvent, now_ms
from .security import redact


def record(
    db: Session,
    action: str,
    *,
    user_id: str | None = None,
    target: str = "",
    detail: str = "",
    ip: str = "",
) -> None:
    """Writes a privileged-action record. Never include raw credentials."""
    db.add(
        AuditEvent(
            id=str(uuid.uuid4()),
            user_id=user_id,
            action=action,
            target=target[:200],
            detail=redact(detail)[:4000],
            ip=ip,
            created_at=now_ms(),
        )
    )
    db.commit()
