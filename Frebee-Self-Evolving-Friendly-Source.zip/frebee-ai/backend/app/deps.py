from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass, field

from fastapi import Depends, Header, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import get_settings
from .db import get_db
from .models import ApiKey, User, now_ms
from .security import decode_token, hash_api_key


@dataclass
class Principal:
    """Authenticated caller. `scopes` is empty for session (JWT) auth."""

    user: User
    auth_kind: str = "session"
    scopes: list[str] = field(default_factory=list)
    api_key_id: str | None = None

    def has_scope(self, scope: str) -> bool:
        if self.auth_kind == "session":
            return True
        return scope in self.scopes or "*" in self.scopes


def client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def _bearer_token(authorization: str | None) -> str | None:
    if not authorization:
        return None
    parts = authorization.split(None, 1)
    if len(parts) != 2 or parts[0].lower() != "bearer":
        return None
    return parts[1].strip()


def _user_from_api_key(db: Session, plaintext: str) -> Principal | None:
    record = db.scalar(select(ApiKey).where(ApiKey.key_hash == hash_api_key(plaintext)))
    if record is None or record.revoked_at is not None:
        return None
    user = db.get(User, record.user_id)
    if user is None or user.disabled:
        return None
    record.last_used_at = now_ms()
    record.request_count = (record.request_count or 0) + 1
    db.commit()
    scopes = [s.strip() for s in (record.scopes or "").split(",") if s.strip()]
    return Principal(user=user, auth_kind="api_key", scopes=scopes, api_key_id=record.id)


def get_principal(
    request: Request,
    db: Session = Depends(get_db),
    authorization: str | None = Header(default=None),
    x_api_key: str | None = Header(default=None),
) -> Principal:
    token = x_api_key or _bearer_token(authorization)
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if token.startswith("fbk_live_"):
        principal = _user_from_api_key(db, token)
        if principal is None:
            raise HTTPException(status_code=401, detail="Invalid or revoked API key.")
        return principal

    payload = decode_token(token, expected_kind="access")
    if payload is None:
        raise HTTPException(
            status_code=401,
            detail="Session expired or invalid. Sign in again.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    user = db.get(User, payload.get("sub"))
    if user is None or user.disabled:
        raise HTTPException(status_code=401, detail="Account not available.")
    if get_settings().require_email_verification and not user.email_verified and not user.is_guest:
        raise HTTPException(status_code=403, detail="Verify your email address to continue.")
    return Principal(user=user)


def get_current_user(principal: Principal = Depends(get_principal)) -> User:
    return principal.user


def require_admin(principal: Principal = Depends(get_principal)) -> User:
    if principal.user.role != "admin":
        raise HTTPException(status_code=403, detail="Administrator access required.")
    return principal.user


def require_scope(scope: str):
    def dependency(principal: Principal = Depends(get_principal)) -> Principal:
        if not principal.has_scope(scope):
            raise HTTPException(status_code=403, detail=f"API key is missing the '{scope}' scope.")
        return principal

    return dependency


class RateLimiter:
    """In-process sliding-window limiter.

    Good enough for a single instance and for tests. For multi-instance
    deployments point FREBEE_RATE_LIMIT_BACKEND at a shared store (documented in
    docs/SECURITY.md); the interface stays the same.
    """

    def __init__(self) -> None:
        self._hits: dict[str, deque[float]] = {}
        self._lock = threading.Lock()

    def allow(self, key: str, limit: int, window_seconds: int = 60) -> bool:
        now = time.time()
        with self._lock:
            bucket = self._hits.setdefault(key, deque())
            while bucket and now - bucket[0] > window_seconds:
                bucket.popleft()
            if len(bucket) >= limit:
                return False
            bucket.append(now)
            return True

    def reset(self) -> None:
        with self._lock:
            self._hits.clear()


limiter = RateLimiter()


def rate_limit(bucket: str, limit: int | None = None):
    settings = get_settings()

    def dependency(request: Request, principal: Principal | None = None) -> None:
        subject = principal.user.id if principal else client_ip(request)
        cap = limit if limit is not None else settings.rate_limit_per_minute
        if not limiter.allow(f"{bucket}:{subject}", cap):
            raise HTTPException(
                status_code=429,
                detail="Too many requests. Please slow down and try again shortly.",
            )

    return dependency
