from __future__ import annotations

import logging
import smtplib
from email.message import EmailMessage

from .config import get_settings

logger = logging.getLogger("frebee.mail")


def send_email(to: str, subject: str, body: str) -> bool:
    """Sends via SMTP when configured; otherwise logs the message locally.

    Returning False means "delivered to the log only", which keeps local and
    free-tier deployments usable without an email vendor.
    """
    settings = get_settings()
    if not settings.smtp_host:
        logger.info("MAIL (log only) to=%s subject=%s\n%s", to, subject, body)
        return False

    message = EmailMessage()
    message["From"] = settings.smtp_from
    message["To"] = to
    message["Subject"] = subject
    message.set_content(body)
    with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=20) as smtp:
        smtp.starttls()
        if settings.smtp_user:
            smtp.login(settings.smtp_user, settings.smtp_password)
        smtp.send_message(message)
    return True


def verification_link(token: str) -> str:
    return f"{get_settings().public_base_url}/verify?token={token}"


def reset_link(token: str) -> str:
    return f"{get_settings().public_base_url}/reset?token={token}"
