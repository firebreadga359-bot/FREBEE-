from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    """Runtime configuration.

    Every value has a safe local default except the two secrets. Set
    FREBEE_JWT_SECRET and FREBEE_ENCRYPTION_KEY in any shared deployment.
    """

    model_config = SettingsConfigDict(env_prefix="FREBEE_", env_file=".env", extra="ignore")

    app_name: str = "Frebee AI"
    environment: str = "development"
    debug: bool = False

    database_url: str = f"sqlite:///{BASE_DIR / 'frebee.db'}"
    data_dir: str = str(BASE_DIR / "data")

    jwt_secret: str = "dev-only-change-me-please-32-bytes-minimum"
    jwt_issuer: str = "frebee"
    access_token_minutes: int = 30
    refresh_token_days: int = 30
    guest_token_days: int = 7

    encryption_key: str = "dev-only-encryption-key-change-me"

    cors_origins: str = "*"
    public_base_url: str = "http://localhost:8000"

    admin_email: str = ""
    allow_registration: bool = True
    allow_guest: bool = True
    require_email_verification: bool = False

    rate_limit_per_minute: int = 120
    auth_rate_limit_per_minute: int = 20
    max_upload_bytes: int = 25 * 1024 * 1024
    max_conversation_messages: int = 400

    # Provider defaults (optional). Users can also store their own encrypted keys.
    openai_api_key: str = ""
    openai_base_url: str = "https://api.openai.com/v1"
    openai_model: str = ""
    anthropic_api_key: str = ""
    anthropic_base_url: str = "https://api.anthropic.com"
    anthropic_model: str = ""
    gemini_api_key: str = ""
    gemini_base_url: str = "https://generativelanguage.googleapis.com"
    gemini_model: str = ""
    local_base_url: str = ""
    local_model: str = ""

    # Open-weights model loaded in this process (no key, no network).
    local_model_path: str = ""
    local_model_threads: int = 4
    local_model_context: int = 4096
    shared_web_cache: bool = True
    auto_research: bool = True

    default_provider: str = ""

    # Research providers
    tavily_api_key: str = ""
    searxng_url: str = ""
    brave_api_key: str = ""
    research_max_sources: int = 5
    research_timeout_seconds: int = 20

    # Speech
    openai_transcribe_model: str = "whisper-1"
    openai_tts_model: str = "tts-1"
    openai_tts_voice: str = "alloy"
    openai_realtime_model: str = ""

    # Development helpers: a deterministic provider used by the test suite only.
    allow_mock_provider: bool = False

    # Key-free web search (DuckDuckGo HTML + Wikipedia). Free, but rate limited.
    allow_keyless_search: bool = True

    # Sandbox limits for the coding agent
    sandbox_timeout_seconds: int = 120
    sandbox_memory_mb: int = 1024
    sandbox_max_output_bytes: int = 200_000

    # Mail
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = "no-reply@frebee.local"

    @property
    def data_path(self) -> Path:
        path = Path(self.data_dir)
        path.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def projects_path(self) -> Path:
        path = self.data_path / "projects"
        path.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def uploads_path(self) -> Path:
        path = self.data_path / "uploads"
        path.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def cors_origin_list(self) -> list[str]:
        if self.cors_origins.strip() == "*":
            return ["*"]
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
