"""Conservative self-improvement lifecycle for Frebee.

This module tracks major-upgrade proposals; it does not pretend that storing facts
trains neural-network weights. A real trainer can be connected later behind the
candidate/evaluation/approval boundary.
"""
from __future__ import annotations

import json
import os
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any

DEFAULT_EVIDENCE_THRESHOLD = 5


def _read(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            data.setdefault("current_version", "frebee-base-1")
            data.setdefault("evidence", [])
            data.setdefault("proposals", [])
            return data
    except (OSError, json.JSONDecodeError):
        pass
    return {"current_version": "frebee-base-1", "evidence": [], "proposals": []}


def _write_atomic(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=".evolution-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2, ensure_ascii=False)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_name, path)
    finally:
        try:
            os.unlink(tmp_name)
        except FileNotFoundError:
            pass


def record_major_evidence(
    registry_path: str | Path,
    *,
    topic: str,
    summary: str,
    source: str,
    confidence: float,
    threshold: int = DEFAULT_EVIDENCE_THRESHOLD,
) -> dict[str, Any]:
    """Record evidence and create a proposal only after repeated strong signals.

    Callers should pass verified, privacy-reviewed summaries, not raw conversations
    or secrets. Duplicate topic/source pairs are ignored to reduce evidence gaming.
    """
    if not topic.strip() or not summary.strip() or not source.strip():
        raise ValueError("topic, summary, and source are required")
    if not 0.0 <= confidence <= 1.0:
        raise ValueError("confidence must be between 0 and 1")
    if threshold < 2:
        raise ValueError("threshold must be at least 2")

    path = Path(registry_path)
    state = _read(path)
    topic_key = topic.strip().casefold()
    evidence = state["evidence"]
    duplicate = any(
        item.get("topic", "").casefold() == topic_key and item.get("source") == source.strip()
        for item in evidence
    )
    if not duplicate and confidence >= 0.8:
        evidence.append({
            "id": str(uuid.uuid4()),
            "topic": topic.strip(),
            "summary": summary.strip()[:2000],
            "source": source.strip()[:300],
            "confidence": confidence,
            "created_at": int(time.time()),
        })

    matching = [item for item in evidence if item.get("topic", "").casefold() == topic_key]
    proposals = state["proposals"]
    proposal = next((p for p in proposals if p.get("topic", "").casefold() == topic_key
                     and p.get("status") in {"proposed", "testing", "approved"}), None)
    if len(matching) >= threshold and proposal is None:
        proposal = {
            "id": str(uuid.uuid4()),
            "topic": topic.strip(),
            "status": "proposed",
            "evidence_count": len(matching),
            "base_version": state["current_version"],
            "candidate_version": f"candidate-{uuid.uuid4().hex[:8]}",
            "created_at": int(time.time()),
            "note": "Proposal only: a compatible trainer and benchmark suite must build and test a candidate model.",
        }
        proposals.append(proposal)

    _write_atomic(path, state)
    return {"accepted": not duplicate and confidence >= 0.8,
            "evidence_count": len(matching), "threshold": threshold,
            "upgrade_ready_for_review": proposal is not None,
            "proposal": proposal, "current_version": state["current_version"]}


def record_evaluation(
    registry_path: str | Path,
    proposal_id: str,
    *,
    passed: bool,
    metrics: dict[str, float],
) -> dict[str, Any]:
    """Record benchmark outcome; passing tests still does not deploy automatically."""
    path = Path(registry_path)
    state = _read(path)
    proposal = next((p for p in state["proposals"] if p.get("id") == proposal_id), None)
    if proposal is None:
        raise ValueError("unknown proposal")
    if any(not isinstance(v, (int, float)) or not 0 <= float(v) <= 1 for v in metrics.values()):
        raise ValueError("metrics must be numeric values between 0 and 1")
    proposal["evaluation"] = {"passed": bool(passed), "metrics": metrics, "created_at": int(time.time())}
    proposal["status"] = "awaiting_approval" if passed else "rejected"
    _write_atomic(path, state)
    return proposal


def approve_upgrade(registry_path: str | Path, proposal_id: str, *, approved_by: str) -> dict[str, Any]:
    """Explicitly promote a benchmark-passing candidate; never self-promotes."""
    if not approved_by.strip():
        raise ValueError("an approver identity is required")
    path = Path(registry_path)
    state = _read(path)
    proposal = next((p for p in state["proposals"] if p.get("id") == proposal_id), None)
    if proposal is None:
        raise ValueError("unknown proposal")
    if proposal.get("status") != "awaiting_approval" or not proposal.get("evaluation", {}).get("passed"):
        raise ValueError("proposal must pass evaluation before approval")
    old_version = state["current_version"]
    state["current_version"] = proposal["candidate_version"]
    proposal["status"] = "active"
    proposal["approved_by"] = approved_by.strip()[:200]
    proposal["previous_version"] = old_version
    proposal["approved_at"] = int(time.time())
    _write_atomic(path, state)
    return proposal


def get_evolution_status(registry_path: str | Path) -> dict[str, Any]:
    state = _read(Path(registry_path))
    return {"current_version": state["current_version"],
            "evidence_count": len(state["evidence"]),
            "proposals": state["proposals"]}
