from __future__ import annotations

import os
import shlex
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

from ..config import get_settings

ALLOWED_COMMANDS = {
    "python", "python3", "pip", "pip3", "pytest", "node", "npm", "npx", "pnpm", "yarn",
    "git", "ls", "cat", "head", "tail", "wc", "grep", "find", "mkdir", "touch",
    "sed", "echo", "tsc", "vite", "next", "gradle", "./gradlew", "javac", "java",
}
DENIED_TOKENS = ("rm -rf /", "sudo", "chmod 777 /", "curl http://169.254", ":(){")
MAX_FILE_BYTES = 400_000


class SandboxError(Exception):
    pass


@dataclass
class CommandResult:
    command: str
    exit_code: int
    stdout: str
    stderr: str
    timed_out: bool = False

    @property
    def ok(self) -> bool:
        return self.exit_code == 0 and not self.timed_out

    def as_dict(self) -> dict:
        return {
            "command": self.command,
            "exit_code": self.exit_code,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "timed_out": self.timed_out,
            "ok": self.ok,
        }

def resolve_inside(root: Path, relative: str) -> Path:
    """Resolves a user-supplied path and refuses to leave the project root."""
    candidate = (root / relative).resolve() if not os.path.isabs(relative) else Path(relative).resolve()
    root_resolved = root.resolve()
    if candidate != root_resolved and root_resolved not in candidate.parents:
        raise SandboxError(f"Path '{relative}' is outside the project workspace.")
    return candidate


def write_file(root: Path, relative: str, content: str) -> Path:
    if len(content.encode("utf-8")) > MAX_FILE_BYTES:
        raise SandboxError("File is larger than the 400 KB write limit.")
    path = resolve_inside(root, relative)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, "utf-8")
    return path


def read_file(root: Path, relative: str, max_bytes: int = 120_000) -> str:
    path = resolve_inside(root, relative)
    if not path.is_file():
        raise SandboxError(f"{relative} is not a file.")
    return path.read_text("utf-8", "ignore")[:max_bytes]


def list_files(root: Path, limit: int = 300) -> list[str]:
    entries: list[str] = []
    skip = {".git", "node_modules", "__pycache__", ".gradle", "build", "dist", ".venv"}
    for path in sorted(root.rglob("*")):
        if any(part in skip for part in path.parts):
            continue
        if path.is_file():
            entries.append(str(path.relative_to(root)))
        if len(entries) >= limit:
            break
    return entries

def _clean_env() -> dict[str, str]:
    """Environment without Frebee secrets, so generated code cannot read them."""
    keep = {"PATH", "HOME", "LANG", "LC_ALL", "TMPDIR", "SYSTEMROOT"}
    env = {key: value for key, value in os.environ.items() if key in keep}
    env.setdefault("PATH", "/usr/local/bin:/usr/bin:/bin")
    env["CI"] = "1"
    env["NO_COLOR"] = "1"
    return env


def run(command: str, root: Path, timeout: int | None = None) -> CommandResult:
    settings = get_settings()
    timeout = timeout or settings.sandbox_timeout_seconds
    if not command.strip():
        raise SandboxError("Empty command.")
    for token in DENIED_TOKENS:
        if token in command:
            raise SandboxError(f"Command rejected: it contains '{token}'.")
    try:
        parts = shlex.split(command)
    except ValueError as exc:
        raise SandboxError(f"Could not parse the command: {exc}") from exc
    if not parts:
        raise SandboxError("Empty command.")
    program = parts[0]
    if program not in ALLOWED_COMMANDS:
        raise SandboxError(
            f"'{program}' is not on the sandbox allowlist. Allowed: {', '.join(sorted(ALLOWED_COMMANDS))}."
        )
    if program in {"python", "python3"} and len(parts) > 1 and parts[1] not in {"-m", "-c", "-V", "--version"}:
        resolve_inside(root, parts[1])
    if not (root / program).exists() and shutil.which(program) is None:
        raise SandboxError(f"'{program}' is not installed in this environment.")

    root.mkdir(parents=True, exist_ok=True)
    cwd = root
    try:
        completed = subprocess.run(
            parts,
            cwd=str(cwd),
            env=_clean_env(),
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        return CommandResult(
            command=command,
            exit_code=124,
            stdout=(exc.stdout or "")[: settings.sandbox_max_output_bytes],
            stderr=f"Command exceeded the {timeout}s sandbox limit and was stopped.",
            timed_out=True,
        )
    cap = settings.sandbox_max_output_bytes
    return CommandResult(
        command=command,
        exit_code=completed.returncode,
        stdout=(completed.stdout or "")[:cap],
        stderr=(completed.stderr or "")[:cap],
    )
