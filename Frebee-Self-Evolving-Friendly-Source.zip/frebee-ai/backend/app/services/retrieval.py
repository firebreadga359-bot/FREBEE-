from __future__ import annotations

import hashlib
import json
import math
import re
import uuid
from dataclasses import dataclass
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..models import KnowledgeChunk, KnowledgeSource, WebPage, now_ms

DIM = 256
TOKEN_RE = re.compile(r"[a-z0-9]+")
STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "are", "was", "were",
    "have", "has", "not", "you", "your", "but", "they", "their", "what", "how",
}


def tokenize(text: str) -> list[str]:
    return [token for token in TOKEN_RE.findall(text.lower()) if token not in STOPWORDS and len(token) > 1]

def embed(text: str) -> list[float]:
    """Deterministic hashed bag-of-words vector.

    This is a local lexical embedding, not a neural one. It keeps the free
    deployment useful without an embedding vendor, and the interface allows a
    real embedding model to replace it later.
    """
    vector = [0.0] * DIM
    for token in tokenize(text):
        digest = hashlib.blake2b(token.encode(), digest_size=8).digest()
        bucket = int.from_bytes(digest[:4], "big") % DIM
        sign = 1.0 if digest[4] % 2 else -1.0
        vector[bucket] += sign
    norm = math.sqrt(sum(value * value for value in vector))
    if norm:
        vector = [value / norm for value in vector]
    return vector


def cosine(left: list[float], right: list[float]) -> float:
    if not left or not right or len(left) != len(right):
        return 0.0
    return sum(a * b for a, b in zip(left, right))


def chunk_text(text: str, size: int = 1200, overlap: int = 150) -> list[str]:
    cleaned = re.sub(r"\n{3,}", "\n\n", text).strip()
    if not cleaned:
        return []
    chunks: list[str] = []
    start = 0
    while start < len(cleaned):
        end = min(start + size, len(cleaned))
        if end < len(cleaned):
            split = cleaned.rfind("\n", start + size // 2, end)
            if split != -1:
                end = split
        chunk = cleaned[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= len(cleaned):
            break
        start = max(end - overlap, start + 1)
    return chunks

@dataclass
class Hit:
    chunk_id: str
    source_id: str
    title: str
    location: str
    content: str
    score: float


def index_source(db: Session, user_id: str, kind: str, location: str, title: str, text: str) -> KnowledgeSource:
    existing = db.scalar(
        select(KnowledgeSource).where(
            KnowledgeSource.user_id == user_id,
            KnowledgeSource.kind == kind,
            KnowledgeSource.location == location[:600],
        )
    )
    if existing is not None and existing.status == "ready":
        existing.updated_at = now_ms()
        db.commit()
        return existing
    source = KnowledgeSource(
        id=str(uuid.uuid4()), user_id=user_id, kind=kind, location=location[:600],
        title=(title or location)[:300], status="indexing", created_at=now_ms(), updated_at=now_ms(),
    )
    db.add(source)
    db.commit()
    chunks = chunk_text(text)
    for ordinal, chunk in enumerate(chunks):
        db.add(KnowledgeChunk(
            id=str(uuid.uuid4()), source_id=source.id, user_id=user_id, ordinal=ordinal,
            content=chunk, embedding_json=json.dumps(embed(chunk)),
        ))
    source.status = "ready" if chunks else "empty"
    source.chunk_count = len(chunks)
    source.updated_at = now_ms()
    db.commit()
    return source

def search(db: Session, user_id: str, query: str, limit: int = 6) -> list[Hit]:
    """Hybrid lexical + vector scoring over the caller's own chunks."""
    query_vector = embed(query)
    terms = set(tokenize(query))
    if not terms:
        return []
    rows = db.execute(
        select(KnowledgeChunk, KnowledgeSource)
        .join(KnowledgeSource, KnowledgeSource.id == KnowledgeChunk.source_id)
        .where(KnowledgeChunk.user_id == user_id)
        .limit(4000)
    ).all()
    hits: list[Hit] = []
    for chunk, source in rows:
        tokens = set(tokenize(chunk.content))
        if not tokens:
            continue
        keyword = len(terms & tokens) / len(terms)
        if keyword == 0:
            continue
        vector = cosine(query_vector, json.loads(chunk.embedding_json or "[]"))
        score = 0.6 * keyword + 0.4 * max(vector, 0.0)
        hits.append(Hit(chunk.id, source.id, source.title, source.location, chunk.content, score))
    hits.sort(key=lambda hit: hit.score, reverse=True)
    return hits[:limit]

def wrap_untrusted(text: str, label: str = "Untrusted data") -> str:
    """Marks retrieved or uploaded text as data so the model never follows it as instructions."""
    return f"{label}:\n<untrusted>\n{text.strip()}\n</untrusted>"


def build_context(hits: list[Hit], budget: int = 16_000) -> str:
    blocks: list[str] = []
    used = 0
    for hit in hits:
        block = f"[knowledge: {hit.title}]\n{hit.content}"
        if used + len(block) > budget:
            break
        blocks.append(block)
        used += len(block)
    return "\n\n".join(blocks)


def delete_source(db: Session, user_id: str, source_id: str) -> bool:
    source = db.get(KnowledgeSource, source_id)
    if source is None or source.user_id != user_id:
        return False
    for chunk in db.scalars(select(KnowledgeChunk).where(KnowledgeChunk.source_id == source_id)).all():
        db.delete(chunk)
    db.delete(source)
    db.commit()
    return True

@dataclass
class WebHit:
    url: str
    title: str
    content: str
    score: float


def cache_web_pages(db: Session, pages: list[tuple[str, str, str]]) -> int:
    """Keeps fetched public page text for every user to retrieve later.

    Only page text is stored: no queries, no user ids, no files. Set
    FREBEE_SHARED_WEB_CACHE=false to keep the instance cache empty.
    """
    if not get_settings().shared_web_cache:
        return 0
    stored = 0
    for url, title, text in pages:
        if not url.startswith(("http://", "https://")) or len(text) < 400:
            continue
        key = url[:2000]
        if db.get(WebPage, key) is not None:
            continue
        db.add(WebPage(url=key, title=(title or url)[:300], text=text[:40_000], created_at=now_ms()))
        stored += 1
    if stored:
        db.commit()
    return stored


def search_web_cache(db: Session, query: str, limit: int = 3) -> list[WebHit]:
    terms = set(tokenize(query))
    if not terms:
        return []
    rows = db.scalars(select(WebPage).order_by(WebPage.created_at.desc()).limit(400)).all()
    query_vector = embed(query)
    hits: list[WebHit] = []
    for row in rows:
        tokens = set(tokenize(row.title + " " + row.text[:6000]))
        if not tokens:
            continue
        keyword = len(terms & tokens) / len(terms)
        if keyword < 0.25:
            continue
        vector = cosine(query_vector, embed(row.text[:2000]))
        hits.append(WebHit(row.url, row.title, row.text, 0.7 * keyword + 0.3 * max(vector, 0.0)))
    hits.sort(key=lambda hit: hit.score, reverse=True)
    return hits[:limit]


def build_web_context(hits: list[WebHit], budget: int = 3500) -> str:
    blocks: list[str] = []
    used = 0
    for hit in hits:
        block = f"[page: {hit.title} - {hit.url}]\n{hit.content[:1200]}"
        if used + len(block) > budget:
            break
        blocks.append(block)
        used += len(block)
    return "\n\n".join(blocks)
