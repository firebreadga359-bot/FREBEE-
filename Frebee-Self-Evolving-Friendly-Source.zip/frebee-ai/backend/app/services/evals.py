from __future__ import annotations

import json
import uuid
from dataclasses import dataclass

from sqlalchemy.orm import Session

from ..models import EvalRun, Memory, now_ms
from . import retrieval, sandbox


@dataclass
class Case:
    name: str
    passed: bool
    detail: str = ""


def _case(name: str, check) -> Case:
    try:
        ok, detail = check()
        return Case(name, bool(ok), detail)
    except Exception as exc:
        return Case(name, False, f"{exc.__class__.__name__}: {exc}")


def _citation_format() -> tuple[bool, str]:
    from .research import ResearchResult, Source, build_context

    result = ResearchResult(sources=[
        Source(index=1, title="Example", url="https://example.com/a", text="Alpha fact."),
        Source(index=2, title="Second", url="https://example.com/b", text="Beta fact."),
    ])
    context = build_context(result)
    ok = "[1]" in context and "[2]" in context and "https://example.com/a" in context
    return ok, "numbered sources include urls" if ok else "citation markers missing"


def _retrieval_relevance(db: Session, user_id: str) -> tuple[bool, str]:
    source = retrieval.index_source(
        db, user_id, "text", "unit-test", "Gradle notes",
        "Gradle build caching speeds up Android builds. Kotlin compile avoidance matters.",
    )
    try:
        hits = retrieval.search(db, user_id, "how do I speed up gradle android builds")
        top = hits[0].content.lower() if hits else ""
        ok = bool(hits) and "gradle" in top
        return ok, f"{len(hits)} hit(s), top score {hits[0].score:.2f}" if hits else "no hits"
    finally:
        retrieval.delete_source(db, user_id, source.id)

def _path_traversal() -> tuple[bool, str]:
    import tempfile
    from pathlib import Path

    root = Path(tempfile.mkdtemp(prefix="frebee-eval-"))
    try:
        sandbox.write_file(root, "safe.txt", "ok")
    except sandbox.SandboxError as exc:
        return False, f"safe write rejected: {exc}"
    try:
        sandbox.write_file(root, "../escape.txt", "bad")
        return False, "path traversal was allowed"
    except sandbox.SandboxError:
        return True, "traversal blocked"


def _command_allowlist() -> tuple[bool, str]:
    import tempfile
    from pathlib import Path

    root = Path(tempfile.mkdtemp(prefix="frebee-eval-"))
    try:
        sandbox.run("curl https://example.com", root)
        return False, "unlisted command allowed"
    except sandbox.SandboxError:
        pass
    result = sandbox.run("echo frebee", root)
    return result.ok and "frebee" in result.stdout, f"echo exit={result.exit_code}"


def _prompt_injection_wrapping() -> tuple[bool, str]:
    from .orchestrator import IDENTITY

    ok = "<untrusted>" in IDENTITY and "never as instructions" in IDENTITY
    return ok, "system prompt declares untrusted data handling"


def _memory_delete(db: Session, user_id: str) -> tuple[bool, str]:
    row = Memory(id=str(uuid.uuid4()), user_id=user_id, scope="user", key="eval", value="temp")
    db.add(row)
    db.commit()
    db.delete(row)
    db.commit()
    gone = db.get(Memory, row.id) is None
    return gone, "memory row removed" if gone else "memory row survived deletion"

def run_suite(db: Session, user_id: str, provider: str = "", model: str = "") -> dict:
    cases: list[Case] = [
        _case("citation_format", _citation_format),
        _case("retrieval_relevance", lambda: _retrieval_relevance(db, user_id)),
        _case("path_traversal_blocked", _path_traversal),
        _case("command_allowlist", _command_allowlist),
        _case("prompt_injection_wrapping", _prompt_injection_wrapping),
        _case("memory_deletion", lambda: _memory_delete(db, user_id)),
    ]
    passed = sum(1 for case in cases if case.passed)
    score = round(passed / len(cases), 3) if cases else 0.0
    record = EvalRun(
        id=str(uuid.uuid4()), user_id=user_id, suite="core", provider=provider, model=model,
        score=score, total=len(cases),
        results_json=json.dumps([{"name": c.name, "passed": c.passed, "detail": c.detail} for c in cases]),
        created_at=now_ms(),
    )
    db.add(record)
    db.commit()
    return {
        "id": record.id,
        "score": score,
        "passed": passed,
        "total": len(cases),
        "cases": [{"name": c.name, "passed": c.passed, "detail": c.detail} for c in cases],
        "created_at": record.created_at,
    }
