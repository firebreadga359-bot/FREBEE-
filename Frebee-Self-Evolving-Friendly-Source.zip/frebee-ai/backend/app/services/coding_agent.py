from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

from sqlalchemy.orm import Session

from ..models import Project, User
from ..providers.base import ChatMessage, ProviderError
from ..providers.registry import resolve
from . import sandbox

logger = logging.getLogger("frebee.coding")

PROTOCOL = """TOOL_PROTOCOL
Reply with exactly one JSON object and nothing else.
To use a tool: {"tool": "<name>", "args": {...}}
To finish:    {"final": "<summary of what you changed and verified>"}

Tools:
- list_files {} -> project files
- read_file {"path": "app/main.py"}
- write_file {"path": "app/main.py", "content": "..."}
- run_command {"command": "python3 -m pytest -q"}
- finish {"summary": "..."}

Rules: never invent command output. Only claim a build or test passed if a
run_command result shows exit_code 0. Prefer small, reviewable changes.
"""

@dataclass
class Step:
    index: int
    tool: str
    args: dict
    ok: bool
    summary: str

    def as_dict(self) -> dict:
        return {"index": self.index, "tool": self.tool, "ok": self.ok, "summary": self.summary}


@dataclass
class AgentResult:
    final: str = ""
    steps: list[Step] = field(default_factory=list)
    changed_files: list[str] = field(default_factory=list)
    commands: list[dict] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    stopped: str = "finished"

    def as_dict(self) -> dict:
        return {
            "final": self.final,
            "steps": [step.as_dict() for step in self.steps],
            "changed_files": self.changed_files,
            "commands": self.commands,
            "errors": self.errors,
            "stopped": self.stopped,
        }

def parse_action(text: str) -> dict | None:
    """Extracts the JSON action from a model reply, tolerating code fences."""
    candidate = text.strip()
    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", candidate, re.S)
    if fenced:
        candidate = fenced.group(1)
    start, end = candidate.find("{"), candidate.rfind("}")
    if start == -1 or end <= start:
        return None
    try:
        payload = json.loads(candidate[start : end + 1])
    except ValueError:
        return None
    return payload if isinstance(payload, dict) else None


def execute(root: Path, action: dict) -> tuple[bool, str, str]:
    """Runs one tool action. Returns (ok, observation, tool_name)."""
    tool = str(action.get("tool") or "").strip()
    args = action.get("args") or {}
    if not isinstance(args, dict):
        return False, "args must be an object", tool
    try:
        if tool == "list_files":
            files = sandbox.list_files(root)
            return True, "Files:\n" + "\n".join(files), tool
        if tool == "read_file":
            return True, sandbox.read_file(root, str(args.get("path", ""))), tool
        if tool == "write_file":
            path = sandbox.write_file(root, str(args.get("path", "")), str(args.get("content", "")))
            return True, f"Wrote {path.relative_to(root)} ({len(str(args.get('content', '')))} bytes)", tool
        if tool == "run_command":
            result = sandbox.run(str(args.get("command", "")), root)
            observation = json.dumps(result.as_dict(), indent=2)
            return result.ok, observation, tool
    except sandbox.SandboxError as exc:
        return False, f"Rejected: {exc}", tool
    return False, f"Unknown tool '{tool}'. Use one of the documented tools.", tool

async def run_task(
    db: Session,
    user: User,
    project: Project,
    task: str,
    *,
    model: str | None = None,
    provider_kind: str | None = None,
    max_steps: int = 8,
) -> AgentResult:
    result = AgentResult()
    root = Path(project.root_path)
    if not root.exists():
        root.mkdir(parents=True, exist_ok=True)
    try:
        providers = resolve(db, user, provider_kind)
    except Exception as exc:
        result.errors.append(str(exc))
        result.stopped = "no_provider"
        return result

    provider = providers[0].provider
    try:
        provider.resolve_model(model)
    except ProviderError as exc:
        result.errors.append(exc.message)
        result.stopped = "no_model"
        return result

    files = sandbox.list_files(root, limit=200)
    system = ChatMessage(role="system", content=(
        f"You are Frebee's coding agent working in the project '{project.name}' ({project.kind}).\n"
        f"Existing files:\n" + "\n".join(files[:200]) + "\n\n" + PROTOCOL
    ))
    messages: list[ChatMessage] = [system, ChatMessage(role="user", content=task)]

    for step_index in range(1, max_steps + 1):
        try:
            reply, _, _ = await provider.complete(
                messages, model=model, temperature=0.1, max_tokens=3000
            )
        except ProviderError as exc:
            result.errors.append(exc.message)
            result.stopped = "provider_error"
            break

        action = parse_action(reply)
        if action is None:
            result.errors.append("The model did not return a valid tool action.")
            result.stopped = "protocol_error"
            break
        if "final" in action:
            result.final = str(action.get("final") or "").strip() or reply.strip()
            break

        ok, observation, tool = execute(root, action)
        summary = observation.splitlines()[0][:300] if observation else ""
        result.steps.append(Step(step_index, tool, action.get("args") or {}, ok, summary))
        if tool == "write_file" and ok:
            path = str((action.get("args") or {}).get("path", ""))
            if path and path not in result.changed_files:
                result.changed_files.append(path)
        if tool == "run_command":
            result.commands.append({"command": str((action.get("args") or {}).get("command", "")), "ok": ok})
        if tool == "finish":
            result.final = str((action.get("args") or {}).get("summary") or summary)
            break
        messages.append(ChatMessage(role="assistant", content=reply))
        messages.append(ChatMessage(
            role="user",
            content=f"tool_result for {tool} (ok={ok}):\n<untrusted>\n{observation[:8000]}\n</untrusted>",
        ))
    else:
        result.stopped = "max_steps"

    if not result.final:
        result.final = (
            "The agent stopped without a final summary. "
            + (f"Last error: {result.errors[-1]}" if result.errors else "")
        ).strip()
    project.last_task = task[:300]
    db.add(project)
    db.commit()
    return result
