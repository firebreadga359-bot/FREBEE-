from __future__ import annotations

import asyncio
import html as html_module
import ipaddress
import logging
import re
import socket
from dataclasses import dataclass, field
from html.parser import HTMLParser
from urllib.parse import parse_qs, quote, urlparse

import httpx

from ..config import get_settings

logger = logging.getLogger("frebee.research")

MAX_PAGE_BYTES = 2_000_000
BLOCKED_HOSTS = {"localhost", "metadata.google.internal"}


class SearchUnavailable(Exception):
    pass


@dataclass
class Source:
    index: int
    title: str
    url: str
    snippet: str = ""
    published: str | None = None
    text: str = ""
    score: float = 0.0

    def as_dict(self) -> dict:
        return {
            "index": self.index,
            "title": self.title,
            "url": self.url,
            "snippet": self.snippet,
            "published": self.published,
            "score": round(self.score, 3),
        }


@dataclass
class ResearchResult:
    sources: list[Source] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    provider: str = ""

    @property
    def usable(self) -> bool:
        return bool(self.sources)

class _TextExtractor(HTMLParser):
    SKIP = {"script", "style", "noscript", "svg", "nav", "footer", "form"}

    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []
        self.title = ""
        self._skip_depth = 0
        self._in_title = False

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self._skip_depth += 1
        if tag == "title":
            self._in_title = True

    def handle_endtag(self, tag):
        if tag in self.SKIP and self._skip_depth:
            self._skip_depth -= 1
        if tag == "title":
            self._in_title = False

    def handle_data(self, data):
        if self._in_title:
            self.title += data
            return
        if self._skip_depth:
            return
        text = " ".join(data.split())
        if text:
            self.parts.append(text)


def extract_text(html: str) -> tuple[str, str]:
    parser = _TextExtractor()
    try:
        parser.feed(html)
    except Exception:
        return "", html[:5000]
    text = "\n".join(parser.parts)
    return " ".join(parser.title.split()), text

def _host_is_public(host: str) -> bool:
    if not host or host in BLOCKED_HOSTS:
        return False
    try:
        infos = socket.getaddrinfo(host, None)
    except OSError:
        return False
    for info in infos:
        address = info[4][0]
        try:
            ip = ipaddress.ip_address(address)
        except ValueError:
            return False
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            return False
    return True


def _safe_url(url: str) -> bool:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        return False
    return _host_is_public(parsed.hostname or "")

async def _tavily(query: str, limit: int) -> tuple[list[dict], str]:
    settings = get_settings()
    body = {"api_key": settings.tavily_api_key, "query": query, "max_results": limit,
            "search_depth": "basic", "include_answer": False}
    async with httpx.AsyncClient(timeout=settings.research_timeout_seconds) as client:
        response = await client.post("https://api.tavily.com/search", json=body)
    if response.status_code >= 400:
        raise SearchUnavailable(f"Tavily returned {response.status_code}")
    results = response.json().get("results") or []
    return [
        {"title": item.get("title") or item.get("url", ""), "url": item.get("url", ""),
         "snippet": item.get("content", ""), "published": item.get("published_date")}
        for item in results
        if item.get("url")
    ], "tavily"

async def _searxng(query: str, limit: int) -> tuple[list[dict], str]:
    settings = get_settings()
    url = settings.searxng_url.rstrip("/") + "/search"
    params = {"q": query, "format": "json", "language": "en"}
    async with httpx.AsyncClient(timeout=settings.research_timeout_seconds) as client:
        response = await client.get(url, params=params)
    if response.status_code >= 400:
        raise SearchUnavailable(f"SearXNG returned {response.status_code}")
    results = response.json().get("results") or []
    return [
        {"title": item.get("title", ""), "url": item.get("url", ""),
         "snippet": item.get("content", ""), "published": item.get("publishedDate")}
        for item in results[:limit]
        if item.get("url")
    ], "searxng"


async def _brave(query: str, limit: int) -> tuple[list[dict], str]:
    settings = get_settings()
    headers = {"X-Subscription-Token": settings.brave_api_key, "Accept": "application/json"}
    params = {"q": query, "count": min(limit, 20)}
    async with httpx.AsyncClient(timeout=settings.research_timeout_seconds) as client:
        response = await client.get("https://api.search.brave.com/res/v1/web/search",
                                    params=params, headers=headers)
    if response.status_code >= 400:
        raise SearchUnavailable(f"Brave returned {response.status_code}")
    results = ((response.json().get("web") or {}).get("results")) or []
    return [
        {"title": item.get("title", ""), "url": item.get("url", ""),
         "snippet": item.get("description", ""), "published": item.get("age")}
        for item in results[:limit]
        if item.get("url")
    ], "brave"

WIKI_API = "https://en.wikipedia.org/w/api.php"
SEARCH_UA = "FrebeeResearch/0.1 (+https://github.com/frebee)"


async def _wikipedia(query: str, limit: int) -> tuple[list[dict], str]:
    params = {
        "action": "query",
        "list": "search",
        "srsearch": query,
        "srlimit": min(limit, 20),
        "srprop": "snippet|timestamp",
        "format": "json",
        "origin": "*",
    }
    async with httpx.AsyncClient(timeout=15, headers={"User-Agent": SEARCH_UA}) as client:
        response = await client.get(WIKI_API, params=params)
    if response.status_code >= 400:
        raise SearchUnavailable(f"Wikipedia returned {response.status_code}")
    results = []
    for item in (response.json().get("query") or {}).get("search") or []:
        title = item.get("title") or ""
        if not title:
            continue
        snippet = re.sub(r"<[^>]+>", "", item.get("snippet") or "")
        results.append({
            "title": title,
            "url": "https://en.wikipedia.org/wiki/" + quote(title.replace(" ", "_")),
            "snippet": html_module.unescape(snippet).strip(),
            "published": item.get("timestamp"),
        })
    return results, "wikipedia"


async def _duckduckgo(query: str, limit: int) -> tuple[list[dict], str]:
    async with httpx.AsyncClient(timeout=15, headers={"User-Agent": SEARCH_UA}) as client:
        response = await client.post("https://html.duckduckgo.com/html/", data={"q": query})
    if response.status_code >= 400:
        raise SearchUnavailable(f"DuckDuckGo returned {response.status_code}")
    results = []
    pattern = re.compile(
        r'class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>(.*?)(?=class="result__a"|\Z)',
        re.S,
    )
    for match in pattern.finditer(response.text):
        href, title_html, tail = match.group(1), match.group(2), match.group(3)
        url = _duckduckgo_target(href)
        if not url:
            continue
        snippet_match = re.search(r'class="result__snippet"[^>]*>(.*?)</a>', tail, re.S)
        snippet = snippet_match.group(1) if snippet_match else ""
        results.append({
            "title": html_module.unescape(re.sub(r"<[^>]+>", "", title_html)).strip(),
            "url": url,
            "snippet": html_module.unescape(re.sub(r"<[^>]+>", " ", snippet)).strip(),
            "published": None,
        })
        if len(results) >= limit:
            break
    return results, "duckduckgo"


def _duckduckgo_target(href: str) -> str:
    """DuckDuckGo wraps results in /l/?uddg=<encoded>. Unwrap it."""
    if href.startswith("//"):
        href = "https:" + href
    parsed = urlparse(href)
    if parsed.netloc.endswith("duckduckgo.com") and parsed.path.startswith("/l/"):
        target = (parse_qs(parsed.query).get("uddg") or [""])[0]
        return target if target.startswith(("http://", "https://")) else ""
    return href if href.startswith(("http://", "https://")) else ""


async def _stackexchange(query: str, limit: int) -> tuple[list[dict], str]:
    params = {
        "order": "desc",
        "sort": "relevance",
        "q": query,
        "site": "stackoverflow",
        "pagesize": min(limit, 10),
    }
    async with httpx.AsyncClient(timeout=15, headers={"User-Agent": SEARCH_UA}) as client:
        response = await client.get("https://api.stackexchange.com/2.3/search/advanced", params=params)
    if response.status_code >= 400:
        raise SearchUnavailable(f"StackExchange returned {response.status_code}")
    results = []
    for item in response.json().get("items") or []:
        link = item.get("link") or ""
        if not link:
            continue
        results.append({
            "title": html_module.unescape(item.get("title") or link),
            "url": link,
            "snippet": html_module.unescape(re.sub(r"<[^>]+>", " ", item.get("body") or ""))[:400].strip(),
            "published": None,
        })
    return results, "stackexchange"


async def _arxiv(query: str, limit: int) -> tuple[list[dict], str]:
    params = {"search_query": f"all:{query}", "start": 0, "max_results": min(limit, 5)}
    async with httpx.AsyncClient(timeout=15, headers={"User-Agent": SEARCH_UA}) as client:
        response = await client.get("https://export.arxiv.org/api/query", params=params)
    if response.status_code >= 400:
        raise SearchUnavailable(f"arXiv returned {response.status_code}")
    import xml.etree.ElementTree as ET

    namespace = {"atom": "http://www.w3.org/2005/Atom"}
    root = ET.fromstring(response.text)
    results = []
    for entry in root.findall("atom:entry", namespace):
        link = (entry.findtext("atom:id", default="", namespaces=namespace) or "").strip()
        title = (entry.findtext("atom:title", default="", namespaces=namespace) or "").strip()
        summary = (entry.findtext("atom:summary", default="", namespaces=namespace) or "").strip()
        published = (entry.findtext("atom:published", default="", namespaces=namespace) or "").strip()
        if link and title:
            results.append({
                "title": " ".join(title.split()),
                "url": link,
                "snippet": " ".join(summary.split())[:400],
                "published": published or None,
            })
    return results, "arxiv"


async def _crossref(query: str, limit: int) -> tuple[list[dict], str]:
    params = {"query": query, "rows": min(limit, 5), "select": "title,URL,abstract,issued"}
    async with httpx.AsyncClient(timeout=15, headers={"User-Agent": SEARCH_UA}) as client:
        response = await client.get("https://api.crossref.org/works", params=params)
    if response.status_code >= 400:
        raise SearchUnavailable(f"Crossref returned {response.status_code}")
    results = []
    for item in (response.json().get("message") or {}).get("items") or []:
        titles = item.get("title") or []
        url = item.get("URL") or ""
        if not titles or not url:
            continue
        issued = ((item.get("issued") or {}).get("date-parts") or [[None]])[0]
        year = str(issued[0]) if issued and issued[0] else None
        results.append({
            "title": titles[0],
            "url": url,
            "snippet": re.sub(r"<[^>]+>", " ", item.get("abstract") or "")[:400].strip(),
            "published": year,
        })
    return results, "crossref"


ACADEMIC_HINTS = (
    "paper", "study", "research", "survey", "theory", "proof", "dataset", "arxiv",
    "journal", "citation", "benchmark", "state of the art",
)


async def _keyless(query: str, limit: int) -> tuple[list[dict], str]:
    """Free, keyless research across sources that permit anonymous use.

    Wikipedia, Stack Exchange, arXiv and Crossref all publish open APIs; the
    DuckDuckGo adapter is included for hosts that can reach it and is skipped
    when it fails. Each provider is capped, then results are interleaved so the
    shortlist is not dominated by a single domain.
    """
    providers = [_wikipedia, _stackexchange, _duckduckgo]
    lowered = query.lower()
    if any(hint in lowered for hint in ACADEMIC_HINTS) or "how" not in lowered:
        providers.extend([_arxiv, _crossref])

    outcomes = await asyncio.gather(
        *(provider(query, max(2, limit // 2)) for provider in providers),
        return_exceptions=True,
    )

    buckets: list[tuple[str, list[dict]]] = []
    errors: list[str] = []
    for provider, outcome in zip(providers, outcomes):
        if isinstance(outcome, BaseException):
            errors.append(f"{provider.__name__[1:]}: {outcome}")
            continue
        results, name = outcome
        if results:
            buckets.append((name, results))

    if not buckets:
        raise SearchUnavailable(
            "Free web search returned nothing (" + "; ".join(errors[:2] or ["no results"]) + "). "
            "Set FREEBEE_TAVILY_API_KEY, FREEBEE_SEARXNG_URL or FREEBEE_BRAVE_API_KEY "
            "for a paid provider."
        )

    merged: list[dict] = []
    seen: set[str] = set()
    for rank in range(max(len(items) for _, items in buckets)):
        for _, items in buckets:
            if rank >= len(items):
                continue
            item = items[rank]
            if item["url"] in seen:
                continue
            seen.add(item["url"])
            merged.append(item)
            if len(merged) >= limit:
                return merged, "+".join(name for name, _ in buckets)
    return merged, "+".join(name for name, _ in buckets)


def configured_search_provider() -> str:
    settings = get_settings()
    if settings.tavily_api_key:
        return "tavily"
    if settings.searxng_url:
        return "searxng"
    if settings.brave_api_key:
        return "brave"
    if settings.allow_keyless_search:
        return "keyless"
    return ""


async def search(query: str, limit: int | None = None) -> tuple[list[dict], str]:
    settings = get_settings()
    limit = limit or settings.research_max_sources
    provider = configured_search_provider()
    if not provider:
        raise SearchUnavailable(
            "Web search is not configured. Set FREEBEE_TAVILY_API_KEY, FREEBEE_SEARXNG_URL "
            "or FREEBEE_BRAVE_API_KEY, or enable FREEBEE_ALLOW_KEYLESS_SEARCH for the "
            "key-free DuckDuckGo and Wikipedia path."
        )
    if provider == "tavily":
        return await _tavily(query, limit)
    if provider == "searxng":
        return await _searxng(query, limit)
    if provider == "brave":
        return await _brave(query, limit)
    return await _keyless(query, limit)


async def fetch_page(url: str) -> tuple[str, str]:
    """Returns (title, text). Raises SearchUnavailable when the page is unusable."""
    if not _safe_url(url):
        raise SearchUnavailable("Blocked a non-public or non-HTTP address.")
    headers = {"User-Agent": "FrebeeResearch/0.1 (+https://github.com/frebee)"}
    async with httpx.AsyncClient(timeout=20, follow_redirects=True, headers=headers) as client:
        try:
            response = await client.get(url)
        except httpx.HTTPError as exc:
            raise SearchUnavailable(f"Could not fetch page: {exc}") from exc
    if response.status_code >= 400:
        raise SearchUnavailable(f"Page returned {response.status_code}")
    content = response.content[:MAX_PAGE_BYTES]
    content_type = response.headers.get("content-type", "")
    if "pdf" in content_type:
        try:
            import io
            from pypdf import PdfReader
            reader = PdfReader(io.BytesIO(content))
            text = "\n".join((page.extract_text() or "") for page in reader.pages[:40])
            return url.rsplit("/", 1)[-1], text
        except Exception as exc:
            raise SearchUnavailable(f"PDF extraction failed: {exc}") from exc
    html = content.decode(response.encoding or "utf-8", "ignore")
    title, text = extract_text(html)
    return title or url, text

TRUSTED_DOMAINS = (
    "wikipedia.org", "docs.python.org", "developer.mozilla.org", "github.com",
    "arxiv.org", "nature.com", "who.int", "nih.gov", "europa.eu", "un.org",
    "kotlinlang.org", "developer.android.com", "fastapi.tiangolo.com",
)


_QUERY_STOPWORDS = {
    "what", "whats", "who", "when", "where", "why", "how", "which", "whose", "is", "are",
    "was", "were", "the", "a", "an", "of", "to", "in", "on", "for", "and", "or", "but",
    "does", "do", "did", "can", "could", "should", "would", "will", "please", "tell", "me",
    "about", "give", "latest", "newest", "current", "currently", "today", "now", "i", "you",
    "my", "your", "it", "its", "this", "that", "these", "those", "with", "from", "be", "been",
    "has", "have", "had", "there", "their", "they", "we", "us", "some", "any", "more", "most",
    "so", "if", "then", "than", "as", "at", "by", "not", "no", "yes", "up", "out", "also",
}


def search_terms(question: str) -> list[str]:
    """Turns a chat question into the short keyword query search engines rank well."""
    words = re.findall(r"[A-Za-z0-9][A-Za-z0-9+.#_-]+", question.lower())
    terms = [word for word in words if word not in _QUERY_STOPWORDS and len(word) > 2]
    # Keep order, drop repeats, and bound the length: long queries rank worse, not better.
    seen: set[str] = set()
    unique = [word for word in terms if not (word in seen or seen.add(word))]
    return unique[:8]


def _relevance(item: dict, terms: list[str]) -> float:
    if not terms:
        return 0.0
    title = (item.get("title") or "").lower()
    body = f"{title} {item.get('snippet') or ''}".lower()
    title_hits = sum(1 for term in terms if term in title) / len(terms)
    body_hits = sum(1 for term in terms if term in body) / len(terms)
    return 0.65 * title_hits + 0.35 * body_hits


def _host_matches_terms(url: str, terms: list[str]) -> bool:
    host = (urlparse(url).hostname or "").lower()
    return any(len(term) > 3 and term in host for term in terms)


def _score(source: dict, position: int) -> float:
    score = max(0.0, 1.0 - position * 0.08)
    host = urlparse(source.get("url", "")).hostname or ""
    if any(host.endswith(domain) for domain in TRUSTED_DOMAINS):
        score += 0.25
    if len(source.get("snippet") or "") > 120:
        score += 0.05
    if source.get("published"):
        score += 0.05
    return score


async def research(question: str, limit: int | None = None) -> ResearchResult:
    settings = get_settings()
    limit = limit or settings.research_max_sources
    result = ResearchResult()
    terms = search_terms(question)
    query = " ".join(terms) or question
    try:
        results, provider = await search(query, max(limit * 2, limit))
        result.provider = provider
    except SearchUnavailable as exc:
        result.errors.append(str(exc))
        return result
    except Exception as exc:  # network, quota, malformed payload
        result.errors.append(f"Search failed: {exc}")
        return result

    seen: set[str] = set()
    candidates = []
    for position, item in enumerate(results):
        url = item.get("url", "")
        key = url.split("#")[0].rstrip("/")
        if not url or key in seen:
            continue
        seen.add(key)
        relevance = _relevance(item, terms)
        item["relevance"] = relevance
        item["score"] = _score(item, position) + 1.2 * relevance
        if _host_matches_terms(item.get("url", ""), terms):
            item["score"] += 0.8
        candidates.append(item)
    candidates.sort(key=lambda item: item["score"], reverse=True)
    # Drop results that share almost none of the question's terms: they are what makes a
    # research answer wander off topic.
    if any(item["relevance"] >= 0.5 for item in candidates):
        candidates = [item for item in candidates if item["relevance"] >= 0.3]

    for item in candidates[:limit]:
        source = Source(
            index=len(result.sources) + 1,
            title=item.get("title") or item.get("url", ""),
            url=item["url"],
            snippet=item.get("snippet") or "",
            published=item.get("published"),
            score=item["score"],
        )
        fetched = False
        try:
            title, text = await fetch_page(source.url)
            if text.strip():
                source.text = text[:12000]
                source.title = source.title or title
                fetched = True
        except SearchUnavailable as exc:
            result.errors.append(f"{source.url}: {exc}")
        # A page blocked to us (403, paywall) carries no evidence; keep it out of the
        # numbered list so the model is not pointed at an empty source.
        if not fetched and len(source.snippet or "") < 80:
            continue
        result.sources.append(source)
    return result

def build_context(result: ResearchResult, budget: int = 14000) -> str:
    """Formats sources for the model, numbering them for citations."""
    chunks: list[str] = []
    used = 0
    for source in result.sources:
        body = (source.text or source.snippet or "").strip()
        if not body:
            continue
        published = f"\nPublished: {source.published}" if source.published else ""
        block = (
            f"[{source.index}] {source.title}\nURL: {source.url}{published}\n{body[:2500]}\n"
        )
        if used + len(block) > budget:
            break
        chunks.append(block)
        used += len(block)
    return "\n---\n".join(chunks)


def citation_list(result: ResearchResult) -> list[dict]:
    return [source.as_dict() for source in result.sources]
