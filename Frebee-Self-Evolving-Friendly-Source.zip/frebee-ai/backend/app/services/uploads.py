from __future__ import annotations

import base64
import io
import mimetypes
import re
import shutil
import subprocess
import uuid
from pathlib import Path

from sqlalchemy.orm import Session

from ..config import get_settings
from ..models import UploadedFile, now_ms

TEXT_EXTENSIONS = {
    ".txt", ".md", ".markdown", ".rst", ".csv", ".tsv", ".json", ".yaml", ".yml",
    ".toml", ".ini", ".cfg", ".log", ".xml", ".html", ".htm", ".css", ".scss",
    ".js", ".jsx", ".ts", ".tsx", ".py", ".kt", ".kts", ".java", ".c", ".h",
    ".cpp", ".cs", ".go", ".rs", ".rb", ".php", ".sh", ".sql", ".gradle", ".swift",
}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}
BLOCKED_EXTENSIONS = {".exe", ".dll", ".so", ".dylib", ".bat", ".cmd", ".msi", ".apk", ".jar"}


class UploadError(Exception):
    pass


def safe_name(filename: str) -> str:
    name = Path(filename or "upload").name
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("._") or "upload"
    return name[:120]

def classify(name: str, mime: str) -> str:
    suffix = Path(name).suffix.lower()
    if mime.startswith("image/") or suffix in IMAGE_EXTENSIONS:
        return "image"
    if mime.startswith("audio/"):
        return "audio"
    if mime.startswith("video/"):
        return "video"
    if suffix in TEXT_EXTENSIONS:
        return "text"
    if mime in {"application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"}:
        return "document"
    return "file"


def validate(name: str, content: bytes, mime: str) -> str:
    settings = get_settings()
    suffix = Path(name).suffix.lower()
    if suffix in BLOCKED_EXTENSIONS:
        raise UploadError(f"{suffix} files cannot be uploaded. Attach source or text instead.")
    if not content:
        raise UploadError("The file is empty.")
    if len(content) > settings.max_upload_bytes:
        raise UploadError(
            f"File is larger than the {settings.max_upload_bytes // (1024 * 1024)} MB limit."
        )
    return classify(name, mime)

def ocr_image(path: Path, timeout: int = 25) -> str:
    """Reads text out of an image with tesseract, when it is installed.

    Screenshots of code, errors and documents are the common case for a phone camera.
    A vision model is better, but OCR is honest, local, free and works with any backend.
    """
    binary = shutil.which("tesseract")
    if not binary:
        return ""
    try:
        result = subprocess.run(
            [binary, str(path), "stdout", "--psm", "3"],
            capture_output=True,
            timeout=timeout,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    if result.returncode != 0:
        return ""
    text = result.stdout.decode("utf-8", "ignore").strip()
    # Tesseract "reads" noise as punctuation; a handful of characters is not evidence.
    letters = sum(character.isalnum() for character in text)
    return text[:100_000] if letters >= 12 else ""


def extract_text(path: Path, kind: str, mime: str) -> str:
    if kind == "image":
        return ocr_image(path)
    if kind == "text":
        return path.read_text("utf-8", "ignore")[:200_000]
    if mime == "application/pdf":
        try:
            from pypdf import PdfReader

            reader = PdfReader(str(path))
            return "\n".join((page.extract_text() or "") for page in reader.pages[:80])[:200_000]
        except Exception as exc:
            raise UploadError(f"Could not read the PDF: {exc}") from exc
    if mime.endswith("wordprocessingml.document"):
        try:
            import docx

            document = docx.Document(str(path))
            return "\n".join(paragraph.text for paragraph in document.paragraphs)[:200_000]
        except Exception as exc:
            raise UploadError(f"Could not read the document: {exc}") from exc
    return ""

def save_upload(db: Session, user_id: str, filename: str, content: bytes, mime: str = "") -> UploadedFile:
    name = safe_name(filename)
    mime = mime or mimetypes.guess_type(name)[0] or "application/octet-stream"
    kind = validate(name, content, mime)
    settings = get_settings()
    folder = settings.uploads_path / user_id
    folder.mkdir(parents=True, exist_ok=True)
    file_id = str(uuid.uuid4())
    path = folder / f"{file_id}_{name}"
    path.write_bytes(content)
    text_path = None
    text = ""
    try:
        text = extract_text(path, kind, mime)
    except UploadError:
        text = ""
    if text:
        text_path = folder / f"{file_id}.txt"
        text_path.write_text(text, "utf-8")
    record = UploadedFile(
        id=file_id,
        user_id=user_id,
        name=name,
        mime=mime,
        size=len(content),
        kind=kind,
        stored_path=str(path),
        text_path=str(text_path) if text_path else None,
        created_at=now_ms(),
    )
    db.add(record)
    db.commit()
    return record

def data_url(record: UploadedFile) -> str:
    raw = Path(record.stored_path).read_bytes()
    return f"data:{record.mime};base64,{base64.b64encode(raw).decode()}"


def attachment_context(records: list[UploadedFile], budget: int = 30_000) -> str:
    blocks: list[str] = []
    used = 0
    for record in records:
        has_text = bool(record.text_path and Path(record.text_path).exists())
        if record.kind == "image" and has_text:
            body = (
                "Text read from this image with OCR (may contain recognition errors):\n"
                + Path(record.text_path).read_text("utf-8", "ignore")
            )
        elif record.kind == "image":
            body = "(image attached; describe or analyse it directly)"
        elif has_text:
            body = Path(record.text_path).read_text("utf-8", "ignore")
        else:
            body = "(no text could be extracted from this file)"
        block = f"FILE: {record.name} ({record.mime}, {record.size} bytes)\n{body[:12_000]}"
        if used + len(block) > budget:
            blocks.append(f"FILE: {record.name} — omitted, attachment budget reached.")
            break
        blocks.append(block)
        used += len(block)
    return "\n\n".join(blocks)


def get_user_file(db: Session, user_id: str, file_id: str) -> UploadedFile:
    record = db.get(UploadedFile, file_id)
    if record is None or record.user_id != user_id:
        raise UploadError("File not found.")
    return record
