from __future__ import annotations

import json
import secrets
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import audit, mailer
from ..config import get_settings
from ..db import get_db
from ..deps import Principal, client_ip, get_principal, limiter
from ..models import (
    Conversation, EmailToken, Memory, Message, Project, ProviderCredential,
    RefreshSession, UploadedFile, User, ApiKey, now_ms,
)
from ..security import (
    create_token, decode_token, generate_opaque_token, hash_password, hash_token,
    password_problem, verify_password,
)

router = APIRouter(prefix="/v1/auth", tags=["auth"])
settings = get_settings()


def _auth_limit(request: Request) -> None:
    if not limiter.allow(f"auth:{client_ip(request)}", settings.auth_rate_limit_per_minute):
        raise HTTPException(status_code=429, detail="Too many authentication attempts. Wait a minute.")

class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=200)
    display_name: str = Field(default="", max_length=120)


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class TokenPair(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    user: dict


def user_public(user: User) -> dict:
    return {
        "id": user.id,
        "email": user.email,
        "display_name": user.display_name,
        "role": user.role,
        "email_verified": user.email_verified,
        "is_guest": user.is_guest,
        "memory_enabled": user.memory_enabled,
        "created_at": user.created_at,
    }


def _issue_tokens(db: Session, user: User, request: Request) -> TokenPair:
    access = create_token(user.id, kind="access", extra={"role": user.role})
    refresh_plain, refresh_hash = generate_opaque_token()
    db.add(RefreshSession(
        id=str(uuid.uuid4()), user_id=user.id, token_hash=refresh_hash,
        created_at=now_ms(), expires_at=now_ms() + settings.refresh_token_days * 86_400_000,
        user_agent=(request.headers.get("user-agent") or "")[:255], ip=client_ip(request),
    ))
    db.commit()
    return TokenPair(
        access_token=access, refresh_token=refresh_plain,
        expires_in=settings.access_token_minutes * 60, user=user_public(user),
    )

@router.post("/register", response_model=TokenPair, status_code=201)
def register(payload: RegisterIn, request: Request, db: Session = Depends(get_db)) -> TokenPair:
    _auth_limit(request)
    if not settings.allow_registration:
        raise HTTPException(status_code=403, detail="Registration is disabled on this server.")
    problem = password_problem(payload.password)
    if problem:
        raise HTTPException(status_code=400, detail=problem)
    email = payload.email.lower().strip()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(status_code=409, detail="An account with this email already exists.")
    user = User(
        id=str(uuid.uuid4()), email=email, password_hash=hash_password(payload.password),
        display_name=payload.display_name.strip() or email.split("@")[0],
        role="admin" if settings.admin_email and email == settings.admin_email.lower() else "user",
        email_verified=not settings.require_email_verification, created_at=now_ms(), updated_at=now_ms(),
    )
    db.add(user)
    db.commit()
    audit.record(db, "auth.register", user_id=user.id, target=email, ip=client_ip(request))
    if settings.require_email_verification:
        _send_email_token(db, user, "verify")
    return _issue_tokens(db, user, request)


@router.post("/login", response_model=TokenPair)
def login(payload: LoginIn, request: Request, db: Session = Depends(get_db)) -> TokenPair:
    _auth_limit(request)
    email = payload.email.lower().strip()
    user = db.scalar(select(User).where(User.email == email))
    if user is None or not user.password_hash or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Email or password is incorrect.")
    if user.disabled:
        raise HTTPException(status_code=403, detail="This account has been disabled.")
    audit.record(db, "auth.login", user_id=user.id, ip=client_ip(request))
    return _issue_tokens(db, user, request)

def _send_email_token(db: Session, user: User, kind: str) -> str:
    plain, hashed = generate_opaque_token()
    ttl_minutes = 60 if kind == "verify" else 30
    db.add(EmailToken(
        id=str(uuid.uuid4()), user_id=user.id, kind=kind, token_hash=hashed,
        created_at=now_ms(), expires_at=now_ms() + ttl_minutes * 60_000,
    ))
    db.commit()
    link = mailer.verification_link(plain) if kind == "verify" else mailer.reset_link(plain)
    mailer.send_email(user.email, f"Frebee: {kind} your account", f"Open this link:\n{link}\n")
    return plain


class RefreshIn(BaseModel):
    refresh_token: str


@router.post("/refresh", response_model=TokenPair)
def refresh(payload: RefreshIn, request: Request, db: Session = Depends(get_db)) -> TokenPair:
    _auth_limit(request)
    record = db.scalar(select(RefreshSession).where(RefreshSession.token_hash == hash_token(payload.refresh_token)))
    if record is None or record.revoked_at is not None or record.expires_at < now_ms():
        raise HTTPException(status_code=401, detail="Session expired. Sign in again.")
    user = db.get(User, record.user_id)
    if user is None or user.disabled:
        raise HTTPException(status_code=401, detail="Account not available.")
    record.revoked_at = now_ms()
    db.commit()
    return _issue_tokens(db, user, request)


@router.post("/logout", status_code=204)
def logout(payload: RefreshIn, db: Session = Depends(get_db)) -> Response:
    record = db.scalar(select(RefreshSession).where(RefreshSession.token_hash == hash_token(payload.refresh_token)))
    if record and record.revoked_at is None:
        record.revoked_at = now_ms()
        db.commit()
    return Response(status_code=204)

class TokenIn(BaseModel):
    token: str


@router.post("/verify-email")
def verify_email(payload: TokenIn, db: Session = Depends(get_db)) -> dict:
    hashed = hash_token(payload.token)
    record = db.scalar(select(EmailToken).where(EmailToken.token_hash == hashed, EmailToken.kind == "verify"))
    if record is None or record.used_at is not None or record.expires_at < now_ms():
        raise HTTPException(status_code=400, detail="This verification link is invalid or expired.")
    user = db.get(User, record.user_id)
    if user is None:
        raise HTTPException(status_code=400, detail="Account not found.")
    record.used_at = now_ms()
    user.email_verified = True
    user.updated_at = now_ms()
    db.commit()
    audit.record(db, "auth.verify_email", user_id=user.id)
    return {"verified": True}


@router.post("/resend-verification", status_code=202)
def resend_verification(principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    if principal.user.email_verified:
        return {"sent": False, "detail": "Email already verified."}
    _send_email_token(db, principal.user, "verify")
    return {"sent": True, "detail": "Check your inbox (or the server log in local mode)."}


@router.post("/password-reset/request", status_code=202)
def request_password_reset(payload: dict, request: Request, db: Session = Depends(get_db)) -> dict:
    _auth_limit(request)
    email = str(payload.get("email", "")).lower().strip()
    user = db.scalar(select(User).where(User.email == email))
    if user and not user.is_guest:
        _send_email_token(db, user, "reset")
    # Always the same answer: no account enumeration.
    return {"detail": "If that address exists, a reset link has been sent."}


@router.post("/password-reset/confirm")
def confirm_password_reset(payload: dict, db: Session = Depends(get_db)) -> dict:
    token = str(payload.get("token", ""))
    password = str(payload.get("password", ""))
    problem = password_problem(password)
    if problem:
        raise HTTPException(status_code=400, detail=problem)
    record = db.scalar(select(EmailToken).where(EmailToken.token_hash == hash_token(token), EmailToken.kind == "reset"))
    if record is None or record.used_at is not None or record.expires_at < now_ms():
        raise HTTPException(status_code=400, detail="This reset link is invalid or expired.")
    user = db.get(User, record.user_id)
    if user is None:
        raise HTTPException(status_code=400, detail="Account not found.")
    record.used_at = now_ms()
    user.password_hash = hash_password(password)
    user.updated_at = now_ms()
    for session in db.scalars(select(RefreshSession).where(RefreshSession.user_id == user.id)).all():
        session.revoked_at = now_ms()
    db.commit()
    audit.record(db, "auth.password_reset", user_id=user.id)
    return {"reset": True}

@router.get("/me")
def me(principal: Principal = Depends(get_principal)) -> dict:
    return user_public(principal.user)


@router.patch("/me")
def update_me(payload: dict, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    user = principal.user
    if "display_name" in payload:
        user.display_name = str(payload["display_name"])[:120]
    if "memory_enabled" in payload:
        user.memory_enabled = bool(payload["memory_enabled"])
    if "password" in payload and payload["password"]:
        problem = password_problem(str(payload["password"]))
        if problem:
            raise HTTPException(status_code=400, detail=problem)
        user.password_hash = hash_password(str(payload["password"]))
        for session in db.scalars(select(RefreshSession).where(RefreshSession.user_id == user.id)).all():
            session.revoked_at = now_ms()
    user.updated_at = now_ms()
    db.commit()
    return user_public(user)


@router.get("/sessions")
def list_sessions(principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> list[dict]:
    rows = db.scalars(
        select(RefreshSession)
        .where(RefreshSession.user_id == principal.user.id)
        .order_by(RefreshSession.created_at.desc())
    ).all()
    return [
        {
            "id": row.id,
            "created_at": row.created_at,
            "expires_at": row.expires_at,
            "revoked": row.revoked_at is not None,
            "user_agent": row.user_agent,
            "ip": row.ip,
        }
        for row in rows[:50]
    ]

@router.delete("/sessions/{session_id}", status_code=204)
def revoke_session(session_id: str, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> Response:
    record = db.get(RefreshSession, session_id)
    if record is None or record.user_id != principal.user.id:
        raise HTTPException(status_code=404, detail="Session not found.")
    record.revoked_at = now_ms()
    db.commit()
    return Response(status_code=204)


@router.post("/guest", response_model=TokenPair)
def guest(request: Request, db: Session = Depends(get_db)) -> TokenPair:
    _auth_limit(request)
    if not settings.allow_guest:
        raise HTTPException(status_code=403, detail="Guest mode is disabled on this server.")
    user = User(
        id=str(uuid.uuid4()), email=f"guest-{secrets.token_hex(6)}@guest.frebee.local",
        password_hash="", display_name="Guest", is_guest=True, email_verified=False,
        memory_enabled=False, created_at=now_ms(), updated_at=now_ms(),
    )
    db.add(user)
    db.commit()
    audit.record(db, "auth.guest", user_id=user.id, ip=client_ip(request))
    return _issue_tokens(db, user, request)

@router.get("/export")
def export_data(principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    user = principal.user
    conversations = db.scalars(select(Conversation).where(Conversation.user_id == user.id)).all()
    messages = db.scalars(select(Message).where(Message.user_id == user.id)).all()
    memories = db.scalars(select(Memory).where(Memory.user_id == user.id)).all()
    projects = db.scalars(select(Project).where(Project.user_id == user.id)).all()
    files = db.scalars(select(UploadedFile).where(UploadedFile.user_id == user.id)).all()
    return {
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "account": user_public(user),
        "conversations": [
            {"id": c.id, "title": c.title, "created_at": c.created_at, "archived": c.archived}
            for c in conversations
        ],
        "messages": [
            {"conversation_id": m.conversation_id, "role": m.role, "content": m.content, "created_at": m.created_at}
            for m in messages
        ],
        "memories": [{"scope": m.scope, "key": m.key, "value": m.value} for m in memories],
        "projects": [{"id": p.id, "name": p.name, "kind": p.kind} for p in projects],
        "files": [{"id": f.id, "name": f.name, "size": f.size, "mime": f.mime} for f in files],
        "note": "Provider API keys are stored encrypted and are never included in exports.",
    }

@router.delete("/me", status_code=204)
def delete_account(payload: dict, request: Request, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> Response:
    user = principal.user
    if not user.is_guest:
        if not verify_password(str(payload.get("password", "")), user.password_hash):
            raise HTTPException(status_code=403, detail="Password confirmation failed.")
    user_id = user.id
    for model in (Message, Conversation, Memory, Project, UploadedFile, ProviderCredential, ApiKey, RefreshSession, EmailToken):
        for row in db.scalars(select(model).where(model.user_id == user_id)).all():
            db.delete(row)
    db.delete(user)
    db.commit()
    audit.record(db, "auth.delete_account", user_id=user_id, ip=client_ip(request))
    return Response(status_code=204)
