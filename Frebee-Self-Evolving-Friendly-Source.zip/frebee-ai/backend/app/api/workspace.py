from __future__ import annotations

import io
import shutil
import uuid
import zipfile
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import get_db
from ..deps import Principal, get_principal
from ..models import Memory, Project, UploadedFile, User, now_ms
from ..services import builder, coding_agent, sandbox, uploads

router = APIRouter(tags=["workspace"])
settings = get_settings()


def _own_project(db: Session, user: User, project_id: str) -> Project:
    project = db.get(Project, project_id)
    if project is None or project.user_id != user.id:
        raise HTTPException(status_code=404, detail="Project not found.")
    return project


def file_public(record: UploadedFile) -> dict:
    return {
        "id": record.id,
        "name": record.name,
        "mime": record.mime,
        "size": record.size,
        "kind": record.kind,
        "has_text": bool(record.text_path),
        "created_at": record.created_at,
    }


@router.post("/v1/files", status_code=201)
async def upload_file(
    file: UploadFile = File(...),
    principal: Principal = Depends(get_principal),
    db: Session = Depends(get_db),
) -> dict:
    content = await file.read()
    try:
        record = uploads.save_upload(db, principal.user.id, file.filename or "upload", content, file.content_type or "")
    except uploads.UploadError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return file_public(record)


@router.get("/v1/files")
def list_files(principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    rows = db.scalars(
        select(UploadedFile)
        .where(UploadedFile.user_id == principal.user.id)
        .order_by(UploadedFile.created_at.desc())
        .limit(200)
    ).all()
    return {"items": [file_public(row) for row in rows]}


@router.get("/v1/files/{file_id}/text")
def file_text(file_id: str, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    try:
        record = uploads.get_user_file(db, principal.user.id, file_id)
    except uploads.UploadError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    text = ""
    if record.text_path and Path(record.text_path).exists():
        text = Path(record.text_path).read_text("utf-8", "ignore")[:100_000]
    return {"id": record.id, "name": record.name, "text": text}


@router.get("/v1/files/{file_id}/download")
def file_download(file_id: str, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)):
    try:
        record = uploads.get_user_file(db, principal.user.id, file_id)
    except uploads.UploadError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    path = Path(record.stored_path)
    if not path.exists():
        raise HTTPException(status_code=410, detail="This file is no longer stored on the server.")
    return FileResponse(path, filename=record.name, media_type=record.mime)


@router.delete("/v1/files/{file_id}", status_code=204)
def delete_file(file_id: str, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)):
    try:
        record = uploads.get_user_file(db, principal.user.id, file_id)
    except uploads.UploadError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    for path in (record.stored_path, record.text_path):
        if path:
            Path(path).unlink(missing_ok=True)
    db.delete(record)
    db.commit()
    return None


class MemoryIn(BaseModel):
    scope: str = Field(default="user", pattern="^(user|project|conversation)$")
    key: str = Field(min_length=1, max_length=120)
    value: str = Field(min_length=1, max_length=4000)
    scope_id: str | None = None


@router.get("/v1/memory")
def list_memory(q: str | None = None, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    query = select(Memory).where(Memory.user_id == principal.user.id)
    if q:
        query = query.where(Memory.value.ilike(f"%{q}%"))
    rows = db.scalars(query.order_by(Memory.updated_at.desc()).limit(200)).all()
    return {
        "memory_enabled": principal.user.memory_enabled,
        "items": [
            {"id": r.id, "scope": r.scope, "scope_id": r.scope_id, "key": r.key, "value": r.value, "updated_at": r.updated_at}
            for r in rows
        ],
    }


class MemorySettingsIn(BaseModel):
    enabled: bool


@router.put("/v1/memory/settings")
def update_memory_settings(
    payload: MemorySettingsIn,
    principal: Principal = Depends(get_principal),
    db: Session = Depends(get_db),
) -> dict:
    """Turns persistent memory on or off for the account."""
    principal.user.memory_enabled = payload.enabled
    db.commit()
    return {"memory_enabled": payload.enabled}


@router.put("/v1/memory")
def upsert_memory(payload: MemoryIn, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    existing = db.scalar(
        select(Memory).where(
            Memory.user_id == principal.user.id,
            Memory.scope == payload.scope,
            Memory.key == payload.key,
        )
    )
    if existing:
        existing.value = payload.value
        existing.scope_id = payload.scope_id
        existing.updated_at = now_ms()
        db.commit()
        return {"id": existing.id, "updated": True}
    row = Memory(
        id=str(uuid.uuid4()), user_id=principal.user.id, scope=payload.scope,
        scope_id=payload.scope_id, key=payload.key, value=payload.value, updated_at=now_ms(),
    )
    db.add(row)
    db.commit()
    return {"id": row.id, "updated": False}


@router.delete("/v1/memory/{memory_id}", status_code=204)
def delete_memory(memory_id: str, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)):
    row = db.get(Memory, memory_id)
    if row is None or row.user_id != principal.user.id:
        raise HTTPException(status_code=404, detail="Memory entry not found.")
    db.delete(row)
    db.commit()
    return None


class ProjectIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    kind: str = Field(default="web", pattern="^(web|api|python|android|other)$")
    description: str = Field(default="", max_length=2000)


def project_public(project: Project) -> dict:
    return {
        "id": project.id,
        "name": project.name,
        "kind": project.kind,
        "description": project.description,
        "created_at": project.created_at,
        "updated_at": project.updated_at,
        "last_task": project.last_task,
    }


@router.get("/v1/projects")
def list_projects(principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    rows = db.scalars(
        select(Project)
        .where(Project.user_id == principal.user.id)
        .order_by(Project.updated_at.desc())
        .limit(100)
    ).all()
    return {"items": [project_public(row) for row in rows]}


@router.post("/v1/projects", status_code=201)
def create_project(payload: ProjectIn, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    project_id = str(uuid.uuid4())
    root = settings.projects_path / principal.user.id / project_id
    root.mkdir(parents=True, exist_ok=True)
    project = Project(
        id=project_id, user_id=principal.user.id, name=payload.name, kind=payload.kind,
        description=payload.description, root_path=str(root), created_at=now_ms(), updated_at=now_ms(),
    )
    db.add(project)
    db.commit()
    created = builder.scaffold(project)
    project.updated_at = now_ms()
    db.commit()
    return {**project_public(project), "scaffolded": created}


@router.get("/v1/projects/{project_id}")
def get_project(project_id: str, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    project = _own_project(db, principal.user, project_id)
    return {**project_public(project), "files": sandbox.list_files(Path(project.root_path))}


@router.patch("/v1/projects/{project_id}")
def update_project(project_id: str, payload: dict, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    project = _own_project(db, principal.user, project_id)
    if "name" in payload:
        project.name = str(payload["name"])[:120]
    if "description" in payload:
        project.description = str(payload["description"])[:2000]
    project.updated_at = now_ms()
    db.commit()
    return project_public(project)


@router.delete("/v1/projects/{project_id}", status_code=204)
def delete_project(project_id: str, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)):
    project = _own_project(db, principal.user, project_id)
    shutil.rmtree(project.root_path, ignore_errors=True)
    db.delete(project)
    db.commit()
    return None


@router.get("/v1/projects/{project_id}/file")
def read_project_file(
    project_id: str,
    path: str = Query(min_length=1),
    principal: Principal = Depends(get_principal),
    db: Session = Depends(get_db),
) -> dict:
    project = _own_project(db, principal.user, project_id)
    try:
        content = sandbox.read_file(Path(project.root_path), path)
    except sandbox.SandboxError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"path": path, "content": content}


class FileWriteIn(BaseModel):
    path: str = Field(min_length=1, max_length=400)
    content: str = Field(max_length=400_000)


@router.put("/v1/projects/{project_id}/file")
def write_project_file(project_id: str, payload: FileWriteIn, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    project = _own_project(db, principal.user, project_id)
    try:
        sandbox.write_file(Path(project.root_path), payload.path, payload.content)
    except sandbox.SandboxError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    project.updated_at = now_ms()
    db.commit()
    return {"path": payload.path, "written": True}


class RunIn(BaseModel):
    command: str = Field(min_length=1, max_length=2000)
    timeout: int | None = Field(default=None, ge=1, le=300)


@router.post("/v1/projects/{project_id}/run")
def run_project_command(project_id: str, payload: RunIn, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    project = _own_project(db, principal.user, project_id)
    try:
        result = sandbox.run(payload.command, Path(project.root_path), timeout=payload.timeout)
    except sandbox.SandboxError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return result.as_dict()


class AgentIn(BaseModel):
    task: str = Field(min_length=3, max_length=8000)
    model: str | None = None
    provider: str | None = None
    max_steps: int = Field(default=8, ge=1, le=20)


@router.post("/v1/projects/{project_id}/agent")
async def run_agent(project_id: str, payload: AgentIn, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    project = _own_project(db, principal.user, project_id)
    result = await coding_agent.run_task(
        db, principal.user, project, payload.task,
        model=payload.model, provider_kind=payload.provider, max_steps=payload.max_steps,
    )
    return result.as_dict()


@router.get("/v1/projects/{project_id}/archive")
def download_archive(project_id: str, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)):
    project = _own_project(db, principal.user, project_id)
    root = Path(project.root_path)
    if not root.exists():
        raise HTTPException(status_code=404, detail="Project workspace is missing.")
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(root.rglob("*")):
            if any(part in {".git", "node_modules", "__pycache__", ".venv"} for part in path.parts):
                continue
            if path.is_file():
                archive.write(path, path.relative_to(root))
    buffer.seek(0)
    safe = "".join(ch for ch in project.name if ch.isalnum() or ch in "-_") or "project"
    return Response(
        content=buffer.getvalue(),
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{safe}.zip"'},
    )
