"""HTTP routers for the Frebee backend."""
