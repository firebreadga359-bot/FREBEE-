from __future__ import annotations

import json
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import Principal, get_principal, limiter
from ..models import Conversation, Message, User, now_ms
from ..services import orchestrator

router = APIRouter(tags=["chat"])

MAX_MESSAGE_CHARS = 60_000


def own_conversation(db: Session, user: User, conversation_id: str) -> Conversation:
    conversation = db.get(Conversation, conversation_id)
    if conversation is None or conversation.user_id != user.id:
        raise HTTPException(status_code=404, detail="Conversation not found.")
    return conversation


def message_public(message: Message) -> dict:
    return {
        "id": message.id,
        "role": message.role,
        "content": message.content,
        "created_at": message.created_at,
        "model": message.model,
        "citations": json.loads(message.citations_json or "[]"),
        "attachments": json.loads(message.attachments_json or "[]"),
        "error": message.error,
    }

@router.get("/v1/conversations")
def list_conversations(
    archived: bool = False,
    q: str | None = None,
    limit: int = Query(default=30, le=100),
    offset: int = Query(default=0, ge=0),
    principal: Principal = Depends(get_principal),
    db: Session = Depends(get_db),
) -> dict:
    query = select(Conversation).where(
        Conversation.user_id == principal.user.id, Conversation.archived == archived
    )
    if q:
        pattern = f"%{q.strip()}%"
        matching = select(Message.conversation_id).where(
            Message.user_id == principal.user.id, Message.content.ilike(pattern)
        )
        query = query.where(or_(Conversation.title.ilike(pattern), Conversation.id.in_(matching)))
    rows = db.scalars(
        query.order_by(Conversation.updated_at.desc()).limit(limit).offset(offset)
    ).all()
    return {
        "items": [
            {
                "id": row.id,
                "title": row.title,
                "created_at": row.created_at,
                "updated_at": row.updated_at,
                "archived": row.archived,
                "project_id": row.project_id,
                "model": row.model,
            }
            for row in rows
        ],
        "limit": limit,
        "offset": offset,
    }

class ConversationIn(BaseModel):
    title: str = Field(default="New chat", max_length=200)
    project_id: str | None = None


@router.post("/v1/conversations", status_code=201)
def create_conversation(payload: ConversationIn, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    conversation = Conversation(
        id=str(uuid.uuid4()), user_id=principal.user.id, title=payload.title or "New chat",
        project_id=payload.project_id, created_at=now_ms(), updated_at=now_ms(),
    )
    db.add(conversation)
    db.commit()
    return {"id": conversation.id, "title": conversation.title, "project_id": conversation.project_id}


@router.get("/v1/conversations/{conversation_id}")
def get_conversation(conversation_id: str, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    conversation = own_conversation(db, principal.user, conversation_id)
    messages = db.scalars(
        select(Message).where(Message.conversation_id == conversation.id).order_by(Message.created_at)
    ).all()
    return {
        "id": conversation.id,
        "title": conversation.title,
        "archived": conversation.archived,
        "project_id": conversation.project_id,
        "model": conversation.model,
        "created_at": conversation.created_at,
        "updated_at": conversation.updated_at,
        "messages": [message_public(message) for message in messages],
    }

@router.patch("/v1/conversations/{conversation_id}")
def update_conversation(conversation_id: str, payload: dict, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    conversation = own_conversation(db, principal.user, conversation_id)
    if "title" in payload:
        title = str(payload["title"]).strip()
        if not title:
            raise HTTPException(status_code=400, detail="Title cannot be empty.")
        conversation.title = title[:200]
    if "archived" in payload:
        conversation.archived = bool(payload["archived"])
    if "project_id" in payload:
        conversation.project_id = payload["project_id"] or None
    conversation.updated_at = now_ms()
    db.commit()
    return {"id": conversation.id, "title": conversation.title, "archived": conversation.archived}


@router.delete("/v1/conversations/{conversation_id}", status_code=204)
def delete_conversation(conversation_id: str, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)):
    conversation = own_conversation(db, principal.user, conversation_id)
    for message in db.scalars(select(Message).where(Message.conversation_id == conversation.id)).all():
        db.delete(message)
    db.delete(conversation)
    db.commit()
    return None


@router.delete("/v1/conversations/{conversation_id}/messages/{message_id}", status_code=204)
def delete_message(conversation_id: str, message_id: str, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)):
    own_conversation(db, principal.user, conversation_id)
    message = db.get(Message, message_id)
    if message is None or message.user_id != principal.user.id or message.conversation_id != conversation_id:
        raise HTTPException(status_code=404, detail="Message not found.")
    db.delete(message)
    db.commit()
    return None

class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=MAX_MESSAGE_CHARS)
    conversation_id: str | None = None
    mode: str = "balanced"
    model: str | None = None
    provider: str | None = None
    attachment_ids: list[str] = Field(default_factory=list)
    research: bool | None = None
    title: str | None = None


def _prepare(db: Session, user: User, payload: ChatIn) -> Conversation:
    if payload.conversation_id:
        conversation = own_conversation(db, user, payload.conversation_id)
    else:
        conversation = Conversation(
            id=str(uuid.uuid4()), user_id=user.id,
            title=(payload.title or payload.message.strip()[:60] or "New chat"),
            created_at=now_ms(), updated_at=now_ms(),
        )
        db.add(conversation)
        db.commit()
    if conversation.title in {"New chat", ""}:
        conversation.title = payload.message.strip()[:60] or "New chat"
        db.commit()
    return conversation


def _sse(event: dict) -> str:
    return f"data: {json.dumps(event)}\n\n"

@router.post("/v1/chat/stream")
async def chat_stream(payload: ChatIn, request: Request, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)):
    if not limiter.allow(f"chat:{principal.user.id}", 60):
        raise HTTPException(status_code=429, detail="Slow down: too many chat requests per minute.")
    conversation = _prepare(db, principal.user, payload)
    conversation_id = conversation.id

    async def generator():
        yield _sse({"type": "conversation", "conversation_id": conversation_id})
        try:
            async for event in orchestrator.stream_reply(
                db, principal.user, conversation, payload.message,
                mode=payload.mode, model=payload.model, provider_kind=payload.provider,
                attachment_ids=payload.attachment_ids, use_research=payload.research,
            ):
                yield _sse(event)
        except Exception as exc:  # noqa: BLE001
            yield _sse({"type": "error", "message": f"Server error: {exc.__class__.__name__}"})
        yield _sse({"type": "done_stream"})

    return StreamingResponse(
        generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.post("/v1/chat")
async def chat_once(payload: ChatIn, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    if not limiter.allow(f"chat:{principal.user.id}", 60):
        raise HTTPException(status_code=429, detail="Slow down: too many chat requests per minute.")
    conversation = _prepare(db, principal.user, payload)
    text_parts: list[str] = []
    final: dict = {}
    error = ""
    async for event in orchestrator.stream_reply(
        db, principal.user, conversation, payload.message,
        mode=payload.mode, model=payload.model, provider_kind=payload.provider,
        attachment_ids=payload.attachment_ids, use_research=payload.research,
    ):
        if event["type"] == "delta":
            text_parts.append(event["text"])
        elif event["type"] == "done":
            final = event
        elif event["type"] == "error":
            error = event["message"]
    return {
        "conversation_id": conversation.id,
        "text": "".join(text_parts),
        "citations": final.get("citations", []),
        "usage": final.get("usage", {}),
        "provider": final.get("provider"),
        "model": final.get("model"),
        "error": error,
    }

