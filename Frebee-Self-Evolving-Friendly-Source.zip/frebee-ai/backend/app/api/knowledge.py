from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import Principal, get_principal
from ..models import KnowledgeSource
from ..services import research as research_service
from ..services import retrieval, uploads

router = APIRouter(tags=["knowledge"])


def source_public(source: KnowledgeSource) -> dict:
    return {
        "id": source.id,
        "kind": source.kind,
        "location": source.location,
        "title": source.title,
        "status": source.status,
        "chunk_count": source.chunk_count,
        "created_at": source.created_at,
        "updated_at": source.updated_at,
    }



@router.get("/v1/knowledge")
def list_sources(principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    rows = db.scalars(
        select(KnowledgeSource)
        .where(KnowledgeSource.user_id == principal.user.id)
        .order_by(KnowledgeSource.created_at.desc())
        .limit(200)
    ).all()
    return {"items": [source_public(row) for row in rows]}


class UrlIn(BaseModel):
    url: str = Field(min_length=8, max_length=2000)


@router.post("/v1/knowledge/url", status_code=201)
async def add_url(payload: UrlIn, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    try:
        title, text = await research_service.fetch_page(payload.url)
    except research_service.SearchUnavailable as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if not text.strip():
        raise HTTPException(status_code=422, detail="No readable text was found on that page.")
    source = retrieval.index_source(db, principal.user.id, "url", payload.url, title, text)
    return source_public(source)


class TextIn(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    text: str = Field(min_length=1, max_length=400_000)


@router.post("/v1/knowledge/text", status_code=201)
def add_text(payload: TextIn, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    source = retrieval.index_source(db, principal.user.id, "text", f"note:{payload.title}", payload.title, payload.text)
    return source_public(source)


class FileIn(BaseModel):
    file_id: str


@router.post("/v1/knowledge/file", status_code=201)
def add_file(payload: FileIn, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    try:
        record = uploads.get_user_file(db, principal.user.id, payload.file_id)
    except uploads.UploadError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    if not record.text_path or not Path(record.text_path).exists():
        raise HTTPException(
            status_code=422,
            detail="This file has no extractable text. Try a text, PDF, or Word document.",
        )
    text = Path(record.text_path).read_text("utf-8", "ignore")
    source = retrieval.index_source(db, principal.user.id, "file", record.name, record.name, text)
    return source_public(source)


class SearchIn(BaseModel):
    query: str = Field(min_length=2, max_length=2000)
    limit: int = Field(default=6, ge=1, le=20)


@router.post("/v1/knowledge/search")
def search_knowledge(payload: SearchIn, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    hits = retrieval.search(db, principal.user.id, payload.query, limit=payload.limit)
    return {
        "items": [
            {
                "chunk_id": hit.chunk_id,
                "source_id": hit.source_id,
                "title": hit.title,
                "location": hit.location,
                "content": hit.content,
                "score": round(hit.score, 3),
            }
            for hit in hits
        ]
    }


@router.delete("/v1/knowledge/{source_id}", status_code=204)
def delete_source(source_id: str, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)):
    if not retrieval.delete_source(db, principal.user.id, source_id):
        raise HTTPException(status_code=404, detail="Knowledge source not found.")
    return None


class ResearchIn(BaseModel):
    query: str = Field(min_length=3, max_length=2000)
    limit: int = Field(default=5, ge=1, le=10)


@router.post("/v1/research")
async def run_research(payload: ResearchIn, principal: Principal = Depends(get_principal)) -> dict:
    provider = research_service.configured_search_provider()
    if not provider:
        raise HTTPException(
            status_code=503,
            detail="No search provider is configured. Set TAVILY_API_KEY, BRAVE_API_KEY, or SEARXNG_URL.",
        )
    result = await research_service.research(payload.query, limit=payload.limit)
    return {
        "provider": result.provider or provider,
        "usable": result.usable,
        "errors": result.errors,
        "sources": research_service.citation_list(result),
        "context": research_service.build_context(result)[:20_000],
    }
