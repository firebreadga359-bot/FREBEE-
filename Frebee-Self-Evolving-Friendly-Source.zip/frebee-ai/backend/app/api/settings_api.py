from __future__ import annotations

import uuid

import httpx
from fastapi import APIRouter, Depends, File, HTTPException, Query, Response, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import audit
from ..config import get_settings
from ..db import get_db
from ..deps import Principal, get_principal, require_admin
from ..models import ApiKey, ProviderCredential, UsageRecord, User, now_ms
from ..providers import registry
from ..providers.base import ProviderError
from ..security import encrypt_secret, generate_api_key, mask_secret
from ..services import evals as evals_service

router = APIRouter(tags=["settings"])
settings = get_settings()

VALID_KINDS = {"openai", "anthropic", "gemini", "local"}


@router.get("/v1/providers")
def list_providers(principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    return {"items": registry.status_for(db, principal.user)}


class CredentialIn(BaseModel):
    kind: str
    api_key: str = Field(default="", max_length=400)
    base_url: str = Field(default="", max_length=300)
    default_model: str = Field(default="", max_length=120)
    label: str = Field(default="", max_length=120)


@router.post("/v1/providers/credentials", status_code=201)
async def add_credential(payload: CredentialIn, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    kind = payload.kind.lower().strip()
    if kind not in VALID_KINDS:
        raise HTTPException(status_code=400, detail=f"Unsupported provider '{payload.kind}'.")
    if kind != "local" and not payload.api_key.strip():
        raise HTTPException(status_code=400, detail="An API key is required for this provider.")
    if kind == "local" and not payload.base_url.strip():
        raise HTTPException(status_code=400, detail="A base URL is required for a local endpoint.")
    provider = registry.build_provider(kind, payload.api_key.strip(), payload.base_url.strip(), payload.default_model.strip())
    ok, message, models = await provider.test()
    row = ProviderCredential(
        id=str(uuid.uuid4()), user_id=principal.user.id, kind=kind,
        label=payload.label or registry.PROVIDER_LABELS.get(kind, kind),
        base_url=payload.base_url.strip() or None,
        secret_encrypted=encrypt_secret(payload.api_key.strip()) if payload.api_key.strip() else "",
        masked_key=mask_secret(payload.api_key.strip()) if payload.api_key.strip() else "(none)",
        default_model=payload.default_model.strip() or (models[0] if models else None),
        status="ok" if ok else "error",
        last_error=None if ok else message[:300],
        created_at=now_ms(),
    )
    db.add(row)
    db.commit()
    audit.record(db, "provider.credential_added", user_id=principal.user.id, target=kind)
    return {
        "id": row.id,
        "kind": kind,
        "status": row.status,
        "default_model": row.default_model,
        "message": message,
        "models": models[:20],
    }


def _own_credential(db: Session, user: User, credential_id: str) -> ProviderCredential:
    row = db.get(ProviderCredential, credential_id)
    if row is None or row.user_id != user.id:
        raise HTTPException(status_code=404, detail="Credential not found.")
    return row


@router.post("/v1/providers/credentials/{credential_id}/test")
async def test_credential(credential_id: str, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    row = _own_credential(db, principal.user, credential_id)
    from ..security import decrypt_secret

    secret = decrypt_secret(row.secret_encrypted) if row.secret_encrypted else ""
    provider = registry.build_provider(row.kind, secret, row.base_url or "", row.default_model or "")
    ok, message, models = await provider.test()
    row.status = "ok" if ok else "error"
    row.last_error = None if ok else message[:300]
    db.commit()
    return {"ok": ok, "message": message, "models": models[:30]}


@router.patch("/v1/providers/credentials/{credential_id}")
def update_credential(credential_id: str, payload: dict, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    row = _own_credential(db, principal.user, credential_id)
    if "default_model" in payload:
        row.default_model = str(payload["default_model"])[:120] or None
    if "label" in payload:
        row.label = str(payload["label"])[:120]
    if payload.get("is_default"):
        for other in db.scalars(select(ProviderCredential).where(ProviderCredential.user_id == principal.user.id)).all():
            other.is_default = other.id == row.id
    db.commit()
    return {"id": row.id, "default_model": row.default_model, "is_default": row.is_default}


@router.delete("/v1/providers/credentials/{credential_id}", status_code=204)
def delete_credential(credential_id: str, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)):
    row = _own_credential(db, principal.user, credential_id)
    db.delete(row)
    db.commit()
    audit.record(db, "provider.credential_removed", user_id=principal.user.id, target=row.kind)
    return None


@router.get("/v1/models")
async def list_models(
    provider: str | None = Query(default=None),
    principal: Principal = Depends(get_principal),
    db: Session = Depends(get_db),
) -> dict:
    try:
        candidates = registry.resolve(db, principal.user, provider)
    except registry.ProviderUnavailable as exc:
        return {"items": [], "detail": str(exc)}
    items: list[dict] = []
    errors: list[str] = []
    for candidate in candidates[:3]:
        if candidate.kind == "mock":
            continue
        try:
            for model in await candidate.provider.list_models():
                entry = model.as_dict()
                entry["source"] = candidate.source
                items.append(entry)
        except ProviderError as exc:
            errors.append(f"{candidate.kind}: {exc.message}")
        except Exception as exc:  # network failure while discovering models
            errors.append(f"{candidate.kind}: {exc.__class__.__name__}")
    return {"items": items[:100], "errors": errors}


class ApiKeyIn(BaseModel):
    label: str = Field(default="Frebee key", max_length=120)
    scopes: list[str] = Field(default_factory=lambda: ["chat.read", "chat.write"])


@router.get("/v1/api-keys")
def list_api_keys(principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    rows = db.scalars(
        select(ApiKey).where(ApiKey.user_id == principal.user.id).order_by(ApiKey.created_at.desc())
    ).all()
    return {
        "items": [
            {
                "id": row.id,
                "label": row.label,
                "prefix": row.prefix,
                "scopes": [s for s in (row.scopes or "").split(",") if s],
                "created_at": row.created_at,
                "last_used_at": row.last_used_at,
                "request_count": row.request_count,
                "revoked": row.revoked_at is not None,
            }
            for row in rows
        ],
        "note": "Only a hash is stored. A new key's secret is shown once, at creation.",
    }


@router.post("/v1/api-keys", status_code=201)
def create_api_key(payload: ApiKeyIn, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    if principal.user.is_guest:
        raise HTTPException(status_code=403, detail="Create a free account to generate API keys.")
    plaintext, prefix, hashed = generate_api_key()
    allowed = {"chat.read", "chat.write", "files.read", "files.write", "projects.read", "projects.write"}
    scopes = [scope for scope in payload.scopes if scope in allowed] or ["chat.read", "chat.write"]
    row = ApiKey(
        id=str(uuid.uuid4()), user_id=principal.user.id, label=payload.label,
        prefix=prefix, key_hash=hashed, scopes=",".join(scopes), created_at=now_ms(),
    )
    db.add(row)
    db.commit()
    audit.record(db, "apikey.created", user_id=principal.user.id, target=prefix)
    return {
        "id": row.id,
        "label": row.label,
        "prefix": prefix,
        "scopes": scopes,
        "secret": plaintext,
        "warning": "Store this secret now. It cannot be shown again.",
    }


@router.delete("/v1/api-keys/{key_id}", status_code=204)
def revoke_api_key(key_id: str, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)):
    row = db.get(ApiKey, key_id)
    if row is None or row.user_id != principal.user.id:
        raise HTTPException(status_code=404, detail="API key not found.")
    row.revoked_at = now_ms()
    db.commit()
    audit.record(db, "apikey.revoked", user_id=principal.user.id, target=row.prefix)
    return None


@router.get("/v1/usage")
def usage(principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    rows = db.scalars(
        select(UsageRecord).where(UsageRecord.user_id == principal.user.id).order_by(UsageRecord.created_at.desc()).limit(500)
    ).all()
    prompt = sum(row.prompt_tokens for row in rows)
    completion = sum(row.completion_tokens for row in rows)
    by_model: dict[str, int] = {}
    for row in rows:
        by_model[row.model or row.provider] = by_model.get(row.model or row.provider, 0) + 1
    return {
        "requests": len(rows),
        "prompt_tokens": prompt,
        "completion_tokens": completion,
        "total_tokens": prompt + completion,
        "cost_usd": round(sum(row.cost_usd for row in rows), 6),
        "by_model": by_model,
        "recent": [
            {
                "provider": row.provider,
                "model": row.model,
                "prompt_tokens": row.prompt_tokens,
                "completion_tokens": row.completion_tokens,
                "created_at": row.created_at,
            }
            for row in rows[:20]
        ],
    }


def _openai_voice_key(db: Session, user: User) -> str:
    """Server key first, then the caller's own encrypted OpenAI credential."""
    if settings.openai_api_key:
        return settings.openai_api_key
    from ..security import decrypt_secret

    row = db.scalar(
        select(ProviderCredential).where(
            ProviderCredential.user_id == user.id, ProviderCredential.kind == "openai"
        )
    )
    if row and row.secret_encrypted:
        return decrypt_secret(row.secret_encrypted)
    return ""


@router.get("/v1/voice/status")
def voice_status(principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    has_key = bool(_openai_voice_key(db, principal.user))
    return {
        "transcription": has_key,
        "speech": has_key,
        "realtime": has_key and bool(settings.openai_realtime_model),
        "detail": (
            "Speech uses your OpenAI key (server key or your own credential)."
            if has_key
            else "Add an OpenAI API key in Settings to enable speech-to-text and text-to-speech."
        ),
    }


@router.post("/v1/voice/transcribe")
async def transcribe(
    file: UploadFile = File(...),
    principal: Principal = Depends(get_principal),
    db: Session = Depends(get_db),
) -> dict:
    key = _openai_voice_key(db, principal.user)
    if not key:
        raise HTTPException(status_code=503, detail="Speech-to-text needs an OpenAI API key.")
    audio = await file.read()
    if not audio:
        raise HTTPException(status_code=400, detail="The audio upload was empty.")
    if len(audio) > settings.max_upload_bytes:
        raise HTTPException(status_code=413, detail="Audio file is too large.")
    files = {"file": (file.filename or "audio.m4a", audio, file.content_type or "audio/m4a")}
    data = {"model": settings.openai_transcribe_model}
    async with httpx.AsyncClient(timeout=120) as client:
        response = await client.post(
            f"{settings.openai_base_url.rstrip('/')}/audio/transcriptions",
            headers={"Authorization": f"Bearer {key}"},
            files=files,
            data=data,
        )
    if response.status_code >= 400:
        detail = response.text[:300]
        raise HTTPException(status_code=502, detail=f"Transcription failed: {detail}")
    payload = response.json()
    return {"text": payload.get("text", ""), "model": settings.openai_transcribe_model}


class SpeakIn(BaseModel):
    text: str = Field(min_length=1, max_length=4000)
    voice: str = Field(default="", max_length=40)
    speed: float = Field(default=1.0, ge=0.5, le=2.0)


@router.post("/v1/voice/speak")
async def speak(payload: SpeakIn, principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> Response:
    key = _openai_voice_key(db, principal.user)
    if not key:
        raise HTTPException(status_code=503, detail="Text-to-speech needs an OpenAI API key.")
    body = {
        "model": settings.openai_tts_model,
        "voice": payload.voice or settings.openai_tts_voice,
        "input": payload.text,
        "speed": payload.speed,
    }
    async with httpx.AsyncClient(timeout=120) as client:
        response = await client.post(
            f"{settings.openai_base_url.rstrip('/')}/audio/speech",
            headers={"Authorization": f"Bearer {key}"},
            json=body,
        )
    if response.status_code >= 400:
        raise HTTPException(status_code=502, detail=f"Speech synthesis failed: {response.text[:300]}")
    return Response(content=response.content, media_type="audio/mpeg")


@router.post("/v1/evals/run")
def run_evals(principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    return evals_service.run_suite(db, principal.user.id)


@router.get("/v1/evals")
def eval_history(principal: Principal = Depends(get_principal), db: Session = Depends(get_db)) -> dict:
    from ..models import EvalRun
    import json as _json

    rows = db.scalars(
        select(EvalRun).where(EvalRun.user_id == principal.user.id).order_by(EvalRun.created_at.desc()).limit(30)
    ).all()
    return {
        "items": [
            {
                "id": row.id,
                "suite": row.suite,
                "score": row.score,
                "total": row.total,
                "results": _json.loads(row.results_json or "[]"),
                "created_at": row.created_at,
            }
            for row in rows
        ]
    }


@router.get("/v1/admin/health")
def admin_health(admin: User = Depends(require_admin), db: Session = Depends(get_db)) -> dict:
    from sqlalchemy import func

    from ..models import AuditEvent, Conversation, Message

    counts = {
        "users": db.scalar(select(func.count()).select_from(User)) or 0,
        "conversations": db.scalar(select(func.count()).select_from(Conversation)) or 0,
        "messages": db.scalar(select(func.count()).select_from(Message)) or 0,
        "audit_events": db.scalar(select(func.count()).select_from(AuditEvent)) or 0,
    }
    return {
        "ok": True,
        "environment": settings.environment,
        "providers": [
            {"kind": item.kind, "source": item.source, "model": item.provider.default_model or None}
            for item in registry.server_providers()
        ],
        "search_provider": bool(settings.tavily_api_key or settings.brave_api_key or settings.searxng_url),
        "counts": counts,
    }


@router.get("/v1/admin/metrics")
def admin_metrics(admin: User = Depends(require_admin), db: Session = Depends(get_db)) -> dict:
    from ..models import AuditEvent

    usage_rows = db.scalars(select(UsageRecord).order_by(UsageRecord.created_at.desc()).limit(1000)).all()
    errors = db.scalars(
        select(AuditEvent).where(AuditEvent.action.like("%error%")).order_by(AuditEvent.created_at.desc()).limit(20)
    ).all()
    return {
        "requests": len(usage_rows),
        "tokens": sum(row.prompt_tokens + row.completion_tokens for row in usage_rows),
        "providers": sorted({row.provider for row in usage_rows if row.provider}),
        "recent_errors": [
            {"action": row.action, "target": row.target, "created_at": row.created_at} for row in errors
        ],
    }


@router.get("/v1/admin/audit")
def admin_audit(limit: int = Query(default=100, le=500), admin: User = Depends(require_admin), db: Session = Depends(get_db)) -> dict:
    from ..models import AuditEvent

    rows = db.scalars(select(AuditEvent).order_by(AuditEvent.created_at.desc()).limit(limit)).all()
    return {
        "items": [
            {
                "id": row.id,
                "user_id": row.user_id,
                "action": row.action,
                "target": row.target,
                "ip": row.ip,
                "created_at": row.created_at,
            }
            for row in rows
        ]
    }


@router.get("/v1/admin/flags")
def list_flags(admin: User = Depends(require_admin), db: Session = Depends(get_db)) -> dict:
    from ..models import FeatureFlag

    rows = db.scalars(select(FeatureFlag)).all()
    return {"items": [{"key": r.key, "enabled": r.enabled, "description": r.description} for r in rows]}


@router.patch("/v1/admin/flags/{key}")
def set_flag(key: str, payload: dict, admin: User = Depends(require_admin), db: Session = Depends(get_db)) -> dict:
    from ..models import FeatureFlag

    row = db.get(FeatureFlag, key)
    if row is None:
        row = FeatureFlag(key=key, enabled=bool(payload.get("enabled")), description=str(payload.get("description", ""))[:300])
        db.add(row)
    else:
        row.enabled = bool(payload.get("enabled", row.enabled))
        if "description" in payload:
            row.description = str(payload["description"])[:300]
    db.commit()
    audit.record(db, "admin.flag_updated", user_id=admin.id, target=key)
    return {"key": row.key, "enabled": row.enabled}
