from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from dataclasses import dataclass, field


@dataclass
class ChatMessage:
    role: str
    content: str | list[dict]
    name: str | None = None

    def text(self) -> str:
        if isinstance(self.content, str):
            return self.content
        return " ".join(part.get("text", "") for part in self.content if part.get("type") == "text")


@dataclass
class StreamChunk:
    text: str = ""
    prompt_tokens: int | None = None
    completion_tokens: int | None = None


@dataclass
class ModelInfo:
    id: str
    label: str
    provider: str
    capabilities: list[str] = field(default_factory=list)
    context_window: int | None = None
    cost_note: str | None = None
    available: bool = True

    def as_dict(self) -> dict:
        return {
            "id": self.id,
            "label": self.label,
            "provider": self.provider,
            "capabilities": self.capabilities,
            "context_window": self.context_window,
            "cost_note": self.cost_note,
            "available": self.available,
        }


class ProviderError(Exception):
    def __init__(self, message: str, *, status: int | None = None, retryable: bool = False):
        super().__init__(message)
        self.message = message
        self.status = status
        self.retryable = retryable


class BaseProvider(ABC):
    kind: str = "base"
    label: str = "Provider"
    supports_vision: bool = False
    supports_streaming: bool = True

    def __init__(self, api_key: str = "", base_url: str = "", default_model: str = ""):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.default_model = default_model

    @property
    def configured(self) -> bool:
        return True

    def resolve_model(self, model: str | None) -> str:
        chosen = (model or self.default_model or "").strip()
        if not chosen:
            raise ProviderError(
                f"{self.label} has no model selected. Set a default model in Settings or pass a model id.",
                status=400,
            )
        return chosen

    @abstractmethod
    async def list_models(self) -> list[ModelInfo]:
        ...

    @abstractmethod
    def stream_chat(
        self,
        messages: list[ChatMessage],
        *,
        model: str | None = None,
        temperature: float = 0.4,
        max_tokens: int = 2048,
    ) -> AsyncIterator[StreamChunk]:
        ...

    async def complete(
        self,
        messages: list[ChatMessage],
        *,
        model: str | None = None,
        temperature: float = 0.4,
        max_tokens: int = 2048,
    ) -> tuple[str, int, int]:
        text_parts: list[str] = []
        prompt_tokens = 0
        completion_tokens = 0
        async for chunk in self.stream_chat(
            messages, model=model, temperature=temperature, max_tokens=max_tokens
        ):
            if chunk.text:
                text_parts.append(chunk.text)
            prompt_tokens = chunk.prompt_tokens or prompt_tokens
            completion_tokens = chunk.completion_tokens or completion_tokens
        return "".join(text_parts), prompt_tokens, completion_tokens

    async def test(self) -> tuple[bool, str, list[str]]:
        try:
            models = await asyncio.wait_for(self.list_models(), timeout=25)
        except ProviderError as exc:
            return False, exc.message, []
        except Exception as exc:  # pragma: no cover - defensive
            return False, f"Connection failed: {exc}", []
        ids = [model.id for model in models][:25]
        if not ids:
            return False, "Connected, but the provider returned no models.", []
        return True, f"Connected. {len(ids)} model(s) available.", ids
