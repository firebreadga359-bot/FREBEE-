from __future__ import annotations

import json
import re

from .base import BaseProvider, ModelInfo, StreamChunk


class MockProvider(BaseProvider):
    """Deterministic provider used by tests and local development only.

    It is registered only when FREBEE_ALLOW_MOCK_PROVIDER is enabled, and it is
    never presented to users as a real model.
    """

    kind = "mock"
    label = "Development mock (not an AI model)"
    supports_vision = False

    MODELS = ("mock:fast", "mock:smart")

    async def list_models(self) -> list[ModelInfo]:
        return [
            ModelInfo(id=name, label=name, provider=self.kind, capabilities=["text", "stream"],
                      cost_note="No cost. Development only.")
            for name in self.MODELS
        ]

    def stream_chat(self, messages, *, model=None, temperature=0.4, max_tokens=2048):
        return self._stream(messages, model)

    async def _stream(self, messages, model):
        self.resolve_model(model)
        last_user = ""
        for message in reversed(messages):
            if message.role == "user":
                last_user = message.text()
                break
        reply = self._reply(messages, last_user)
        for word in reply.split(" "):
            yield StreamChunk(text=word + " ", prompt_tokens=len(last_user) // 4,
                              completion_tokens=len(reply) // 4)

    @staticmethod
    def _reply(messages, last_user):
        transcript = "\n".join(message.text() for message in messages)
        if "TOOL_PROTOCOL" in transcript and "tool_result" not in transcript:
            path = "README.md"
            match = re.search(r"write (\S+)", last_user)
            if match:
                path = match.group(1)
            return json.dumps({"tool": "write_file", "args": {"path": path, "content": "# Mock\n"}})
        if "TOOL_PROTOCOL" in transcript and "tool_result" in transcript:
            return json.dumps({"final": "Wrote the file and stopped."})
        sources = re.findall(r"\[(\d+)\] ([^\\n]+)", last_user)
        if sources:
            cited = " ".join(f"[{index}]" for index, _ in sources[:2])
            return f"Mock research answer {cited}."
        return f"Mock response. You said: {last_user[:200]}"
