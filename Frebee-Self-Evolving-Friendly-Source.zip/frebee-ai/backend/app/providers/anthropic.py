from __future__ import annotations

import json

import httpx

from .base import BaseProvider, ModelInfo, ProviderError, StreamChunk


class AnthropicProvider(BaseProvider):
    kind = "anthropic"
    label = "Anthropic"
    supports_vision = True

    def _headers(self):
        return {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }

    async def list_models(self):
        async with httpx.AsyncClient(timeout=25) as client:
            try:
                response = await client.get(f"{self.base_url}/v1/models", headers=self._headers())
            except httpx.HTTPError as exc:
                raise ProviderError(f"Could not reach {self.base_url}: {exc}") from exc
        if response.status_code == 401:
            raise ProviderError("The API key was rejected (401).", status=401)
        if response.status_code >= 400:
            raise ProviderError(self._error(response.status_code, response.text), status=response.status_code)
        items = response.json().get("data") or []
        return [
            ModelInfo(
                id=item["id"],
                label=item.get("display_name") or item["id"],
                provider=self.kind,
                capabilities=["text", "stream", "vision"],
            )
            for item in items
            if item.get("id")
        ]

    @staticmethod
    def _convert(messages):
        system = "\n\n".join(m.text() for m in messages if m.role == "system")
        converted = []
        for message in messages:
            if message.role == "system":
                continue
            if isinstance(message.content, str):
                converted.append({"role": message.role, "content": [{"type": "text", "text": message.content}]})
            else:
                converted.append({"role": message.role, "content": message.content})
        return system, converted

    def stream_chat(self, messages, *, model=None, temperature=0.4, max_tokens=2048):
        return self._stream(messages, model, temperature, max_tokens)

    async def _stream(self, messages, model, temperature, max_tokens):
        system, converted = self._convert(messages)
        body = {
            "model": self.resolve_model(model),
            "messages": converted,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": True,
        }
        if system:
            body["system"] = system
        url = f"{self.base_url}/v1/messages"
        timeout = httpx.Timeout(180, connect=15)
        async with httpx.AsyncClient(timeout=timeout) as client:
            async with client.stream("POST", url, json=body, headers=self._headers()) as response:
                if response.status_code >= 400:
                    text = (await response.aread()).decode("utf-8", "ignore")[:400]
                    raise ProviderError(self._error(response.status_code, text), status=response.status_code)
                async for line in response.aiter_lines():
                    chunk = self._parse(line)
                    if chunk is not None:
                        yield chunk

    @staticmethod
    def _parse(line):
        if not line.startswith("data:"):
            return None
        try:
            event = json.loads(line[5:].strip())
        except ValueError:
            return None
        kind = event.get("type")
        if kind == "content_block_delta":
            text = (event.get("delta") or {}).get("text") or ""
            return StreamChunk(text=text) if text else None
        if kind == "message_delta":
            usage = event.get("usage") or {}
            return StreamChunk(completion_tokens=usage.get("output_tokens"))
        return None

    def _error(self, status, body):
        if status == 401:
            return "The API key was rejected (401)."
        if status == 429:
            return "Anthropic rate limit reached. Try again shortly."
        return f"Anthropic error {status}: {body[:200]}"
