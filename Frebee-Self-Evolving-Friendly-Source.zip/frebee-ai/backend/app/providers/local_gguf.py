from __future__ import annotations

import asyncio
import logging
import threading
from collections.abc import AsyncIterator
from pathlib import Path

from .base import BaseProvider, ModelInfo, ProviderError, StreamChunk

logger = logging.getLogger(__name__)

_MODEL_CACHE: dict[tuple[str, int, int], object] = {}
_CACHE_LOCK = threading.Lock()

_INSTALL_HINT = (
    "The local model runtime is not installed on this server. Run "
    "`pip install -r backend/requirements-local.txt` and set FREBEE_LOCAL_MODEL_PATH."
)


def _load(model_path: str, n_ctx: int, n_threads: int):
    try:
        from llama_cpp import Llama
    except ImportError as exc:  # pragma: no cover - depends on host packages
        raise ProviderError(_INSTALL_HINT, status=503) from exc

    key = (model_path, n_ctx, n_threads)
    with _CACHE_LOCK:
        model = _MODEL_CACHE.get(key)
        if model is None:
            model = Llama(model_path=model_path, n_ctx=n_ctx, n_threads=n_threads, verbose=False)
            _MODEL_CACHE[key] = model
        return model


# Overhead the chat template adds per message and around the whole prompt.
_MESSAGE_OVERHEAD = 8
_PROMPT_OVERHEAD = 32


def _count_tokens(model, messages: list[dict]) -> int:
    """Counts real tokens, not characters.

    Guessing with chars//4 undercounts dense text (code, URLs, tables) badly enough that
    llama.cpp aborts the whole process when the prompt no longer fits the window.
    """
    total = _PROMPT_OVERHEAD + _MESSAGE_OVERHEAD * len(messages)
    for item in messages:
        total += len(model.tokenize(item["content"].encode("utf-8"), add_bos=False))
    return total


def _shrink(text: str, keep_chars: int) -> str:
    if len(text) <= keep_chars:
        return text
    head = int(keep_chars * 0.4)
    tail = max(0, keep_chars - head - 48)
    return f"{text[:head]}\n...[trimmed to fit the model context]...\n{text[-tail:]}"


def _fit_context(payload: list[dict], model, n_ctx: int, max_tokens: int) -> list[dict]:
    """Drops the oldest turns until the prompt fits the model's window.

    llama.cpp aborts the process on an oversized prompt, so this has to be exact: the
    budget is measured with the model's own tokenizer and keeps a margin for the
    template and the reply.
    """
    budget = max(256, n_ctx - max_tokens - 128)

    system = payload[:1] if payload and payload[0]["role"] == "system" else []
    rest = payload[len(system):]
    if system and _count_tokens(model, system) > budget // 2:
        # Research blocks live inside the system message, so it can overflow on its own.
        keep_chars = (budget // 2) * 3
        system = [{**system[0], "content": _shrink(system[0]["content"], keep_chars)}]

    while len(rest) > 1 and _count_tokens(model, system + rest) > budget:
        rest.pop(0)

    if rest:
        # Last resort: the final message alone is too big (a huge paste or a long question).
        while _count_tokens(model, system + rest) > budget and len(rest[-1]["content"]) > 200:
            overflow = _count_tokens(model, system + rest) - budget
            drop_chars = max(200, overflow * 3)
            rest[-1] = {
                **rest[-1],
                "content": _shrink(rest[-1]["content"], max(200, len(rest[-1]["content"]) - drop_chars)),
            }
    return system + rest


class LocalGgufProvider(BaseProvider):
    """Runs an open-weights GGUF model in this process.

    No network and no API key are involved, which makes it the free path for a
    self-hosted deployment. Quality and speed depend on the model file and the
    host hardware, so capability claims stay deliberately modest.
    """

    kind = "local_gguf"
    label = "Local model on this server"
    supports_vision = False

    def __init__(
        self,
        model_path: str,
        default_model: str = "",
        *,
        n_ctx: int = 4096,
        n_threads: int = 4,
    ) -> None:
        super().__init__("", "", default_model or Path(model_path).stem)
        self.model_path = model_path
        self.n_ctx = n_ctx
        self.n_threads = n_threads

    @property
    def configured(self) -> bool:
        return Path(self.model_path).is_file()

    def _available_models(self) -> dict[str, str]:
        """Every GGUF file next to the configured model, keyed by its id."""
        folder = Path(self.model_path).parent
        found: dict[str, str] = {}
        if folder.is_dir():
            for candidate in sorted(folder.glob("*.gguf")):
                found[candidate.stem] = str(candidate)
        if Path(self.model_path).is_file():
            found.setdefault(Path(self.model_path).stem, self.model_path)
        return found

    def preferred_for_mode(self, mode: str) -> str:
        """Picks the biggest installed model for work that benefits from it.

        A 1.5B model keeps chat snappy but loses the thread on multi-file edits, so the
        coding and deep modes take the slow, larger model when one is installed.
        """
        available = self._available_models()
        if mode in {"deep", "coding", "council", "autonomous", "research"} and len(available) > 1:
            return max(available, key=lambda name: Path(available[name]).stat().st_size)
        return self.resolve_model(None)

    def resolve_model(self, requested: str | None = None) -> str:
        """Maps a model id to a file path; unknown ids fall back to the configured default."""
        available = self._available_models()
        default = Path(self.model_path).stem
        if not requested:
            return default
        if requested in available:
            return requested
        matches = [name for name in available if requested.lower() in name.lower()]
        return matches[0] if len(matches) == 1 else default

    async def list_models(self) -> list[ModelInfo]:
        available = self._available_models()
        if not available:
            return []
        default = self.resolve_model(None)
        default_bytes = Path(available.get(default, self.model_path)).stat().st_size
        models: list[ModelInfo] = []
        for name, path in available.items():
            size = Path(path).stat().st_size
            note = f"Runs on this server, no API cost. {size / (1024**3):.1f} GB file."
            if size < default_bytes * 0.9:
                note += " Faster, but it makes more mistakes on multi-step work."
            elif size > default_bytes * 1.1:
                note += " Smarter, but takes roughly twice as long per word."
            models.append(
                ModelInfo(
                    id=name,
                    label=f"{name} (local{' - default' if name == default else ''})",
                    provider=self.kind,
                    capabilities=["text", "stream"],
                    context_window=self.n_ctx,
                    cost_note=note,
                    available=True,
                )
            )
        # The default first, so the picker opens on the model the server actually uses.
        models.sort(key=lambda item: item.id != default)
        return models

    def stream_chat(self, messages, *, model=None, temperature: float = 0.4, max_tokens: int = 2048):
        return self._stream(messages, temperature, max_tokens, model)

    async def _stream(
        self, messages, temperature: float, max_tokens: int, requested: str | None = None
    ) -> AsyncIterator[StreamChunk]:
        name = self.resolve_model(requested)
        path = self._available_models().get(name, self.model_path)
        if not Path(path).is_file():
            raise ProviderError(f"Local model file not found: {path}", status=503)

        model = await asyncio.to_thread(_load, path, self.n_ctx, self.n_threads)
        payload = [
            {"role": message.role, "content": message.text()}
            for message in messages
            if message.role in {"system", "user", "assistant"} and message.text().strip()
        ]
        payload = _fit_context(payload, model, self.n_ctx, max_tokens)
        logger.info(
            "local model %s: %d prompt tokens, %d max_tokens",
            name, _count_tokens(model, payload), max_tokens,
        )

        loop = asyncio.get_running_loop()
        queue: asyncio.Queue[tuple[str, object]] = asyncio.Queue()

        def worker() -> None:
            try:
                stream = model.create_chat_completion(
                    messages=payload,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    # Greedy-ish sampling with a repetition penalty: small models otherwise
                    # repeat the last paragraph until the token cap.
                    top_p=0.9,
                    repeat_penalty=1.15,
                    stream=True,
                )
                for chunk in stream:
                    delta = (chunk.get("choices") or [{}])[0].get("delta", {}).get("content") or ""
                    if delta:
                        loop.call_soon_threadsafe(queue.put_nowait, ("delta", delta))
                loop.call_soon_threadsafe(queue.put_nowait, ("done", None))
            except Exception as exc:  # noqa: BLE001 - surfaced to the caller as a provider error
                loop.call_soon_threadsafe(queue.put_nowait, ("error", exc))

        threading.Thread(target=worker, name="frebee-local-model", daemon=True).start()

        while True:
            kind, value = await queue.get()
            if kind == "delta":
                yield StreamChunk(text=str(value))
            elif kind == "done":
                return
            else:
                raise ProviderError(f"Local model failed: {value}", status=500)
