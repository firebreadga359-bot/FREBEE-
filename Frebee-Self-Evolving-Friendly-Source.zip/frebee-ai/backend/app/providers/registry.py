from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..models import ProviderCredential, User
from ..security import decrypt_secret
from .anthropic import AnthropicProvider
from .base import BaseProvider
from .gemini import GeminiProvider
from .local_gguf import LocalGgufProvider
from .mock import MockProvider
from .openai import OpenAICompatibleProvider

PROVIDER_LABELS = {
    "openai": "OpenAI / compatible",
    "anthropic": "Anthropic",
    "gemini": "Google Gemini",
    "local": "Local or self-hosted endpoint",
    "local_gguf": "Local model on this server",
    "mock": "Development mock",
}


class ProviderUnavailable(Exception):
    """Raised when the caller has no usable AI provider configured."""

@dataclass
class ResolvedProvider:
    provider: BaseProvider
    source: str
    credential_id: str | None = None

    @property
    def kind(self) -> str:
        return self.provider.kind


def build_provider(kind: str, api_key: str = "", base_url: str = "", default_model: str = "") -> BaseProvider:
    kind = (kind or "").lower()
    if kind == "anthropic":
        return AnthropicProvider(api_key, base_url or "https://api.anthropic.com", default_model)
    if kind == "gemini":
        return GeminiProvider(api_key, base_url or "https://generativelanguage.googleapis.com", default_model)
    if kind == "mock":
        return MockProvider(default_model=default_model or MockProvider.MODELS[0])
    base = base_url or "https://api.openai.com/v1"
    return OpenAICompatibleProvider(api_key, base, default_model)

def server_providers() -> list[ResolvedProvider]:
    settings = get_settings()
    items = []
    if settings.openai_api_key:
        items.append(ResolvedProvider(build_provider("openai", settings.openai_api_key, settings.openai_base_url, settings.openai_model), "server"))
    if settings.anthropic_api_key:
        items.append(ResolvedProvider(build_provider("anthropic", settings.anthropic_api_key, settings.anthropic_base_url, settings.anthropic_model), "server"))
    if settings.gemini_api_key:
        items.append(ResolvedProvider(build_provider("gemini", settings.gemini_api_key, settings.gemini_base_url, settings.gemini_model), "server"))
    if settings.local_base_url:
        items.append(ResolvedProvider(build_provider("local", "", settings.local_base_url, settings.local_model), "server"))
    if settings.local_model_path:
        local = LocalGgufProvider(
            settings.local_model_path,
            settings.local_model,
            n_ctx=settings.local_model_context,
            n_threads=settings.local_model_threads,
        )
        if local.configured:
            items.append(ResolvedProvider(local, "server"))
    return items


def user_providers(db: Session, user: User) -> list[ResolvedProvider]:
    rows = db.scalars(
        select(ProviderCredential)
        .where(ProviderCredential.user_id == user.id)
        .order_by(ProviderCredential.is_default.desc(), ProviderCredential.created_at.desc())
    ).all()
    resolved = []
    for row in rows:
        try:
            secret = decrypt_secret(row.secret_encrypted)
        except Exception:
            continue
        provider = build_provider(row.kind, secret, row.base_url or "", row.default_model or "")
        resolved.append(ResolvedProvider(provider, "user", row.id))
    return resolved

def resolve(db: Session, user: User, preferred: str | None = None) -> list[ResolvedProvider]:
    """Every usable provider for this user, best candidate first."""
    settings = get_settings()
    candidates = user_providers(db, user) + server_providers()
    if settings.allow_mock_provider:
        candidates.append(ResolvedProvider(build_provider("mock"), "mock"))
    if not candidates:
        raise ProviderUnavailable(
            "No AI provider is configured. Add your own API key in Settings, or ask the "
            "operator to set a server key (FREBEE_OPENAI_API_KEY, FREBEE_ANTHROPIC_API_KEY "
            "or FREBEE_GEMINI_API_KEY)."
        )
    wanted = (preferred or settings.default_provider or "").lower()
    if wanted:
        candidates.sort(key=lambda item: 0 if item.kind == wanted else 1)
    return candidates


def status_for(db: Session, user: User) -> list[dict]:
    settings = get_settings()
    rows = db.scalars(select(ProviderCredential).where(ProviderCredential.user_id == user.id)).all()
    seen = {row.kind for row in rows}
    result = [
        {
            "kind": row.kind,
            "label": PROVIDER_LABELS.get(row.kind, row.kind),
            "source": "user",
            "configured": True,
            "masked_key": row.masked_key,
            "default_model": row.default_model,
            "is_default": row.is_default,
            "status": row.status,
            "last_error": row.last_error,
            "id": row.id,
        }
        for row in rows
    ]
    for item in server_providers():
        result.append({
            "kind": item.kind,
            "label": PROVIDER_LABELS.get(item.kind, item.kind),
            "source": "server",
            "configured": True,
            "masked_key": "managed by operator",
            "default_model": item.provider.default_model,
            "is_default": False,
            "status": "configured",
            "last_error": None,
            "id": None,
        })
    local_path = settings.local_model_path
    if local_path and Path(local_path).is_file():
        result.append({
            "kind": "local_gguf",
            "label": PROVIDER_LABELS["local_gguf"],
            "source": "server",
            "configured": True,
            "masked_key": "runs on this server",
            "default_model": settings.local_model or Path(local_path).stem,
            "is_default": settings.default_provider == "local_gguf",
            "status": "configured",
            "last_error": None,
            "id": None,
        })
    if settings.allow_mock_provider:
        result.append({
            "kind": "mock",
            "label": PROVIDER_LABELS["mock"],
            "source": "mock",
            "configured": True,
            "masked_key": "",
            "default_model": MockProvider.MODELS[0],
            "is_default": False,
            "status": "development",
            "last_error": None,
            "id": None,
        })
    return result
