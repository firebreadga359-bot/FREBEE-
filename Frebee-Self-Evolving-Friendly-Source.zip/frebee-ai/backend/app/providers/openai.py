from __future__ import annotations

import json
from collections.abc import AsyncIterator

import httpx

from .base import BaseProvider, ChatMessage, ModelInfo, ProviderError, StreamChunk


class OpenAICompatibleProvider(BaseProvider):
    kind = "openai"
    label = "OpenAI-compatible"
    supports_vision = True

    def _headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    async def list_models(self) -> list[ModelInfo]:
        async with httpx.AsyncClient(timeout=25) as client:
            try:
                response = await client.get(f"{self.base_url}/models", headers=self._headers())
            except httpx.HTTPError as exc:
                raise ProviderError(f"Could not reach {self.base_url}: {exc}") from exc
        if response.status_code == 401:
            raise ProviderError("The API key was rejected (401).", status=401)
        if response.status_code >= 400:
            raise ProviderError(self._error(response.status_code, response.text), status=response.status_code)
        payload = response.json()
        items = payload.get("data") or payload.get("models") or []
        models = []
        for item in items:
            model_id = item.get("id") or item.get("name")
            if model_id:
                models.append(ModelInfo(id=model_id, label=model_id, provider=self.kind,
                                        capabilities=["text", "stream", "vision"]))
        return models

    def stream_chat(self, messages, *, model=None, temperature=0.4, max_tokens=2048):
        return self._stream(messages, model, temperature, max_tokens)

    async def _stream(self, messages, model, temperature, max_tokens):
        model_id = self.resolve_model(model)
        body = {
            "model": model_id,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        url = f"{self.base_url}/chat/completions"
        timeout = httpx.Timeout(180, connect=15)
        async with httpx.AsyncClient(timeout=timeout) as client:
            async with client.stream("POST", url, json=body, headers=self._headers()) as response:
                if response.status_code >= 400:
                    text = (await response.aread()).decode("utf-8", "ignore")[:400]
                    raise ProviderError(self._error(response.status_code, text), status=response.status_code)
                async for line in response.aiter_lines():
                    chunk = self._parse(line)
                    if chunk is not None:
                        yield chunk

    def _parse(self, line):
        if not line.startswith("data:"):
            return None
        data = line[5:].strip()
        if not data:
            return None
        try:
            event = json.loads(data)
        except ValueError:
            return None
        usage = event.get("usage") or {}
        choices = event.get("choices") or [{}]
        delta = choices[0].get("delta") or {}
        return StreamChunk(
            text=delta.get("content") or "",
            prompt_tokens=usage.get("prompt_tokens"),
            completion_tokens=usage.get("completion_tokens"),
        )

    def _error(self, status, body):
        if status == 401:
            return "The API key was rejected (401)."
        if status == 429:
            return "Provider rate limit reached. Try again shortly."
        return f"Provider error {status}: {body[:200]}"
