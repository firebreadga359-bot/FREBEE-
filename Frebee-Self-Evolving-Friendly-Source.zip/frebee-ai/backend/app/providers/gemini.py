from __future__ import annotations

import json

import httpx

from .base import BaseProvider, ModelInfo, ProviderError, StreamChunk


class GeminiProvider(BaseProvider):
    kind = "gemini"
    label = "Google Gemini"
    supports_vision = True

    async def list_models(self):
        url = f"{self.base_url}/v1beta/models"
        async with httpx.AsyncClient(timeout=25) as client:
            try:
                response = await client.get(url, params={"key": self.api_key})
            except httpx.HTTPError as exc:
                raise ProviderError(f"Could not reach {self.base_url}: {exc}") from exc
        if response.status_code in (401, 403):
            raise ProviderError("The API key was rejected.", status=response.status_code)
        if response.status_code >= 400:
            raise ProviderError(self._error(response.status_code, response.text), status=response.status_code)
        models = []
        for item in response.json().get("models") or []:
            name = (item.get("name") or "").replace("models/", "")
            if not name or "generateContent" not in (item.get("supportedGenerationMethods") or []):
                continue
            models.append(ModelInfo(id=name, label=item.get("displayName") or name, provider=self.kind,
                                    capabilities=["text", "stream", "vision"],
                                    context_window=item.get("inputTokenLimit")))
        return models

    @staticmethod
    def _convert(messages):
        system_parts = []
        contents = []
        for message in messages:
            if message.role == "system":
                system_parts.append({"text": message.text()})
                continue
            role = "model" if message.role == "assistant" else "user"
            if isinstance(message.content, str):
                parts = [{"text": message.content}]
            else:
                parts = []
                for part in message.content:
                    if part.get("type") == "text":
                        parts.append({"text": part.get("text", "")})
                    elif part.get("type") == "image_url":
                        url = (part.get("image_url") or {}).get("url", "")
                        if url.startswith("data:"):
                            header, data = url.split(",", 1)
                            mime = header.split(";")[0].replace("data:", "") or "image/png"
                            parts.append({"inline_data": {"mime_type": mime, "data": data}})
            contents.append({"role": role, "parts": parts})
        return system_parts, contents

    def stream_chat(self, messages, *, model=None, temperature=0.4, max_tokens=2048):
        return self._stream(messages, model, temperature, max_tokens)

    async def _stream(self, messages, model, temperature, max_tokens):
        model_id = self.resolve_model(model)
        system_parts, contents = self._convert(messages)
        body = {
            "contents": contents,
            "generationConfig": {"temperature": temperature, "maxOutputTokens": max_tokens},
        }
        if system_parts:
            body["systemInstruction"] = {"parts": system_parts}
        url = f"{self.base_url}/v1beta/models/{model_id}:streamGenerateContent"
        params = {"alt": "sse", "key": self.api_key}
        timeout = httpx.Timeout(180, connect=15)
        async with httpx.AsyncClient(timeout=timeout) as client:
            async with client.stream("POST", url, params=params, json=body) as response:
                if response.status_code >= 400:
                    text = (await response.aread()).decode("utf-8", "ignore")[:400]
                    raise ProviderError(self._error(response.status_code, text), status=response.status_code)
                async for line in response.aiter_lines():
                    chunk = self._parse(line)
                    if chunk is not None:
                        yield chunk

    @staticmethod
    def _parse(line):
        if not line.startswith("data:"):
            return None
        payload = line[5:].strip()
        if not payload:
            return None
        try:
            event = json.loads(payload)
        except ValueError:
            return None
        candidates = event.get("candidates") or []
        text = ""
        if candidates:
            parts = (candidates[0].get("content") or {}).get("parts") or []
            text = "".join(part.get("text", "") for part in parts)
        usage = event.get("usageMetadata") or {}
        if not text and not usage:
            return None
        return StreamChunk(
            text=text,
            prompt_tokens=usage.get("promptTokenCount"),
            completion_tokens=usage.get("candidatesTokenCount"),
        )

    def _error(self, status, body):
        if status in (401, 403):
            return "The Google API key was rejected."
        if status == 429:
            return "Gemini quota reached. Try again later or check your plan."
        return f"Gemini error {status}: {body[:200]}"
