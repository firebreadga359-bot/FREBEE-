from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import time

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .config import get_settings

SCRYPT_N = 2**14
SCRYPT_R = 8
SCRYPT_P = 1


# ----------------------------------------------------------------- passwords


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    digest = hashlib.scrypt(
        password.encode("utf-8"), salt=salt, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P, dklen=32
    )
    return "scrypt${}${}${}${}${}".format(
        SCRYPT_N,
        SCRYPT_R,
        SCRYPT_P,
        base64.b64encode(salt).decode(),
        base64.b64encode(digest).decode(),
    )


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, n, r, p, salt_b64, digest_b64 = stored.split("$")
        if scheme != "scrypt":
            return False
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(digest_b64)
        actual = hashlib.scrypt(
            password.encode("utf-8"), salt=salt, n=int(n), r=int(r), p=int(p), dklen=len(expected)
        )
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


def password_problem(password: str) -> str | None:
    if len(password) < 8:
        return "Password must be at least 8 characters."
    if len(password) > 200:
        return "Password is too long."
    if password.lower() in {"password", "12345678", "qwertyui", "letmein1"}:
        return "Choose a less common password."
    return None


# --------------------------------------------------------------- JWT (HS256)


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip("=")


def _b64url_decode(data: str) -> bytes:
    padding = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)


def create_token(
    subject: str,
    *,
    kind: str = "access",
    minutes: int | None = None,
    extra: dict | None = None,
) -> str:
    settings = get_settings()
    ttl = minutes if minutes is not None else settings.access_token_minutes
    header = {"alg": "HS256", "typ": "JWT"}
    payload = {
        "sub": subject,
        "typ": kind,
        "iss": settings.jwt_issuer,
        "iat": int(time.time()),
        "exp": int(time.time() + ttl * 60),
        "jti": secrets.token_urlsafe(12),
    }
    if extra:
        payload.update(extra)
    segments = [
        _b64url(json.dumps(header, separators=(",", ":")).encode()),
        _b64url(json.dumps(payload, separators=(",", ":")).encode()),
    ]
    signing_input = ".".join(segments).encode()
    signature = hmac.new(settings.jwt_secret.encode(), signing_input, hashlib.sha256).digest()
    segments.append(_b64url(signature))
    return ".".join(segments)


def decode_token(token: str, *, expected_kind: str = "access") -> dict | None:
    settings = get_settings()
    try:
        header_b64, payload_b64, signature_b64 = token.split(".")
        signing_input = f"{header_b64}.{payload_b64}".encode()
        expected = hmac.new(settings.jwt_secret.encode(), signing_input, hashlib.sha256).digest()
        if not hmac.compare_digest(expected, _b64url_decode(signature_b64)):
            return None
        payload = json.loads(_b64url_decode(payload_b64))
        if payload.get("iss") != settings.jwt_issuer:
            return None
        if payload.get("typ") != expected_kind:
            return None
        if int(payload.get("exp", 0)) < int(time.time()):
            return None
        return payload
    except Exception:
        return None


# ----------------------------------------------------------- secret storage


def _aes_key() -> bytes:
    return hashlib.sha256(get_settings().encryption_key.encode()).digest()


def encrypt_secret(plaintext: str) -> str:
    if not plaintext:
        return ""
    nonce = os.urandom(12)
    ciphertext = AESGCM(_aes_key()).encrypt(nonce, plaintext.encode(), None)
    return base64.b64encode(nonce + ciphertext).decode()


def decrypt_secret(payload: str) -> str:
    if not payload:
        return ""
    raw = base64.b64decode(payload)
    nonce, ciphertext = raw[:12], raw[12:]
    return AESGCM(_aes_key()).decrypt(nonce, ciphertext).decode()


def mask_secret(secret: str) -> str:
    if not secret:
        return ""
    if len(secret) <= 8:
        return "*" * len(secret)
    return f"{secret[:3]}…{secret[-4:]}"


# ------------------------------------------------------------- Frebee keys

API_KEY_PREFIX = "fbk_live"


def generate_api_key() -> tuple[str, str, str]:
    """Return (plaintext, prefix, sha256 hash). The plaintext is shown once."""
    body = secrets.token_urlsafe(32)
    plaintext = f"{API_KEY_PREFIX}_{body}"
    prefix = plaintext[: len(API_KEY_PREFIX) + 6]
    return plaintext, prefix, hash_api_key(plaintext)


def hash_api_key(plaintext: str) -> str:
    return hashlib.sha256(plaintext.encode()).hexdigest()


def generate_opaque_token() -> tuple[str, str]:
    plaintext = secrets.token_urlsafe(32)
    return plaintext, hash_token(plaintext)


def hash_token(plaintext: str) -> str:
    return hashlib.sha256(plaintext.encode()).hexdigest()


def redact(value: str) -> str:
    """Redacts likely credentials before they reach logs."""
    value = re.sub(r"(sk-[A-Za-z0-9_\-]{8,})", "sk-***", value)
    value = re.sub(r"(fbk_live_[A-Za-z0-9_\-]+)", "fbk_live_***", value)
    value = re.sub(r"(Bearer\s+[A-Za-z0-9._\-]+)", "Bearer ***", value)
    return value
