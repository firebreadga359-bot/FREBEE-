# Repository notes for AI agents

Frebee is an Android app (`app/`) plus a FastAPI backend (`backend/`). Read
`docs/BUILD_REPORT.md` before claiming anything works; it records what was actually
executed.

## Commands

```bash
# Backend
cd backend && python -m pytest -q                      # 35 tests, no network needed
python -m uvicorn app.main:app --reload --port 8000    # dashboard at /

# Android (JDK 17 + Android SDK 35 required)
./gradlew :app:testDebugUnitTest :app:assembleDebug
```

This environment has JDK 17 at `/workspace/tools/jdk-17.0.21.1+2`, Gradle 8.9 at
`/workspace/tools/gradle-8.9/bin/gradle`, and the SDK at `/workspace/tools/android-sdk`
(also recorded in `local.properties`, which is git-ignored).

## Conventions

- Python: type hints everywhere, `from __future__ import annotations`, routers thin and
  services in `app/services/`, provider-specific code only inside `app/providers/`.
- Every query filters by `user_id`; a foreign object id must return 404, not 403.
- Never put provider secrets in client code or logs; use `security.encrypt_secret` and
  `security.redact`.
- External text (web pages, uploads, tool output) is wrapped with
  `retrieval.wrap_untrusted` before it reaches a model.
- Kotlin: Compose + ViewModel state, no blocking work on the main thread.
- Tests use the deterministic mock provider (`FREBEE_ALLOW_MOCK_PROVIDER=true`); never
  make the suite depend on a paid API.

## Answer quality notes

- Local answers are only as good as what reaches the model. Research context is budgeted
  (6k chars for local backends, 14k for hosted ones) and every source is labelled with
  its URL and publication date; without labels the model invents versions and dates.
- Ranking decides correctness: a matching host (`python.org` for "python") must outweigh
  a keyword-dense third-party page, and pages that returned 403 or no text are dropped
  rather than cited.
- Memory is deterministic on purpose (`orchestrator.memory_facts`). A small model asked
  to "remember" things turns guesses into permanent context. Facts stop at the clause
  boundary: "My name is Asha. I'm building X and I prefer Y" stores three values.
- Council mode asks the reviewer for `KEEP` and caps its budget; a reviewer that repeats
  the draft must not trigger a second full stream. Revisions are announced with a
  `reset` event, otherwise the client shows the draft and the revision stacked.

## Local model performance notes

- The 3B model on 4 vCPUs reads the prompt at ~60 tok/s and answers at 5-14 tok/s
  (slower as the context grows). The 1.5B model is roughly twice as fast and noticeably
  worse at edits that must keep names; both are listed in the picker, the default comes
  from `FREBEE_LOCAL_MODEL_PATH`, and `preferred_for_mode` sends coding/deep/research/
  council/autonomous to the largest installed file.
- Local history is capped at 4 000 characters (`HISTORY_CHAR_BUDGET_LOCAL`). Without
  the cap a 20-turn conversation took 80 s per turn; with it, turns stay under ~40 s.
  Dropped user requests are recapped in the system prompt so the task thread survives.
- Never estimate prompt size with `len(text) // 4`. Dense text (code, URLs, tables)
  undercounts badly and llama.cpp aborts the *process* on overflow, not the request.
  `local_gguf._fit_context` measures with the model's own tokenizer and keeps
  `n_ctx - max_tokens - 128`.
- Keep the system prompt and history byte-identical between turns: retrieved context
  belongs on the final user turn so llama.cpp's prefix cache can skip the re-read.
- Follow-up instructions ("do it again", "now add a header") must not trigger research.
  `should_research(..., has_history=True)` handles this; a search there costs 10-30 s
  and injects unrelated pages.
- Image uploads run through tesseract (`uploads.ocr_image`) when the binary exists, so
  screenshots are useful without a vision model. Never claim the model saw an image:
  it either got OCR text or an explicit "cannot read images" note.

## Known gaps

- No database migrations: tables are created at startup. Changing a column means a
  manual migration or a fresh database.
- The rate limiter is in-process; multi-instance deployments need a shared store.
- Realtime voice, Google sign-in and passkeys are not implemented.
