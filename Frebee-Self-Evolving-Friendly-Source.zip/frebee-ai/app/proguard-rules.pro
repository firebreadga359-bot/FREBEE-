# kotlinx.serialization keeps generated serializers through the @Serializable annotation.
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.frebee.ai.**$$serializer { *; }
-keepclassmembers class com.frebee.ai.** { *** Companion; }
-keepclasseswithmembers class com.frebee.ai.** { kotlinx.serialization.KSerializer serializer(...); }
-dontwarn okhttp3.**
-dontwarn okio.**
