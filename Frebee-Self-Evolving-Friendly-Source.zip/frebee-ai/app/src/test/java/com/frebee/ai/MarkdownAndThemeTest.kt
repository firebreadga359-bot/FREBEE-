package com.frebee.ai

import com.frebee.ai.domain.ChatMode
import com.frebee.ai.domain.ThemeMode
import com.frebee.ai.domain.ThinkingEffort
import com.frebee.ai.ui.chat.MarkdownParser
import com.frebee.ai.ui.chat.MdBlock
import com.frebee.ai.ui.theme.paletteFor
import com.frebee.ai.domain.UiStyle
import com.frebee.ai.util.Attachments
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MarkdownParserTest {

    @Test
    fun `parses headings with level`() {
        val blocks = MarkdownParser.parse("# Title\n\n### Deep")
        assertEquals(2, blocks.size)
        assertEquals(MdBlock.Heading(1, "Title"), blocks[0])
        assertEquals(MdBlock.Heading(3, "Deep"), blocks[1])
    }

    @Test
    fun `parses fenced code with language`() {
        val markdown = "Intro\n\n```kotlin\nfun main() {}\n```\n"
        val blocks = MarkdownParser.parse(markdown)
        assertTrue(blocks.any { it is MdBlock.Paragraph })
        val code = blocks.filterIsInstance<MdBlock.Code>().single()
        assertEquals("kotlin", code.language)
        assertEquals("fun main() {}", code.code)
    }

    @Test
    fun `parses unordered and ordered lists`() {
        val blocks = MarkdownParser.parse("- one\n- two\n\n1. first\n2. second")
        val bullets = blocks.filterIsInstance<MdBlock.Bullets>().single()
        assertEquals(listOf("one", "two"), bullets.items)
        val numbered = blocks.filterIsInstance<MdBlock.Numbered>().single()
        assertEquals(listOf("first", "second"), numbered.items)
    }

    @Test
    fun `parses pipe tables`() {
        val markdown = "| a | b |\n|---|---|\n| 1 | 2 |\n| 3 | 4 |"
        val table = MarkdownParser.parse(markdown).filterIsInstance<MdBlock.Table>().single()
        assertEquals(listOf("a", "b"), table.header)
        assertEquals(2, table.rows.size)
        assertEquals(listOf("3", "4"), table.rows[1])
    }

    @Test
    fun `keeps paragraphs together and splits on blank lines`() {
        val blocks = MarkdownParser.parse("line one\nline two\n\nsecond paragraph")
        val paragraphs = blocks.filterIsInstance<MdBlock.Paragraph>()
        assertEquals(2, paragraphs.size)
        assertEquals("line one\nline two", paragraphs[0].text)
    }

    @Test
    fun `parses block quotes`() {
        val quote = MarkdownParser.parse("> quoted text").filterIsInstance<MdBlock.Quote>().single()
        assertEquals("quoted text", quote.text)
    }

    @Test
    fun `does not treat a lone pipe as a table`() {
        val blocks = MarkdownParser.parse("a | b without separator")
        assertTrue(blocks.none { it is MdBlock.Table })
    }
}

class PaletteTest {

    private fun luminance(color: androidx.compose.ui.graphics.Color): Double {
        fun channel(value: Float): Double {
            val c = value.toDouble()
            return if (c <= 0.03928) c / 12.92 else Math.pow((c + 0.055) / 1.055, 2.4)
        }
        return 0.2126 * channel(color.red) + 0.7152 * channel(color.green) + 0.0722 * channel(color.blue)
    }

    private fun contrast(a: androidx.compose.ui.graphics.Color, b: androidx.compose.ui.graphics.Color): Double {
        val la = luminance(a)
        val lb = luminance(b)
        val lighter = maxOf(la, lb)
        val darker = minOf(la, lb)
        return (lighter + 0.05) / (darker + 0.05)
    }

    @Test
    fun `text on surfaces keeps at least 4_5 to 1 contrast in every style`() {
        val accents = listOf(0xFF5B8CFF, 0xFF8B5CF6, 0xFF14B8A6, 0xFFF59E0B, 0xFFF43F5E, 0xFF84CC16)
        for (style in UiStyle.entries) {
            for (dark in listOf(true, false)) {
                for (accent in accents) {
                    val palette = paletteFor(style, dark, accent)
                    val ratio = contrast(palette.onSurface, palette.surface)
                    assertTrue(
                        "style=$style dark=$dark accent=$accent ratio=$ratio",
                        ratio >= 4.5,
                    )
                }
            }
        }
    }

    @Test
    fun `styles produce different palettes`() {
        val classic = paletteFor(UiStyle.Classic, dark = true, accentArgb = 0xFF5B8CFF)
        val futuristic = paletteFor(UiStyle.Futuristic, dark = true, accentArgb = 0xFF5B8CFF)
        assertTrue(classic.background != futuristic.background)
    }
}

class ModeParsingTest {

    @Test
    fun `wire values round trip`() {
        ChatMode.entries.forEach { mode ->
            assertEquals(mode, ChatMode.fromWire(mode.wire))
        }
        ThinkingEffort.entries.forEach { effort ->
            assertEquals(effort, ThinkingEffort.fromWire(effort.wire))
        }
    }

    @Test
    fun `unknown wire values fall back to balanced and medium`() {
        assertEquals(ChatMode.Balanced, ChatMode.fromWire("nonsense"))
        assertEquals(ChatMode.Balanced, ChatMode.fromWire(null))
        assertEquals(ThinkingEffort.Medium, ThinkingEffort.fromWire("ultra"))
        assertEquals(ThemeMode.System, ThemeMode.entries.firstOrNull { it.name == "System" })
    }
}

class AttachmentRulesTest {

    @Test
    fun `mime guess covers common developer files`() {
        assertEquals("application/pdf", Attachments.guessMime("report.PDF"))
        assertEquals("text/x-kotlin", Attachments.guessMime("Main.kt"))
        assertEquals("text/x-python", Attachments.guessMime("train.py"))
        assertEquals("application/json", Attachments.guessMime("data.json"))
    }

    @Test
    fun `unsupported mime types are rejected`() {
        assertTrue(Attachments.isSupportedMime("image/png"))
        assertTrue(Attachments.isSupportedMime("application/pdf"))
        assertTrue(Attachments.isSupportedMime("text/plain"))
        assertTrue(!Attachments.isSupportedMime("application/x-msdownload"))
        assertTrue(!Attachments.isSupportedMime("application/vnd.android.package-archive"))
    }

    @Test
    fun `upload limit is enforced in code`() {
        assertNotNull(Attachments.MAX_UPLOAD_BYTES)
        assertTrue(Attachments.MAX_UPLOAD_BYTES > 0)
    }
}
