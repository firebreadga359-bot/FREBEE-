package com.frebee.ai

import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.assertIsDisplayed
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Smoke coverage for the signed-out shell. These tests run on a device or emulator
 * (`./gradlew connectedDebugAndroidTest`); they do not require a backend because the
 * auth screen is fully local.
 */
@RunWith(AndroidJUnit4::class)
class AppLaunchTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun brandIsVisibleOnLaunch() {
        composeRule.onNodeWithText("Frebee").assertIsDisplayed()
    }

    @Test
    fun guestEntryPointIsOffered() {
        composeRule.onNodeWithText("Continue as guest").assertIsDisplayed()
    }

    @Test
    fun loginAndRegistrationTabsExist() {
        composeRule.onNodeWithText("Log in").assertIsDisplayed()
        composeRule.onNodeWithText("Create account").assertIsDisplayed()
    }
}
