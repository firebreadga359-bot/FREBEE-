package com.frebee.ai.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.frebee.ai.AppContainer
import com.frebee.ai.data.remote.ApiException
import com.frebee.ai.data.remote.CreateProviderRequest
import com.frebee.ai.data.remote.SessionDto
import com.frebee.ai.domain.ApiKeyInfo
import com.frebee.ai.domain.AppSettings
import com.frebee.ai.domain.ConversationSummary
import com.frebee.ai.domain.MemoryItem
import com.frebee.ai.domain.ModelInfo
import com.frebee.ai.domain.ProjectInfo
import com.frebee.ai.domain.ProviderInfo
import com.frebee.ai.domain.UsageSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class BackendStatus { Unknown, Online, Offline }

data class Banner(val text: String, val isError: Boolean = false)

data class SessionUi(
    val loading: Boolean = true,
    val signedIn: Boolean = false,
    val guest: Boolean = false,
    val email: String = "",
    val name: String = "",
    val role: String = "user",
    val emailVerified: Boolean = true,
)

class AppViewModel(private val container: AppContainer) : ViewModel() {

    private val api = container.api

    val settings: StateFlow<AppSettings> = container.settings.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val conversations: StateFlow<List<ConversationSummary>> = container.chat.conversations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val projects: StateFlow<List<ProjectInfo>> = container.projects.observeLocal()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val memories: StateFlow<List<MemoryItem>> = container.memory.observeLocal()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _session = MutableStateFlow(SessionUi())
    val session: StateFlow<SessionUi> = _session.asStateFlow()

    private val _models = MutableStateFlow<List<ModelInfo>>(emptyList())
    val models: StateFlow<List<ModelInfo>> = _models.asStateFlow()

    private val _providers = MutableStateFlow<List<ProviderInfo>>(emptyList())
    val providers: StateFlow<List<ProviderInfo>> = _providers.asStateFlow()

    private val _apiKeys = MutableStateFlow<List<ApiKeyInfo>>(emptyList())
    val apiKeys: StateFlow<List<ApiKeyInfo>> = _apiKeys.asStateFlow()

    private val _usage = MutableStateFlow(UsageSummary())
    val usage: StateFlow<UsageSummary> = _usage.asStateFlow()

    private val _sessions = MutableStateFlow<List<SessionDto>>(emptyList())
    val sessions: StateFlow<List<SessionDto>> = _sessions.asStateFlow()

    private val _backendStatus = MutableStateFlow(BackendStatus.Unknown)
    val backendStatus: StateFlow<BackendStatus> = _backendStatus.asStateFlow()

    private val _banner = MutableStateFlow<Banner?>(null)
    val banner: StateFlow<Banner?> = _banner.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    init {
        bootstrap()
    }

    fun dismissBanner() {
        _banner.value = null
    }

    private fun notify(text: String, isError: Boolean = false) {
        _banner.value = Banner(text, isError)
    }

    fun bootstrap() {
        viewModelScope.launch {
            _session.value = _session.value.copy(loading = true)
            if (!container.session.isSignedIn) {
                _session.value = SessionUi(loading = false, signedIn = false)
                return@launch
            }
            try {
                val user = api.me()
                _backendStatus.value = BackendStatus.Online
                _session.value = SessionUi(
                    loading = false,
                    signedIn = true,
                    guest = user.isGuest,
                    email = user.email,
                    name = user.displayName ?: user.email.substringBefore('@'),
                    role = user.role,
                    emailVerified = user.emailVerified,
                )
                refreshAll()
            } catch (e: ApiException) {
                if (e.isUnauthorized) {
                    container.session.clear()
                    _session.value = SessionUi(loading = false, signedIn = false)
                } else {
                    // Offline: keep the cached conversation list usable and say so.
                    _backendStatus.value = BackendStatus.Offline
                    val cached = container.settings.settings.first()
                    _session.value = SessionUi(
                        loading = false,
                        signedIn = true,
                        guest = cached.guest,
                        email = cached.accountEmail,
                        name = cached.accountName,
                        emailVerified = true,
                    )
                    notify(e.message ?: "Backend unreachable. Showing saved conversations.")
                }
            }
        }
    }

    fun refreshAll() {
        viewModelScope.launch {
            refreshConversations()
            refreshModels()
            refreshProviders()
            refreshMemories()
            refreshProjects()
        }
    }

    fun refreshConversations() {
        viewModelScope.launch {
            runCatching { container.chat.syncConversations() }
                .onSuccess { _backendStatus.value = BackendStatus.Online }
                .onFailure { if (it is ApiException && !it.isUnauthorized) _backendStatus.value = BackendStatus.Offline }
        }
    }

    fun refreshModels() {
        viewModelScope.launch {
            runCatching { api.models() }.onSuccess { response ->
                _models.value = response.items.map {
                    ModelInfo(it.id, it.label, it.provider, it.capabilities, it.contextWindow, it.costNote)
                }
                _backendStatus.value = BackendStatus.Online
            }
        }
    }

    fun refreshProviders() {
        viewModelScope.launch {
            runCatching { api.providers() }.onSuccess { list ->
                _providers.value = list.map {
                    ProviderInfo(it.id, it.kind, it.label, it.baseUrl, it.maskedKey, it.status, it.defaultModel, it.isDefault, it.error)
                }
            }
        }
    }

    fun refreshMemories() {
        viewModelScope.launch {
            runCatching { container.memory.refresh() }
        }
    }

    fun refreshProjects() {
        viewModelScope.launch {
            runCatching { container.projects.refresh() }
        }
    }

    fun signIn(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            notify("Enter your email and password.", isError = true)
            return
        }
        viewModelScope.launch {
            _busy.value = true
            try {
                val token = api.login(email, password)
                val user = token.user
                container.settings.update {
                    it.copy(
                        guest = false,
                        accountEmail = user?.email ?: email,
                        accountName = user?.displayName ?: email.substringBefore('@'),
                    )
                }
                _session.value = SessionUi(
                    loading = false,
                    signedIn = true,
                    guest = user?.isGuest ?: false,
                    email = user?.email ?: email,
                    name = user?.displayName ?: email.substringBefore('@'),
                    role = user?.role ?: "user",
                    emailVerified = user?.emailVerified ?: false,
                )
                _backendStatus.value = BackendStatus.Online
                refreshAll()
            } catch (e: ApiException) {
                notify(e.message ?: "Sign in failed", isError = true)
            } finally {
                _busy.value = false
            }
        }
    }

    fun register(email: String, password: String, displayName: String) {
        viewModelScope.launch {
            _busy.value = true
            try {
                val token = api.register(email, password, displayName)
                val user = token.user
                container.settings.update {
                    it.copy(
                        guest = false,
                        accountEmail = user?.email ?: email,
                        accountName = user?.displayName ?: displayName,
                    )
                }
                _session.value = SessionUi(
                    loading = false,
                    signedIn = true,
                    guest = false,
                    email = user?.email ?: email,
                    name = user?.displayName ?: displayName,
                    role = user?.role ?: "user",
                    emailVerified = user?.emailVerified ?: false,
                )
                refreshAll()
                notify("Account created. Check your email to verify the address.")
            } catch (e: ApiException) {
                notify(e.message ?: "Registration failed", isError = true)
            } finally {
                _busy.value = false
            }
        }
    }

    fun continueAsGuest() {
        viewModelScope.launch {
            _busy.value = true
            try {
                val token = api.guest()
                container.settings.update { it.copy(guest = true, accountEmail = "guest", accountName = "Guest") }
                _session.value = SessionUi(
                    loading = false,
                    signedIn = true,
                    guest = true,
                    email = token.user?.email ?: "guest",
                    name = "Guest",
                    role = "guest",
                    emailVerified = false,
                )
                refreshAll()
            } catch (e: ApiException) {
                notify(e.message ?: "Guest mode is unavailable while the backend is offline.", isError = true)
            } finally {
                _busy.value = false
            }
        }
    }

    fun signOut() {
        viewModelScope.launch {
            api.logout()
            container.chat.deleteAllLocal()
            container.settings.update { it.copy(guest = false, accountEmail = "", accountName = "") }
            _session.value = SessionUi(loading = false, signedIn = false)
            _models.value = emptyList()
            _providers.value = emptyList()
            _apiKeys.value = emptyList()
            _memoriesRefresh()
        }
    }

    private fun _memoriesRefresh() {
        viewModelScope.launch { runCatching { container.memory.refresh() } }
    }

    fun renameConversation(id: String, title: String) {
        viewModelScope.launch {
            runCatching { container.chat.rename(id, title) }
                .onFailure { notify(it.message ?: "Rename failed", isError = true) }
        }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            runCatching { container.chat.delete(id) }
                .onFailure { notify(it.message ?: "Delete failed", isError = true) }
        }
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { container.settings.update(transform) }
    }

    fun addProvider(kind: String, label: String, apiKey: String, baseUrl: String?, defaultModel: String?) {
        viewModelScope.launch {
            _busy.value = true
            try {
                api.addProvider(CreateProviderRequest(kind, label, apiKey, baseUrl?.ifBlank { null }, defaultModel?.ifBlank { null }))
                notify("Provider saved. Run a connection test to confirm it works.")
                refreshProviders()
                refreshModels()
            } catch (e: ApiException) {
                notify(e.message ?: "Could not save the provider", isError = true)
            } finally {
                _busy.value = false
            }
        }
    }

    fun testProvider(id: String) {
        viewModelScope.launch {
            _busy.value = true
            try {
                val result = api.testProvider(id)
                notify(result.message, isError = !result.ok)
                refreshProviders()
                refreshModels()
            } catch (e: ApiException) {
                notify(e.message ?: "Connection test failed", isError = true)
            } finally {
                _busy.value = false
            }
        }
    }

    fun removeProvider(id: String) {
        viewModelScope.launch {
            runCatching { api.deleteProvider(id) }
                .onSuccess { refreshProviders(); refreshModels() }
                .onFailure { notify(it.message ?: "Could not remove the provider", isError = true) }
        }
    }

    fun makeProviderDefault(id: String) {
        viewModelScope.launch {
            runCatching { api.setDefaultProvider(id) }
                .onSuccess { refreshProviders() }
                .onFailure { notify(it.message ?: "Could not update the default provider", isError = true) }
        }
    }

    fun addMemory(key: String, value: String, scope: String = "user") {
        viewModelScope.launch {
            runCatching { container.memory.add(scope, null, key, value) }
                .onSuccess { notify("Memory saved") }
                .onFailure { notify(it.message ?: "Could not save memory", isError = true) }
        }
    }

    fun deleteMemory(id: String) {
        viewModelScope.launch {
            runCatching { container.memory.delete(id) }
                .onFailure { notify(it.message ?: "Could not delete memory", isError = true) }
        }
    }

    fun clearMemory() {
        viewModelScope.launch {
            runCatching { container.memory.deleteAll() }
                .onSuccess { notify("All saved memory deleted") }
                .onFailure { notify(it.message ?: "Could not delete memory", isError = true) }
        }
    }

    fun loadDeveloperData() {
        viewModelScope.launch {
            runCatching { api.apiKeys() }.onSuccess { list ->
                _apiKeys.value = list.map {
                    ApiKeyInfo(it.id, it.label, it.masked, it.scopes, it.createdAt, it.lastUsedAt, it.revoked)
                }
            }
            runCatching { api.usage() }.onSuccess {
                _usage.value = UsageSummary(it.requests, it.promptTokens, it.completionTokens, it.estimatedCostUsd)
            }
            runCatching { api.sessions() }.onSuccess { _sessions.value = it }
        }
    }

    fun createApiKey(label: String, onCreated: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val created = api.createApiKey(label.ifBlank { "Frebee key" }, listOf("chat.read", "chat.write"))
                onCreated(created.secret)
                loadDeveloperData()
            } catch (e: ApiException) {
                notify(e.message ?: "Could not create the API key", isError = true)
            }
        }
    }

    fun revokeApiKey(id: String) {
        viewModelScope.launch {
            runCatching { api.revokeApiKey(id) }
                .onSuccess { loadDeveloperData() }
                .onFailure { notify(it.message ?: "Could not revoke the key", isError = true) }
        }
    }

    fun revokeSession(id: String) {
        viewModelScope.launch {
            runCatching { api.revokeSession(id) }
                .onSuccess { loadDeveloperData() }
                .onFailure { notify(it.message ?: "Could not revoke the session", isError = true) }
        }
    }

    fun revokeAllSessions() {
        viewModelScope.launch {
            runCatching { api.revokeAllSessions() }
                .onSuccess { signOut() }
                .onFailure { notify(it.message ?: "Could not revoke sessions", isError = true) }
        }
    }

    fun exportData(onReady: (String) -> Unit) {
        viewModelScope.launch {
            runCatching { api.exportAccount() }
                .onSuccess(onReady)
                .onFailure { notify(it.message ?: "Export failed", isError = true) }
        }
    }

    fun deleteAccount(password: String) {
        viewModelScope.launch {
            try {
                api.deleteAccount(password)
                container.chat.deleteAllLocal()
                container.settings.reset()
                _session.value = SessionUi(loading = false, signedIn = false)
                notify("Account deleted.")
            } catch (e: ApiException) {
                notify(e.message ?: "Could not delete the account", isError = true)
            }
        }
    }

    fun verifyEmail(token: String) {
        viewModelScope.launch {
            runCatching { api.verifyEmail(token) }
                .onSuccess { notify("Email verified"); bootstrap() }
                .onFailure { notify(it.message ?: "Verification failed", isError = true) }
        }
    }

    fun requestPasswordReset(email: String) {
        viewModelScope.launch {
            runCatching { api.requestPasswordReset(email) }
                .onSuccess { notify("If that address exists, a reset link has been sent.") }
                .onFailure { notify(it.message ?: "Could not start password reset", isError = true) }
        }
    }

    fun confirmPasswordReset(token: String, newPassword: String) {
        viewModelScope.launch {
            runCatching { api.confirmPasswordReset(token, newPassword) }
                .onSuccess { notify("Password updated. Sign in with the new password.") }
                .onFailure { notify(it.message ?: "Could not reset the password", isError = true) }
        }
    }
}
