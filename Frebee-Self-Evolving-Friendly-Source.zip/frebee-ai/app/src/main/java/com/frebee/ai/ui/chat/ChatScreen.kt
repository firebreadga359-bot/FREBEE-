package com.frebee.ai.ui.chat

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.frebee.ai.domain.Attachment
import com.frebee.ai.domain.ChatMode
import com.frebee.ai.domain.ThinkingEffort
import com.frebee.ai.domain.UiMessage
import com.frebee.ai.domain.UiStyle
import com.frebee.ai.domain.UploadState
import com.frebee.ai.ui.AppViewModel
import com.frebee.ai.ui.common.BrandMark
import com.frebee.ai.ui.common.InlineBanner
import com.frebee.ai.ui.theme.LocalFrebeePalette
import com.frebee.ai.util.Attachments
import com.frebee.ai.voice.SpeechInput
import com.frebee.ai.voice.Speaker
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(
    app: AppViewModel,
    chatVm: ChatViewModel,
    onOpenDrawer: () -> Unit,
) {
    val palette = LocalFrebeePalette.current
    val context = LocalContext.current
    val settings by app.settings.collectAsStateWithLifecycle()
    val models by app.models.collectAsStateWithLifecycle()
    val messages by chatVm.messages.collectAsStateWithLifecycle()
    val streaming by chatVm.streaming.collectAsStateWithLifecycle()
    val statusLine by chatVm.statusLine.collectAsStateWithLifecycle()
    val title by chatVm.title.collectAsStateWithLifecycle()
    val error by chatVm.error.collectAsStateWithLifecycle()
    val pendingAttachments by chatVm.attachments.collectAsStateWithLifecycle()
    val suggestions by chatVm.suggestions.collectAsStateWithLifecycle()
    val activeId by chatVm.activeConversationId.collectAsStateWithLifecycle()

    var draft by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var editTarget by remember { mutableStateOf<UiMessage?>(null) }
    var listening by remember { mutableStateOf(false) }
    var partial by remember { mutableStateOf("") }
    var pendingDownload by remember { mutableStateOf<Pair<String, String>?>(null) }

    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val speech = remember { SpeechInput(context) }
    val speaker = remember { Speaker(context) }
    val clipboard = LocalClipboardManager.current

    DisposableEffect(Unit) {
        onDispose {
            speech.destroy()
            speaker.shutdown()
        }
    }

    val lastAssistant = messages.lastOrNull { it.role == "assistant" }
    LaunchedEffect(lastAssistant?.id, lastAssistant?.streaming, settings.speakReplies) {
        if (settings.speakReplies && lastAssistant != null && !lastAssistant.streaming &&
            !lastAssistant.error && lastAssistant.content.isNotBlank()
        ) {
            speaker.speak(lastAssistant.content)
        }
    }

    LaunchedEffect(messages.size, messages.lastOrNull()?.content?.length) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    val saveCodeLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain"),
    ) { uri ->
        val payload = pendingDownload
        if (uri != null && payload != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(payload.second.toByteArray())
                }
            }
        }
        pendingDownload = null
    }

    fun attachUri(uri: Uri) {
        val picked = Attachments.describe(context, uri)
        if (picked == null) {
            chatVm.attach(uri, uri.lastPathSegment ?: "attachment", "application/octet-stream", 0)
        } else {
            chatVm.attach(picked.uri, picked.name, picked.mime, picked.size)
        }
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { attachUri(it) }
    }
    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia(),
    ) { uri -> uri?.let { attachUri(it) } }
    var captureUri by remember { mutableStateOf<Uri?>(null) }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) captureUri?.let { attachUri(it) }
    }

    fun startListening() {
        partial = ""
        speech.onPartial = { partial = it }
        speech.onFinal = {
            draft = (draft + " " + it).trim()
            listening = false
            partial = ""
        }
        speech.onError = {
            listening = false
            partial = ""
        }
        listening = true
        speech.start()
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListening()
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        ChatHeader(
            title = if (activeId == null) "New chat" else title,
            subtitle = "${settings.mode.label} · ${settings.effort.label} reasoning",
            modelLabel = models.firstOrNull { it.id == settings.modelId }?.label ?: "Auto model",
            onOpenDrawer = onOpenDrawer,
            menuOpen = menuOpen,
            onMenuOpenChange = { menuOpen = it },
            hasConversation = activeId != null,
            onRename = { showRename = true },
            onDelete = { showDelete = true },
            onArchive = { chatVm.archive() },
        )

        AnimatedVisibility(visible = error != null) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                InlineBanner(
                    text = error.orEmpty(),
                    isError = true,
                    actionLabel = "Retry",
                    onAction = {
                        chatVm.dismissError()
                        chatVm.regenerate()
                    },
                    onDismiss = { chatVm.dismissError() },
                )
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (messages.isEmpty()) {
                EmptyChat(suggestions = suggestions, onSuggestion = { draft = it })
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                ) {
                    items(messages, key = { it.id }) { message ->
                        MessageItem(
                            message = message,
                            compact = settings.density == com.frebee.ai.domain.MessageDensity.Compact,
                            onCopy = { clipboard.setText(AnnotatedString(message.content)) },
                            onRegenerate = { chatVm.regenerate() },
                            onEdit = { editTarget = message },
                            onSpeak = { speaker.speak(message.content) },
                            onDownloadCode = { language, code ->
                                pendingDownload = language to code
                                saveCodeLauncher.launch("frebee-snippet.${extensionFor(language)}")
                            },
                            onOpenUrl = { url ->
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                }
                            },
                        )
                    }
                    if (streaming) {
                        item("status") {
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(14.dp),
                                    strokeWidth = 2.dp,
                                    color = palette.accent,
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    statusLine ?: "Generating…",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.onSurfaceMuted,
                                )
                            }
                        }
                    }
                }
            }
        }

        if (listening) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(8.dp).background(palette.danger, CircleShape))
                Spacer(Modifier.width(8.dp))
                Text(
                    partial.ifBlank { "Listening… speak now" },
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.onSurfaceMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }

        if (pendingAttachments.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                pendingAttachments.forEach { attachment ->
                    AttachmentChip(attachment = attachment, onRemove = { chatVm.removeAttachment(attachment.id) })
                }
            }
        }

        Composer(
            draft = draft,
            onDraftChange = { draft = it },
            streaming = streaming,
            mode = settings.mode,
            effort = settings.effort,
            webSearch = settings.webSearch,
            modelLabel = models.firstOrNull { it.id == settings.modelId }?.label ?: "Auto",
            models = models.map { it.id to it.label },
            selectedModel = settings.modelId,
            onModeChange = { mode -> app.updateSettings { it.copy(mode = mode) } },
            onEffortChange = { effort -> app.updateSettings { it.copy(effort = effort) } },
            onWebSearchChange = { enabled -> app.updateSettings { it.copy(webSearch = enabled) } },
            onModelChange = { model -> app.updateSettings { it.copy(modelId = model) } },
            onSend = {
                val text = draft
                draft = ""
                chatVm.send(text)
            },
            onStop = { chatVm.stop() },
            onAttachFile = { filePicker.launch(arrayOf("*/*")) },
            onAttachPhoto = {
                photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
            onCamera = {
                val uri = Attachments.createCaptureUri(context)
                if (uri != null) {
                    captureUri = uri
                    cameraLauncher.launch(uri)
                }
            },
            speakReplies = settings.speakReplies,
            listening = listening,
            onMic = {
                if (listening) {
                    speech.stop()
                    listening = false
                } else {
                    val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                        PackageManager.PERMISSION_GRANTED
                    if (granted) startListening() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                }
            },
            onSpeakToggle = {
                speaker.stop()
                app.updateSettings { it.copy(speakReplies = !it.speakReplies) }
            },
        )
    }

    if (showRename) {
        var value by remember { mutableStateOf(title) }
        AlertDialog(
            onDismissRequest = { showRename = false },
            title = { Text("Rename conversation") },
            text = { OutlinedTextField(value = value, onValueChange = { value = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    chatVm.rename(value)
                    showRename = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showRename = false }) { Text("Cancel") } },
        )
    }

    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Delete conversation?") },
            text = { Text("This removes the conversation and its messages for your account.") },
            confirmButton = {
                TextButton(onClick = {
                    chatVm.delete()
                    showDelete = false
                }) { Text("Delete", color = palette.danger) }
            },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Cancel") } },
        )
    }

    editTarget?.let { target ->
        var value by remember(target.id) { mutableStateOf(target.content) }
        AlertDialog(
            onDismissRequest = { editTarget = null },
            title = { Text("Edit message") },
            text = {
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it },
                    modifier = Modifier.height(160.dp),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    chatVm.editAndResend(target, value)
                    editTarget = null
                }) { Text("Send again") }
            },
            dismissButton = { TextButton(onClick = { editTarget = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun ChatHeader(
    title: String,
    subtitle: String,
    modelLabel: String,
    onOpenDrawer: () -> Unit,
    menuOpen: Boolean,
    onMenuOpenChange: (Boolean) -> Unit,
    hasConversation: Boolean,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onArchive: () -> Unit,
) {
    val palette = LocalFrebeePalette.current
    Row(
        Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onOpenDrawer) {
            Icon(Icons.Default.Menu, contentDescription = "Open navigation", tint = palette.onSurface)
        }
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                color = palette.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                "$subtitle · $modelLabel",
                style = MaterialTheme.typography.labelSmall,
                color = palette.onSurfaceMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Box {
            IconButton(onClick = { onMenuOpenChange(true) }) {
                Icon(Icons.Default.MoreVert, contentDescription = "Conversation actions", tint = palette.onSurfaceMuted)
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { onMenuOpenChange(false) }) {
                DropdownMenuItem(
                    text = { Text("Rename") },
                    enabled = hasConversation,
                    onClick = { onMenuOpenChange(false); onRename() },
                )
                DropdownMenuItem(
                    text = { Text("Archive") },
                    enabled = hasConversation,
                    onClick = { onMenuOpenChange(false); onArchive() },
                )
                DropdownMenuItem(
                    text = { Text("Delete") },
                    enabled = hasConversation,
                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null) },
                    onClick = { onMenuOpenChange(false); onDelete() },
                )
            }
        }
    }
}

@Composable
private fun EmptyChat(suggestions: List<String>, onSuggestion: (String) -> Unit) {
    val palette = LocalFrebeePalette.current
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        BrandMark(size = 52.dp, style = UiStyle.Futuristic)
        Spacer(Modifier.height(16.dp))
        Text(
            "What can I help with?",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.SemiBold,
            color = palette.onSurface,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "Ask anything, research a topic, or describe software you want built.",
            style = MaterialTheme.typography.bodyMedium,
            color = palette.onSurfaceMuted,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(22.dp))
        suggestions.chunked(2).forEach { row ->
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                row.forEach { suggestion ->
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .padding(vertical = 2.dp)
                            .clickable { onSuggestion(suggestion) },
                        color = palette.surface,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, palette.outline),
                    ) {
                        Text(
                            suggestion,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp),
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.onSurface,
                        )
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun MessageItem(
    message: UiMessage,
    compact: Boolean,
    onCopy: () -> Unit,
    onRegenerate: () -> Unit,
    onEdit: () -> Unit,
    onSpeak: () -> Unit,
    onDownloadCode: (String, String) -> Unit,
    onOpenUrl: (String) -> Unit,
) {
    val palette = LocalFrebeePalette.current
    val vertical = if (compact) 4.dp else 10.dp

    Row(
        Modifier.fillMaxWidth().padding(vertical = vertical),
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start,
    ) {
        if (!message.isUser) {
            BrandMark(size = 22.dp)
            Spacer(Modifier.width(8.dp))
        }
        Column(
            Modifier
                .widthIn(max = if (message.isUser) 560.dp else 660.dp)
                .then(
                    if (message.isUser) {
                        Modifier
                            .background(palette.userBubble, RoundedCornerShape(18.dp))
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    } else {
                        Modifier.padding(vertical = 2.dp)
                    },
                ),
        ) {
            if (message.attachments.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    message.attachments.forEach { attachment ->
                        if (attachment.isImage && attachment.localUri != null) {
                            AsyncImage(
                                model = Uri.parse(attachment.localUri),
                                contentDescription = attachment.name,
                                modifier = Modifier.size(64.dp).background(palette.surfaceVariant, RoundedCornerShape(10.dp)),
                            )
                        } else {
                            Text(
                                "📎 ${attachment.name}",
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.onSurfaceMuted,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
            }

            if (message.content.isBlank() && message.streaming) {
                Text("…", style = MaterialTheme.typography.bodyLarge, color = palette.onSurfaceMuted)
            } else if (message.isUser) {
                Text(
                    message.content,
                    style = MaterialTheme.typography.bodyLarge,
                    color = palette.userBubbleText,
                )
            } else {
                MarkdownText(
                    markdown = message.content,
                    onDownloadCode = onDownloadCode,
                )
            }

            if (message.toolTrace.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Column {
                    message.toolTrace.forEach { tool ->
                        Text(
                            "▸ ${tool.name}${if (tool.detail.isBlank()) "" else ": ${tool.detail.take(120)}"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.onSurfaceMuted,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }

            if (message.citations.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    message.citations.forEach { citation ->
                        Surface(
                            color = palette.accent.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.clickable {
                                citation.url?.let(onOpenUrl)
                            },
                        ) {
                            Text(
                                "[${citation.index}] ${citation.title.take(28)}",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.accent,
                                maxLines = 1,
                            )
                        }
                    }
                }
            }

            if (message.error) {
                Spacer(Modifier.height(6.dp))
                Text("Failed", style = MaterialTheme.typography.labelSmall, color = palette.danger)
            }

            if (!message.streaming && message.content.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    MessageAction(Icons.Default.ContentCopy, "Copy", onCopy)
                    if (message.isUser) {
                        MessageAction(Icons.Default.Edit, "Edit", onEdit)
                    } else {
                        MessageAction(Icons.Default.Refresh, "Regenerate", onRegenerate)
                        MessageAction(Icons.Default.VolumeUp, "Read aloud", onSpeak)
                    }
                    Spacer(Modifier.width(4.dp))
                    message.model?.let {
                        Text(it, style = MaterialTheme.typography.labelSmall, color = palette.onSurfaceMuted, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    onClick: () -> Unit,
) {
    val palette = LocalFrebeePalette.current
    IconButton(onClick = onClick, modifier = Modifier.size(28.dp)) {
        Icon(icon, contentDescription = description, tint = palette.onSurfaceMuted, modifier = Modifier.size(15.dp))
    }
}

@Composable
private fun AttachmentChip(attachment: Attachment, onRemove: () -> Unit) {
    val palette = LocalFrebeePalette.current
    Surface(color = palette.surfaceVariant, shape = RoundedCornerShape(10.dp)) {
        Row(Modifier.padding(start = 10.dp, end = 4.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (attachment.isImage) Icons.Default.Image else Icons.Default.AttachFile,
                contentDescription = null,
                tint = palette.onSurfaceMuted,
                modifier = Modifier.size(14.dp),
            )
            Spacer(Modifier.width(6.dp))
            Text(
                attachment.name.take(18),
                style = MaterialTheme.typography.labelSmall,
                color = palette.onSurface,
                maxLines = 1,
            )
            if (attachment.uploadState == UploadState.Uploading) {
                Spacer(Modifier.width(6.dp))
                CircularProgressIndicator(modifier = Modifier.size(10.dp), strokeWidth = 1.5.dp, color = palette.accent)
            }
            if (attachment.uploadState == UploadState.Failed) {
                Spacer(Modifier.width(6.dp))
                Text("failed", style = MaterialTheme.typography.labelSmall, color = palette.danger)
            }
            IconButton(onClick = onRemove, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Default.Delete, contentDescription = "Remove attachment", tint = palette.onSurfaceMuted, modifier = Modifier.size(13.dp))
            }
        }
    }
}

@Composable
private fun Composer(
    draft: String,
    onDraftChange: (String) -> Unit,
    streaming: Boolean,
    mode: ChatMode,
    effort: ThinkingEffort,
    webSearch: Boolean,
    modelLabel: String,
    models: List<Pair<String, String>>,
    selectedModel: String,
    onModeChange: (ChatMode) -> Unit,
    onEffortChange: (ThinkingEffort) -> Unit,
    onWebSearchChange: (Boolean) -> Unit,
    onModelChange: (String) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onAttachFile: () -> Unit,
    onAttachPhoto: () -> Unit,
    onCamera: () -> Unit,
    speakReplies: Boolean,
    listening: Boolean,
    onMic: () -> Unit,
    onSpeakToggle: () -> Unit,
) {
    val palette = LocalFrebeePalette.current
    var attachMenu by remember { mutableStateOf(false) }
    var modeMenu by remember { mutableStateOf(false) }
    var modelMenu by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 10.dp, vertical = 6.dp)) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box {
                ComposerChip(
                    text = mode.label,
                    active = mode != ChatMode.Balanced,
                    onClick = { modeMenu = true },
                )
                DropdownMenu(expanded = modeMenu, onDismissRequest = { modeMenu = false }) {
                    ChatMode.entries.forEach { entry ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(entry.label)
                                    Text(entry.hint, style = MaterialTheme.typography.labelSmall, color = palette.onSurfaceMuted)
                                }
                            },
                            onClick = { onModeChange(entry); modeMenu = false },
                        )
                    }
                }
            }
            ThinkingEffortChip(effort = effort, onChange = onEffortChange)
            ComposerChip(
                text = if (webSearch) "Web on" else "Web off",
                active = webSearch,
                onClick = { onWebSearchChange(!webSearch) },
            )
            Box {
                ComposerChip(
                    text = if (selectedModel.isBlank()) "Auto model" else modelLabel,
                    active = false,
                    onClick = { modelMenu = true },
                )
                DropdownMenu(expanded = modelMenu, onDismissRequest = { modelMenu = false }) {
                    DropdownMenuItem(text = { Text("Auto (server picks)") }, onClick = { onModelChange(""); modelMenu = false })
                    models.forEach { (id, label) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { onModelChange(id); modelMenu = false })
                    }
                }
            }
            ComposerChip(
                text = if (speakReplies) "Voice reply on" else "Voice reply",
                active = speakReplies,
                onClick = onSpeakToggle,
            )
        }

        Surface(
            color = palette.surface,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, palette.outline, RoundedCornerShape(20.dp)),
        ) {
            Row(Modifier.padding(start = 4.dp, end = 4.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.Bottom) {
                Box {
                    IconButton(onClick = { attachMenu = true }) {
                        Icon(Icons.Default.AttachFile, contentDescription = "Attach", tint = palette.onSurfaceMuted)
                    }
                    DropdownMenu(expanded = attachMenu, onDismissRequest = { attachMenu = false }) {
                        DropdownMenuItem(
                            text = { Text("Photo library") },
                            leadingIcon = { Icon(Icons.Default.Image, contentDescription = null) },
                            onClick = { attachMenu = false; onAttachPhoto() },
                        )
                        DropdownMenuItem(
                            text = { Text("Take photo") },
                            onClick = { attachMenu = false; onCamera() },
                        )
                        DropdownMenuItem(
                            text = { Text("Choose file") },
                            onClick = { attachMenu = false; onAttachFile() },
                        )
                    }
                }

                OutlinedTextField(
                    value = draft,
                    onValueChange = onDraftChange,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Message Frebee…", color = palette.onSurfaceMuted) },
                    maxLines = 6,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
                    colors = androidx.compose.material3.TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                    ),
                )

                IconButton(onClick = onMic) {
                    Icon(
                        Icons.Default.Mic,
                        contentDescription = if (listening) "Stop dictation" else "Dictate",
                        tint = if (listening) palette.danger else palette.onSurfaceMuted,
                    )
                }

                Box(
                    Modifier
                        .size(42.dp)
                        .background(if (streaming) palette.danger else palette.accent, CircleShape)
                        .clickable(enabled = streaming || draft.isNotBlank()) {
                            if (streaming) onStop() else onSend()
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (streaming) Icons.Default.Stop else Icons.Default.ArrowUpward,
                        contentDescription = if (streaming) "Stop generating" else "Send",
                        tint = palette.onAccent,
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
        }
        Text(
            "Frebee can make mistakes. Verify important information.",
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            style = MaterialTheme.typography.labelSmall,
            color = palette.onSurfaceMuted,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}

@Composable
private fun ThinkingEffortChip(effort: ThinkingEffort, onChange: (ThinkingEffort) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        ComposerChip(text = "Effort: ${effort.label}", active = effort == ThinkingEffort.High, onClick = { open = true })
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            ThinkingEffort.entries.forEach { entry ->
                DropdownMenuItem(text = { Text(entry.label) }, onClick = { onChange(entry); open = false })
            }
        }
    }
}

@Composable
private fun ComposerChip(text: String, active: Boolean, onClick: () -> Unit) {
    val palette = LocalFrebeePalette.current
    Surface(
        color = if (active) palette.accent.copy(alpha = 0.16f) else palette.surfaceVariant,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.clickable { onClick() },
    ) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelSmall,
            color = if (active) palette.accent else palette.onSurfaceMuted,
            maxLines = 1,
        )
    }
}

private fun extensionFor(language: String): String = when (language.lowercase()) {
    "kotlin", "kt" -> "kt"
    "python", "py" -> "py"
    "javascript", "js" -> "js"
    "typescript", "ts" -> "ts"
    "json" -> "json"
    "html" -> "html"
    "css" -> "css"
    "xml" -> "xml"
    "sql" -> "sql"
    "bash", "sh", "shell" -> "sh"
    "yaml", "yml" -> "yml"
    "markdown", "md" -> "md"
    else -> "txt"
}
