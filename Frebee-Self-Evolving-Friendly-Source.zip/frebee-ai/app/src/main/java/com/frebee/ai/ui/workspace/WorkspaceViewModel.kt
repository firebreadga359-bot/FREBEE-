package com.frebee.ai.ui.workspace

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.frebee.ai.AppContainer
import com.frebee.ai.data.remote.FileContentDto
import com.frebee.ai.domain.ProjectInfo
import com.frebee.ai.domain.WorkspaceFile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class WorkspaceViewModel(private val container: AppContainer) : ViewModel() {

    private val _selected = MutableStateFlow<ProjectInfo?>(null)
    val selected: StateFlow<ProjectInfo?> = _selected.asStateFlow()

    private val _files = MutableStateFlow<List<WorkspaceFile>>(emptyList())
    val files: StateFlow<List<WorkspaceFile>> = _files.asStateFlow()

    private val _openFile = MutableStateFlow<FileContentDto?>(null)
    val openFile: StateFlow<FileContentDto?> = _openFile.asStateFlow()

    private val _editorText = MutableStateFlow("")
    val editorText: StateFlow<String> = _editorText.asStateFlow()

    private val _log = MutableStateFlow("")
    val log: StateFlow<String> = _log.asStateFlow()

    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    private val _status = MutableStateFlow<String?>(null)
    val status: StateFlow<String?> = _status.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun dismissError() {
        _error.value = null
    }

    fun select(project: ProjectInfo) {
        _selected.value = project
        _openFile.value = null
        _editorText.value = ""
        _log.value = ""
        refreshFiles()
    }

    fun createProject(name: String, kind: String) {
        viewModelScope.launch {
            try {
                val project = container.projects.create(name.ifBlank { "Untitled project" }, kind)
                select(project)
                _log.value = "Created project ${project.name} (${project.kind})\n"
            } catch (e: Exception) {
                _error.value = e.message ?: "Could not create the project"
            }
        }
    }

    fun refreshFiles() {
        val project = _selected.value ?: return
        viewModelScope.launch {
            try {
                _files.value = container.api.workspaceFiles(project.id)
                    .map { WorkspaceFile(it.path, it.size, it.directory) }
                    .sortedBy { it.path }
            } catch (e: Exception) {
                _error.value = e.message ?: "Could not list files"
            }
        }
    }

    fun open(path: String) {
        val project = _selected.value ?: return
        viewModelScope.launch {
            try {
                val file = container.api.readWorkspaceFile(project.id, path)
                _openFile.value = file
                _editorText.value = file.content
            } catch (e: Exception) {
                _error.value = e.message ?: "Could not open the file"
            }
        }
    }

    fun updateEditor(text: String) {
        _editorText.value = text
    }

    fun save() {
        val project = _selected.value ?: return
        val file = _openFile.value ?: return
        viewModelScope.launch {
            try {
                container.api.writeWorkspaceFile(project.id, file.path, _editorText.value)
                _status.value = "Saved ${file.path}"
                refreshFiles()
            } catch (e: Exception) {
                _error.value = e.message ?: "Save failed"
            }
        }
    }

    fun run(command: String) {
        val project = _selected.value ?: return
        if (command.isBlank() || _running.value) return
        viewModelScope.launch {
            _running.value = true
            _log.value += "\n$ $command\n"
            try {
                val result = container.api.runCommand(project.id, command)
                _log.value += buildString {
                    if (result.stdout.isNotBlank()) append(result.stdout.trimEnd()).append('\n')
                    if (result.stderr.isNotBlank()) append(result.stderr.trimEnd()).append('\n')
                    append("[exit ${result.exitCode} in ${result.durationMs} ms]\n")
                }
            } catch (e: Exception) {
                _log.value += "Error: ${e.message}\n"
            } finally {
                _running.value = false
                refreshFiles()
            }
        }
    }

    fun runAgentTask(prompt: String) {
        val project = _selected.value ?: return
        if (prompt.isBlank() || _running.value) return
        viewModelScope.launch {
            _running.value = true
            _log.value += "\n▶ Task: $prompt\n"
            try {
                container.api.runAgentTask(project.id, prompt, "coding").collect { event ->
                    when (event.type) {
                        "delta" -> _log.value += event.text.orEmpty()
                        "tool" -> _log.value += "\n[${event.tool?.name}] ${event.tool?.detail}\n"
                        "status" -> _status.value = event.text
                        "error" -> _log.value += "\nError: ${event.error}\n"
                        "done" -> _log.value += "\n✔ Finished\n"
                        else -> Unit
                    }
                }
            } catch (e: Exception) {
                _log.value += "\nError: ${e.message}\n"
            } finally {
                _running.value = false
                _status.value = null
                refreshFiles()
            }
        }
    }

    fun stop() {
        container.api.cancelStream()
        _running.value = false
        _status.value = null
    }

    suspend fun exportArchive(): ByteArray {
        val project = _selected.value ?: throw IllegalStateException("Select a project first")
        return container.api.downloadProjectArchive(project.id)
    }
}
