package com.frebee.ai.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.frebee.ai.ui.theme.LocalFrebeePalette
import com.frebee.ai.ui.theme.MonospaceFamily

sealed interface MdBlock {
    data class Heading(val level: Int, val text: String) : MdBlock
    data class Paragraph(val text: String) : MdBlock
    data class Bullets(val items: List<String>) : MdBlock
    data class Numbered(val items: List<String>) : MdBlock
    data class Code(val language: String, val code: String) : MdBlock
    data class Quote(val text: String) : MdBlock
    data class Table(val header: List<String>, val rows: List<List<String>>) : MdBlock
    data object Divider : MdBlock
}

/**
 * Small, dependency-free Markdown parser covering what chat answers actually use:
 * headings, lists, fenced code, quotes, pipe tables, rules and inline emphasis/links.
 */
object MarkdownParser {

    fun parse(markdown: String): List<MdBlock> {
        val blocks = mutableListOf<MdBlock>()
        val lines = markdown.replace("\r\n", "\n").split('\n')
        var i = 0
        val paragraph = StringBuilder()

        fun flushParagraph() {
            if (paragraph.isNotBlank()) {
                blocks += MdBlock.Paragraph(paragraph.toString().trim())
                paragraph.clear()
            }
        }

        while (i < lines.size) {
            val line = lines[i]
            val trimmed = line.trimStart()

            when {
                trimmed.startsWith("```") -> {
                    flushParagraph()
                    val language = trimmed.removePrefix("```").trim().substringBefore(' ')
                    val body = StringBuilder()
                    i++
                    while (i < lines.size && !lines[i].trimStart().startsWith("```")) {
                        body.append(lines[i]).append('\n')
                        i++
                    }
                    blocks += MdBlock.Code(language.ifBlank { "text" }, body.toString().trimEnd('\n'))
                }

                trimmed.startsWith("#") -> {
                    flushParagraph()
                    val level = trimmed.takeWhile { it == '#' }.length.coerceIn(1, 6)
                    blocks += MdBlock.Heading(level, trimmed.drop(level).trim())
                }

                trimmed == "---" || trimmed == "***" || trimmed == "___" -> {
                    flushParagraph()
                    blocks += MdBlock.Divider
                }

                trimmed.startsWith("> ") -> {
                    flushParagraph()
                    val body = StringBuilder()
                    while (i < lines.size && lines[i].trimStart().startsWith(">")) {
                        body.append(lines[i].trimStart().removePrefix(">").trim()).append(' ')
                        i++
                    }
                    i--
                    blocks += MdBlock.Quote(body.toString().trim())
                }

                isTableHeader(lines, i) -> {
                    flushParagraph()
                    val header = splitRow(line)
                    i += 2
                    val rows = mutableListOf<List<String>>()
                    while (i < lines.size && lines[i].contains('|') && lines[i].isNotBlank()) {
                        rows += splitRow(lines[i])
                        i++
                    }
                    i--
                    blocks += MdBlock.Table(header, rows)
                }

                isBullet(trimmed) -> {
                    flushParagraph()
                    val items = mutableListOf<String>()
                    while (i < lines.size && isBullet(lines[i].trimStart())) {
                        items += lines[i].trimStart().drop(2).trim()
                        i++
                    }
                    i--
                    blocks += MdBlock.Bullets(items)
                }

                isNumbered(trimmed) -> {
                    flushParagraph()
                    val items = mutableListOf<String>()
                    while (i < lines.size && isNumbered(lines[i].trimStart())) {
                        val value = lines[i].trimStart()
                        items += value.substringAfter('.').trim()
                        i++
                    }
                    i--
                    blocks += MdBlock.Numbered(items)
                }

                trimmed.isBlank() -> flushParagraph()

                else -> {
                    if (paragraph.isNotEmpty()) paragraph.append('\n')
                    paragraph.append(line)
                }
            }
            i++
        }
        flushParagraph()
        return blocks
    }

    private fun isBullet(line: String) =
        line.startsWith("- ") || line.startsWith("* ") || line.startsWith("+ ")

    private fun isNumbered(line: String): Boolean {
        val digits = line.takeWhile { it.isDigit() }
        return digits.isNotEmpty() && line.length > digits.length && line[digits.length] == '.' &&
            line.getOrNull(digits.length + 1) == ' '
    }

    private fun isTableHeader(lines: List<String>, index: Int): Boolean {
        if (!lines[index].contains('|')) return false
        val separator = lines.getOrNull(index + 1) ?: return false
        val cells = splitRow(separator)
        return cells.isNotEmpty() && cells.all { cell ->
            val c = cell.trim().trim(':')
            c.isNotEmpty() && c.all { it == '-' }
        }
    }

    fun splitRow(row: String): List<String> =
        row.trim().trim('|').split('|').map { it.trim() }
}

@Composable
fun MarkdownText(
    markdown: String,
    modifier: Modifier = Modifier,
    onDownloadCode: ((String, String) -> Unit)? = null,
) {
    val palette = LocalFrebeePalette.current
    val blocks = remember(markdown) { MarkdownParser.parse(markdown) }
    Column(modifier) {
        blocks.forEach { block ->
            when (block) {
                is MdBlock.Heading -> {
                    Text(
                        text = inline(block.text),
                        style = when (block.level) {
                            1 -> MaterialTheme.typography.headlineSmall
                            2 -> MaterialTheme.typography.titleLarge
                            else -> MaterialTheme.typography.titleMedium
                        },
                        color = palette.onSurface,
                        modifier = Modifier.padding(top = 10.dp, bottom = 4.dp),
                    )
                }

                is MdBlock.Paragraph -> Text(
                    text = inline(block.text),
                    style = MaterialTheme.typography.bodyLarge,
                    color = palette.onSurface,
                    modifier = Modifier.padding(vertical = 3.dp),
                )

                is MdBlock.Bullets -> Column(Modifier.padding(vertical = 2.dp)) {
                    block.items.forEach { item ->
                        Row(Modifier.padding(vertical = 1.dp)) {
                            Text("•", color = palette.accent, modifier = Modifier.width(14.dp))
                            Text(inline(item), style = MaterialTheme.typography.bodyLarge, color = palette.onSurface)
                        }
                    }
                }

                is MdBlock.Numbered -> Column(Modifier.padding(vertical = 2.dp)) {
                    block.items.forEachIndexed { index, item ->
                        Row(Modifier.padding(vertical = 1.dp)) {
                            Text("${index + 1}.", color = palette.accent, modifier = Modifier.width(22.dp))
                            Text(inline(item), style = MaterialTheme.typography.bodyLarge, color = palette.onSurface)
                        }
                    }
                }

                is MdBlock.Code -> CodeBlock(block.language, block.code, onDownloadCode)

                is MdBlock.Quote -> Row(Modifier.padding(vertical = 4.dp)) {
                    Box(
                        Modifier
                            .width(3.dp)
                            .height(20.dp)
                            .background(palette.accent.copy(alpha = 0.6f), RoundedCornerShape(2.dp)),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        inline(block.text),
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.onSurfaceMuted,
                        fontStyle = FontStyle.Italic,
                    )
                }

                is MdBlock.Table -> TableBlock(block)

                MdBlock.Divider -> Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .height(1.dp)
                        .background(palette.outline),
                )
            }
        }
    }
}

@Composable
private fun TableBlock(block: MdBlock.Table) {
    val palette = LocalFrebeePalette.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .horizontalScroll(rememberScrollState()),
    ) {
        Row(Modifier.background(palette.surfaceVariant, RoundedCornerShape(6.dp))) {
            block.header.forEach { cell ->
                Text(
                    cell,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = palette.onSurface,
                )
            }
        }
        block.rows.forEach { row ->
            Row {
                row.forEach { cell ->
                    Text(
                        cell,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.onSurface,
                    )
                }
            }
        }
    }
}

@Composable
fun CodeBlock(language: String, code: String, onDownload: ((String, String) -> Unit)?) {
    val palette = LocalFrebeePalette.current
    val clipboard = LocalClipboardManager.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .background(palette.codeBackground, RoundedCornerShape(12.dp)),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                language.lowercase(),
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF8FA3C8),
            )
            Row {
                IconButton(onClick = { clipboard.setText(AnnotatedString(code)) }, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy code", tint = Color(0xFF8FA3C8), modifier = Modifier.size(15.dp))
                }
                if (onDownload != null) {
                    IconButton(onClick = { onDownload(language, code) }, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Download, contentDescription = "Download code", tint = Color(0xFF8FA3C8), modifier = Modifier.size(15.dp))
                    }
                }
            }
        }
        Box(Modifier.horizontalScroll(rememberScrollState())) {
            Text(
                text = highlight(code, language),
                modifier = Modifier.padding(start = 12.dp, end = 12.dp, top = 2.dp, bottom = 12.dp),
                fontFamily = MonospaceFamily,
                fontSize = 12.sp,
                lineHeight = 18.sp,
            )
        }
    }
}

@Composable
private fun inline(text: String): AnnotatedString {
    val palette = LocalFrebeePalette.current
    return buildAnnotatedString {
        var index = 0
        val buffer = StringBuilder()

        fun flush() {
            if (buffer.isNotEmpty()) {
                append(buffer.toString())
                buffer.clear()
            }
        }

        while (index < text.length) {
            val rest = text.substring(index)
            when {
                rest.startsWith("**") -> {
                    val end = rest.indexOf("**", 2)
                    if (end > 0) {
                        flush()
                        withStyle(SpanStyle(fontWeight = FontWeight.SemiBold)) {
                            append(text.substring(index + 2, index + end))
                        }
                        index += end + 2
                    } else {
                        buffer.append(rest.first()); index++
                    }
                }
                rest.startsWith("`") -> {
                    val end = rest.indexOf('`', 1)
                    if (end > 0) {
                        flush()
                        withStyle(SpanStyle(fontFamily = MonospaceFamily, color = palette.accent)) {
                            append(text.substring(index + 1, index + end))
                        }
                        index += end + 1
                    } else {
                        buffer.append(rest.first()); index++
                    }
                }
                rest.startsWith("[") -> {
                    val close = rest.indexOf(']')
                    val open = rest.indexOf('(')
                    val end = rest.indexOf(')')
                    if (close in 1 until open && open < end) {
                        flush()
                        val label = rest.substring(1, close)
                        val url = rest.substring(open + 1, end)
                        if (url.startsWith("http")) {
                            withLink(LinkAnnotation.Url(url)) {
                                withStyle(SpanStyle(color = palette.accent, fontWeight = FontWeight.Medium)) {
                                    append(label)
                                }
                            }
                        } else {
                            append(label)
                        }
                        index += end + 1
                    } else {
                        buffer.append(rest.first()); index++
                    }
                }
                rest.startsWith("*") && !rest.startsWith("**") -> {
                    val end = rest.indexOf('*', 1)
                    if (end > 0) {
                        flush()
                        withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                            append(text.substring(index + 1, index + end))
                        }
                        index += end + 1
                    } else {
                        buffer.append(rest.first()); index++
                    }
                }
                else -> {
                    buffer.append(rest.first()); index++
                }
            }
        }
        flush()
    }
}

private val KEYWORDS = setOf(
    "fun", "val", "var", "class", "object", "interface", "if", "else", "when", "for", "while",
    "return", "import", "package", "suspend", "override", "private", "public", "internal", "data",
    "def", "lambda", "None", "True", "False", "elif", "try", "except", "with", "as", "from",
    "function", "const", "let", "await", "async", "export", "default", "new", "this", "type",
    "struct", "impl", "fn", "use", "mod", "match", "public", "static", "void", "int", "float",
)

private fun highlight(code: String, language: String): AnnotatedString = buildAnnotatedString {
    val commentColor = Color(0xFF6B7C99)
    val stringColor = Color(0xFF9BE8A8)
    val keywordColor = Color(0xFF7FB2FF)
    val numberColor = Color(0xFFE8B96B)
    val plain = Color(0xFFE3E9F5)

    var index = 0
    while (index < code.length) {
        val rest = code.substring(index)
        when {
            rest.startsWith("//") || (rest.startsWith("#") && language in setOf("python", "sh", "bash", "yaml", "toml", "py")) -> {
                val end = rest.indexOf('\n').let { if (it == -1) rest.length else it }
                withStyle(SpanStyle(color = commentColor)) { append(rest.substring(0, end)) }
                index += end
            }
            rest.startsWith("\"") || rest.startsWith("'") -> {
                val quote = rest.first()
                var end = 1
                while (end < rest.length && rest[end] != quote) {
                    if (rest[end] == '\\') end++
                    end++
                }
                end = (end + 1).coerceAtMost(rest.length)
                withStyle(SpanStyle(color = stringColor)) { append(rest.substring(0, end)) }
                index += end
            }
            rest.first().isDigit() -> {
                val match = Regex("^[0-9][0-9._a-fA-FxX]*").find(rest)?.value ?: rest.first().toString()
                withStyle(SpanStyle(color = numberColor)) { append(match) }
                index += match.length
            }
            rest.first().isLetter() || rest.first() == '_' -> {
                val word = Regex("^[A-Za-z_][A-Za-z0-9_]*").find(rest)?.value ?: rest.first().toString()
                if (KEYWORDS.contains(word)) {
                    withStyle(SpanStyle(color = keywordColor, fontWeight = FontWeight.Medium)) { append(word) }
                } else {
                    withStyle(SpanStyle(color = plain)) { append(word) }
                }
                index += word.length
            }
            else -> {
                withStyle(SpanStyle(color = plain)) { append(rest.first()) }
                index++
            }
        }
    }
}
