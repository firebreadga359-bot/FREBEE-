package com.frebee.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.frebee.ai.domain.AppSettings
import com.frebee.ai.domain.MessageDensity
import com.frebee.ai.domain.ThemeMode
import com.frebee.ai.domain.UiStyle

data class FrebeePalette(
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val onSurface: Color,
    val onSurfaceMuted: Color,
    val outline: Color,
    val accent: Color,
    val onAccent: Color,
    val userBubble: Color,
    val userBubbleText: Color,
    val assistantBubble: Color,
    val codeBackground: Color,
    val success: Color,
    val warning: Color,
    val danger: Color,
    val glow: Color,
)

val LocalFrebeePalette = staticCompositionLocalOf {
    paletteFor(UiStyle.Classic, dark = false, accentArgb = 0xFF5B8CFF)
}

val LocalReduceMotion = staticCompositionLocalOf { false }
val LocalDensity = staticCompositionLocalOf { MessageDensity.Comfortable }

fun paletteFor(style: UiStyle, dark: Boolean, accentArgb: Long): FrebeePalette {
    val accent = Color(accentArgb)
    return when {
        style == UiStyle.Futuristic && dark -> FrebeePalette(
            background = Color(0xFF060A14),
            surface = Color(0xFF0D1424),
            surfaceVariant = Color(0xFF16203A),
            onSurface = Color(0xFFE8EFFF),
            onSurfaceMuted = Color(0xFF97A6C6),
            outline = Color(0xFF25304C),
            accent = accent,
            onAccent = Color(0xFF04101C),
            userBubble = Color(0xFF152B4D),
            userBubbleText = Color(0xFFE9F2FF),
            assistantBubble = Color(0xFF0F1728),
            codeBackground = Color(0xFF070D19),
            success = Color(0xFF4ADE80),
            warning = Color(0xFFFBBF24),
            danger = Color(0xFFF87171),
            glow = accent.copy(alpha = 0.35f),
        )
        style == UiStyle.Futuristic && !dark -> FrebeePalette(
            background = Color(0xFFF2F6FF),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFE4ECFB),
            onSurface = Color(0xFF0B1526),
            onSurfaceMuted = Color(0xFF5A6B88),
            outline = Color(0xFFCBD8EE),
            accent = accent,
            onAccent = Color.White,
            userBubble = Color(0xFFE3EDFF),
            userBubbleText = Color(0xFF0B1526),
            assistantBubble = Color(0xFFFFFFFF),
            codeBackground = Color(0xFF0B1220),
            success = Color(0xFF15803D),
            warning = Color(0xFFB45309),
            danger = Color(0xFFB91C1C),
            glow = accent.copy(alpha = 0.18f),
        )
        dark -> FrebeePalette(
            background = Color(0xFF121316),
            surface = Color(0xFF1B1D21),
            surfaceVariant = Color(0xFF24262B),
            onSurface = Color(0xFFECEDEF),
            onSurfaceMuted = Color(0xFFA0A4AD),
            outline = Color(0xFF33363D),
            accent = accent,
            onAccent = Color.White,
            userBubble = Color(0xFF2B2F3A),
            userBubbleText = Color(0xFFF3F4F6),
            assistantBubble = Color(0xFF1B1D21),
            codeBackground = Color(0xFF101114),
            success = Color(0xFF4ADE80),
            warning = Color(0xFFFBBF24),
            danger = Color(0xFFF87171),
            glow = accent.copy(alpha = 0.22f),
        )
        else -> FrebeePalette(
            background = Color(0xFFF7F8FA),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFEFF1F5),
            onSurface = Color(0xFF15171C),
            onSurfaceMuted = Color(0xFF6B7280),
            outline = Color(0xFFDDE1E8),
            accent = accent,
            onAccent = Color.White,
            userBubble = Color(0xFFE8EFFC),
            userBubbleText = Color(0xFF15171C),
            assistantBubble = Color(0xFFFFFFFF),
            codeBackground = Color(0xFF11141A),
            success = Color(0xFF15803D),
            warning = Color(0xFFB45309),
            danger = Color(0xFFB91C1C),
            glow = accent.copy(alpha = 0.12f),
        )
    }
}

fun isDarkResolved(settings: AppSettings, systemDark: Boolean): Boolean = when (settings.themeMode) {
    ThemeMode.System -> systemDark
    ThemeMode.Light -> false
    ThemeMode.Dark -> true
}

private fun typography(scale: Float): Typography {
    fun size(value: Float) = (value * scale).sp
    return Typography(
        headlineSmall = TextStyle(fontSize = size(22f), lineHeight = size(30f), fontWeight = FontWeight.SemiBold),
        titleLarge = TextStyle(fontSize = size(20f), lineHeight = size(28f), fontWeight = FontWeight.SemiBold),
        titleMedium = TextStyle(fontSize = size(16f), lineHeight = size(24f), fontWeight = FontWeight.Medium),
        bodyLarge = TextStyle(fontSize = size(16f), lineHeight = size(24f)),
        bodyMedium = TextStyle(fontSize = size(14f), lineHeight = size(21f)),
        bodySmall = TextStyle(fontSize = size(12f), lineHeight = size(17f)),
        labelLarge = TextStyle(fontSize = size(14f), lineHeight = size(18f), fontWeight = FontWeight.Medium),
        labelSmall = TextStyle(fontSize = size(11f), lineHeight = size(15f)),
    )
}

val MonospaceFamily: FontFamily = FontFamily.Monospace

@Composable
fun FrebeeTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = isDarkResolved(settings, isSystemInDarkTheme())
    val palette = paletteFor(settings.style, dark, settings.accentArgb)
    val scheme = if (dark) {
        darkColorScheme(
            primary = palette.accent,
            onPrimary = palette.onAccent,
            background = palette.background,
            onBackground = palette.onSurface,
            surface = palette.surface,
            onSurface = palette.onSurface,
            surfaceVariant = palette.surfaceVariant,
            onSurfaceVariant = palette.onSurfaceMuted,
            outline = palette.outline,
            error = palette.danger,
        )
    } else {
        lightColorScheme(
            primary = palette.accent,
            onPrimary = palette.onAccent,
            background = palette.background,
            onBackground = palette.onSurface,
            surface = palette.surface,
            onSurface = palette.onSurface,
            surfaceVariant = palette.surfaceVariant,
            onSurfaceVariant = palette.onSurfaceMuted,
            outline = palette.outline,
            error = palette.danger,
        )
    }
    CompositionLocalProvider(
        LocalFrebeePalette provides palette,
        LocalReduceMotion provides settings.reduceMotion,
        LocalDensity provides settings.density,
    ) {
        MaterialTheme(
            colorScheme = scheme,
            typography = typography(settings.fontScale),
            content = content,
        )
    }
}
