package com.frebee.ai.ui.workspace

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.frebee.ai.FrebeeApplication
import com.frebee.ai.ui.AppViewModel
import com.frebee.ai.ui.common.ChoiceRow
import com.frebee.ai.ui.common.InlineBanner
import com.frebee.ai.ui.common.SectionHeader
import com.frebee.ai.ui.theme.LocalFrebeePalette
import com.frebee.ai.ui.theme.MonospaceFamily
import kotlinx.coroutines.launch
import java.io.File

private enum class WorkspaceTab { Files, Editor, Run, Agent }

@Composable
fun WorkspaceScreen(app: AppViewModel, onBack: () -> Unit) {
    val palette = LocalFrebeePalette.current
    val context = LocalContext.current
    val container = (context.applicationContext as FrebeeApplication).container
    val vm: WorkspaceViewModel = viewModel(factory = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = WorkspaceViewModel(container) as T
    })

    val projects by app.projects.collectAsStateWithLifecycle()
    val selected by vm.selected.collectAsStateWithLifecycle()
    val files by vm.files.collectAsStateWithLifecycle()
    val openFile by vm.openFile.collectAsStateWithLifecycle()
    val editorText by vm.editorText.collectAsStateWithLifecycle()
    val log by vm.log.collectAsStateWithLifecycle()
    val running by vm.running.collectAsStateWithLifecycle()
    val status by vm.status.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()

    var tab by remember { mutableStateOf(WorkspaceTab.Files) }
    var showNewProject by remember { mutableStateOf(false) }
    var command by remember { mutableStateOf("ls -la") }
    var taskPrompt by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 4.dp, top = 8.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = palette.onSurface)
            }
            Column(Modifier.weight(1f)) {
                Text("Coding workspace", style = MaterialTheme.typography.titleLarge, color = palette.onSurface)
                Text(
                    selected?.let { "${it.name} · ${it.kind}" } ?: "Select or create a sandboxed project",
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.onSurfaceMuted,
                )
            }
            if (running) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
            }
        }

        error?.let {
            Box(Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                InlineBanner(text = it, isError = true, onDismiss = { vm.dismissError() })
            }
        }

        if (selected == null) {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                item("actions") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { showNewProject = true }, shape = RoundedCornerShape(10.dp)) {
                            Text("New project")
                        }
                        OutlinedButton(onClick = { app.refreshProjects() }, shape = RoundedCornerShape(10.dp)) {
                            Text("Refresh")
                        }
                    }
                }
                if (projects.isEmpty()) {
                    item("empty") {
                        Text(
                            "No projects yet. Create one to get an isolated workspace where Frebee can write files and run builds.",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.onSurfaceMuted,
                        )
                    }
                }
                items(projects, key = { it.id }) { project ->
                    Surface(
                        color = palette.surface,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().clickable { vm.select(project) },
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Folder, contentDescription = null, tint = palette.accent)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(project.name, style = MaterialTheme.typography.bodyLarge, color = palette.onSurface)
                                Text(
                                    project.kind,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = palette.onSurfaceMuted,
                                )
                            }
                        }
                    }
                }
            }
        } else {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                WorkspaceTab.entries.forEach { entry ->
                    val active = tab == entry
                    Surface(
                        color = if (active) palette.accent.copy(alpha = 0.16f) else palette.surfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.clickable { tab = entry },
                    ) {
                        Text(
                            entry.name,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = if (active) palette.accent else palette.onSurfaceMuted,
                        )
                    }
                }
                Surface(
                    color = palette.surfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.clickable {
                        scope.launch {
                            runCatching { vm.exportArchive() }
                                .onSuccess { bytes ->
                                    val dir = File(context.cacheDir, "exports").apply { mkdirs() }
                                    val file = File(dir, "${selected?.name?.replace(' ', '-') ?: "project"}.zip")
                                    file.writeBytes(bytes)
                                    val uri = FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.fileprovider",
                                        file,
                                    )
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "application/zip"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(intent, "Share project archive"))
                                }
                        }
                    },
                ) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Share, contentDescription = null, tint = palette.onSurfaceMuted, modifier = Modifier.size(13.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Export", style = MaterialTheme.typography.labelSmall, color = palette.onSurfaceMuted)
                    }
                }
                Surface(
                    color = palette.surfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.clickable { vm.refreshFiles() },
                ) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = palette.onSurfaceMuted, modifier = Modifier.size(13.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Files", style = MaterialTheme.typography.labelSmall, color = palette.onSurfaceMuted)
                    }
                }
            }

            when (tab) {
                WorkspaceTab.Files -> LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                ) {
                    items(files, key = { it.path }) { file ->
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable(enabled = !file.directory) { vm.open(file.path); tab = WorkspaceTab.Editor }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                if (file.directory) Icons.Default.Folder else Icons.Default.Description,
                                contentDescription = null,
                                tint = palette.onSurfaceMuted,
                                modifier = Modifier.size(16.dp),
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                file.path,
                                modifier = Modifier.weight(1f),
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            if (!file.directory) {
                                Text(
                                    "${file.sizeBytes} B",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = palette.onSurfaceMuted,
                                )
                            }
                        }
                    }
                }

                WorkspaceTab.Editor -> Column(Modifier.fillMaxSize().padding(12.dp)) {
                    if (openFile == null) {
                        Text(
                            "Open a file from the Files tab to edit it.",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.onSurfaceMuted,
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                openFile!!.path,
                                modifier = Modifier.weight(1f),
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.onSurfaceMuted,
                            )
                            TextButton(onClick = { vm.save() }) { Text("Save") }
                        }
                        OutlinedTextField(
                            value = editorText,
                            onValueChange = { vm.updateEditor(it) },
                            modifier = Modifier.fillMaxSize(),
                            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = MonospaceFamily),
                        )
                    }
                }

                WorkspaceTab.Run -> Column(Modifier.fillMaxSize().padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = command,
                            onValueChange = { command = it },
                            label = { Text("Shell command") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = { vm.run(command) },
                            enabled = !running,
                            shape = RoundedCornerShape(10.dp),
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Run")
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Commands run inside the project sandbox with a timeout, no network escalation and no access outside the workspace.",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.onSurfaceMuted,
                    )
                    Spacer(Modifier.height(8.dp))
                    LogPanel(log)
                }

                WorkspaceTab.Agent -> Column(Modifier.fillMaxSize().padding(12.dp)) {
                    OutlinedTextField(
                        value = taskPrompt,
                        onValueChange = { taskPrompt = it },
                        label = { Text("Describe the change you want") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4,
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                vm.runAgentTask(taskPrompt)
                                taskPrompt = ""
                            },
                            enabled = !running && taskPrompt.isNotBlank(),
                            shape = RoundedCornerShape(10.dp),
                        ) {
                            Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Run agent")
                        }
                        if (running) {
                            OutlinedButton(onClick = { vm.stop() }, shape = RoundedCornerShape(10.dp)) {
                                Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Stop")
                            }
                        }
                    }
                    status?.let {
                        Spacer(Modifier.height(6.dp))
                        Text(it, style = MaterialTheme.typography.labelSmall, color = palette.accent)
                    }
                    Spacer(Modifier.height(8.dp))
                    LogPanel(log)
                }
            }
        }
    }

    if (showNewProject) {
        var name by remember { mutableStateOf("") }
        var kind by remember { mutableStateOf("web") }
        AlertDialog(
            onDismissRequest = { showNewProject = false },
            title = { Text("New project") },
            text = {
                Column {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Project name") },
                        singleLine = true,
                    )
                    Spacer(Modifier.height(10.dp))
                    SectionHeader("Template")
                    ChoiceRow(
                        options = listOf("web", "api", "python"),
                        selected = kind,
                        onSelect = { kind = it },
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.createProject(name, kind)
                    showNewProject = false
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showNewProject = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun LogPanel(log: String) {
    val palette = LocalFrebeePalette.current
    Box(
        Modifier
            .fillMaxWidth()
            .background(palette.codeBackground, RoundedCornerShape(10.dp))
            .padding(10.dp),
    ) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            SelectionContainer {
                Text(
                    log.ifBlank { "Output appears here." },
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonospaceFamily),
                    color = if (palette.codeBackground.luminance() > 0.5f) palette.onSurface else androidx.compose.ui.graphics.Color(0xFFD8E2F2),
                )
            }
        }
    }
}

private fun androidx.compose.ui.graphics.Color.luminance(): Float =
    0.299f * red + 0.587f * green + 0.114f * blue
