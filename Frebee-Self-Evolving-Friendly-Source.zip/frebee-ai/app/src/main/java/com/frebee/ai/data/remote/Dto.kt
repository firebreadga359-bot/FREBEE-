package com.frebee.ai.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class UserDto(
    val id: String,
    val email: String,
    @SerialName("display_name") val displayName: String? = null,
    val role: String = "user",
    @SerialName("email_verified") val emailVerified: Boolean = false,
    @SerialName("is_guest") val isGuest: Boolean = false,
    @SerialName("created_at") val createdAt: Long = 0,
)

@Serializable
data class TokenDto(
    @SerialName("access_token") val accessToken: String,
    @SerialName("refresh_token") val refreshToken: String = "",
    @SerialName("token_type") val tokenType: String = "bearer",
    @SerialName("expires_in") val expiresIn: Int = 0,
    val user: UserDto? = null,
)

@Serializable
data class LoginRequest(val email: String, val password: String)

@Serializable
data class RegisterRequest(
    val email: String,
    val password: String,
    @SerialName("display_name") val displayName: String,
)

@Serializable
data class MessageRequest(
    val content: String,
    val model: String? = null,
    val mode: String = "balanced",
    val effort: String = "medium",
    @SerialName("web_search") val webSearch: Boolean = true,
    @SerialName("attachment_ids") val attachmentIds: List<String> = emptyList(),
    @SerialName("project_id") val projectId: String? = null,
    @SerialName("conversation_title") val conversationTitle: String? = null,
)

@Serializable
data class CitationDto(
    val index: Int = 0,
    val title: String = "",
    val url: String? = null,
    val snippet: String? = null,
)

@Serializable
data class AttachmentDto(
    val id: String,
    val name: String,
    val mime: String,
    val size: Long = 0,
    val kind: String = "file",
)

@Serializable
data class ToolCallDto(
    val name: String,
    val detail: String = "",
    val ok: Boolean = true,
)

@Serializable
data class MessageDto(
    val id: String,
    @SerialName("conversation_id") val conversationId: String,
    val role: String,
    val content: String,
    @SerialName("created_at") val createdAt: Long,
    val model: String? = null,
    val citations: List<CitationDto> = emptyList(),
    val attachments: List<AttachmentDto> = emptyList(),
    @SerialName("tool_calls") val toolCalls: List<ToolCallDto> = emptyList(),
    val error: Boolean = false,
)

@Serializable
data class ConversationDto(
    val id: String,
    val title: String,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: Long,
    val archived: Boolean = false,
    @SerialName("project_id") val projectId: String? = null,
    val model: String? = null,
    val preview: String = "",
    @SerialName("message_count") val messageCount: Int = 0,
)

@Serializable
data class ConversationListDto(val items: List<ConversationDto> = emptyList(), val next_cursor: String? = null)

@Serializable
data class CreateConversationRequest(val title: String? = null, @SerialName("project_id") val projectId: String? = null)

@Serializable
data class RenameConversationRequest(val title: String)

@Serializable
data class UsageDto(
    @SerialName("prompt_tokens") val promptTokens: Int = 0,
    @SerialName("completion_tokens") val completionTokens: Int = 0,
    @SerialName("estimated_cost_usd") val estimatedCostUsd: Double = 0.0,
)

@Serializable
data class StreamEvent(
    val type: String,
    val text: String? = null,
    @SerialName("message_id") val messageId: String? = null,
    val model: String? = null,
    val citation: CitationDto? = null,
    val tool: ToolCallDto? = null,
    val error: String? = null,
    val usage: UsageDto? = null,
    @SerialName("conversation_id") val conversationId: String? = null,
    val title: String? = null,
)

@Serializable
data class ModelDto(
    val id: String,
    val label: String,
    val provider: String,
    val capabilities: List<String> = emptyList(),
    @SerialName("context_window") val contextWindow: Int? = null,
    @SerialName("cost_note") val costNote: String? = null,
    val available: Boolean = true,
)

@Serializable
data class ModelsResponse(val items: List<ModelDto> = emptyList(), val default: String? = null)

@Serializable
data class ProviderDto(
    val id: String,
    val kind: String,
    val label: String,
    @SerialName("base_url") val baseUrl: String? = null,
    @SerialName("masked_key") val maskedKey: String? = null,
    val status: String = "unconfigured",
    @SerialName("default_model") val defaultModel: String? = null,
    @SerialName("is_default") val isDefault: Boolean = false,
    val error: String? = null,
)

@Serializable
data class ProviderListDto(val items: List<ProviderDto> = emptyList())

@Serializable
data class CreateProviderRequest(
    val kind: String,
    val label: String,
    @SerialName("api_key") val apiKey: String,
    @SerialName("base_url") val baseUrl: String? = null,
    @SerialName("default_model") val defaultModel: String? = null,
)

@Serializable
data class ProviderTestDto(val ok: Boolean, val message: String, val models: List<String> = emptyList())

@Serializable
data class MemoryDto(
    val id: String,
    val scope: String,
    @SerialName("scope_id") val scopeId: String? = null,
    val key: String,
    val value: String,
    @SerialName("updated_at") val updatedAt: Long = 0,
)

@Serializable
data class MemoryListDto(val items: List<MemoryDto> = emptyList())

@Serializable
data class MemoryRequest(
    val scope: String = "user",
    @SerialName("scope_id") val scopeId: String? = null,
    val key: String,
    val value: String,
)

@Serializable
data class FileDto(
    val id: String,
    val name: String,
    val mime: String,
    val size: Long = 0,
    val kind: String = "file",
    @SerialName("text_preview") val textPreview: String = "",
)

@Serializable
data class ProjectDto(
    val id: String,
    val name: String,
    val kind: String,
    @SerialName("created_at") val createdAt: Long = 0,
    @SerialName("last_task") val lastTask: String? = null,
)

@Serializable
data class ProjectListDto(val items: List<ProjectDto> = emptyList())

@Serializable
data class WorkspaceFileDto(
    val path: String,
    val size: Long = 0,
    val directory: Boolean = false,
)

@Serializable
data class WorkspaceFilesDto(val items: List<WorkspaceFileDto> = emptyList())

@Serializable
data class FileContentDto(val path: String, val content: String)

@Serializable
data class WriteFileRequest(val path: String, val content: String)

@Serializable
data class RunCommandRequest(val command: String, val timeout_seconds: Int = 120)

@Serializable
data class CommandResultDto(
    @SerialName("exit_code") val exitCode: Int,
    val stdout: String = "",
    val stderr: String = "",
    @SerialName("duration_ms") val durationMs: Long = 0,
)

@Serializable
data class ApiKeyDto(
    val id: String,
    val label: String,
    val masked: String,
    val scopes: List<String> = emptyList(),
    @SerialName("created_at") val createdAt: Long = 0,
    @SerialName("last_used_at") val lastUsedAt: Long? = null,
    val revoked: Boolean = false,
)

@Serializable
data class ApiKeyListDto(val items: List<ApiKeyDto> = emptyList())

@Serializable
data class CreatedApiKeyDto(
    val id: String,
    val secret: String,
    val label: String,
    val scopes: List<String> = emptyList(),
    @SerialName("created_at") val createdAt: Long = 0,
)

@Serializable
data class CreateApiKeyRequest(val label: String, val scopes: List<String> = listOf("chat.read", "chat.write"))

@Serializable
data class UsageSummaryDto(
    val requests: Int = 0,
    @SerialName("prompt_tokens") val promptTokens: Int = 0,
    @SerialName("completion_tokens") val completionTokens: Int = 0,
    @SerialName("estimated_cost_usd") val estimatedCostUsd: Double = 0.0,
)

@Serializable
data class SessionDto(
    val id: String,
    @SerialName("created_at") val createdAt: Long = 0,
    @SerialName("expires_at") val expiresAt: Long = 0,
    @SerialName("user_agent") val userAgent: String? = null,
    val current: Boolean = false,
)

@Serializable
data class SessionListDto(val items: List<SessionDto> = emptyList())

@Serializable
data class SimpleMessage(val message: String = "")

@Serializable
data class ErrorBody(val detail: String = "", val code: String? = null)
