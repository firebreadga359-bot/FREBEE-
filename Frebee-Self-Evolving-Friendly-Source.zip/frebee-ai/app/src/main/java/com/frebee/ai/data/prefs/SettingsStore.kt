package com.frebee.ai.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.frebee.ai.BuildConfig
import com.frebee.ai.domain.AppSettings
import com.frebee.ai.domain.ChatMode
import com.frebee.ai.domain.MessageDensity
import com.frebee.ai.domain.ThemeMode
import com.frebee.ai.domain.ThinkingEffort
import com.frebee.ai.domain.UiStyle
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "frebee_settings")

class SettingsStore(private val context: Context) {

    val settings: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            themeMode = prefs[THEME_MODE].toThemeMode(),
            style = prefs[STYLE].toUiStyle(),
            accentArgb = prefs[ACCENT] ?: DEFAULT_ACCENT,
            fontScale = prefs[FONT_SCALE] ?: 1f,
            density = prefs[DENSITY].toDensity(),
            reduceMotion = prefs[REDUCE_MOTION] ?: false,
            backendUrl = prefs[BACKEND_URL] ?: BuildConfig.DEFAULT_BACKEND_URL,
            modelId = prefs[MODEL_ID] ?: "",
            mode = ChatMode.fromWire(prefs[MODE]),
            effort = ThinkingEffort.fromWire(prefs[EFFORT]),
            webSearch = prefs[WEB_SEARCH] ?: true,
            speakReplies = prefs[SPEAK_REPLIES] ?: false,
            memoryEnabled = prefs[MEMORY_ENABLED] ?: true,
            guest = prefs[GUEST] ?: false,
            accountEmail = prefs[ACCOUNT_EMAIL] ?: "",
            accountName = prefs[ACCOUNT_NAME] ?: "",
        )
    }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.dataStore.edit { prefs ->
            val current = AppSettings(
                themeMode = prefs[THEME_MODE].toThemeMode(),
                style = prefs[STYLE].toUiStyle(),
                accentArgb = prefs[ACCENT] ?: DEFAULT_ACCENT,
                fontScale = prefs[FONT_SCALE] ?: 1f,
                density = prefs[DENSITY].toDensity(),
                reduceMotion = prefs[REDUCE_MOTION] ?: false,
                backendUrl = prefs[BACKEND_URL] ?: BuildConfig.DEFAULT_BACKEND_URL,
                modelId = prefs[MODEL_ID] ?: "",
                mode = ChatMode.fromWire(prefs[MODE]),
                effort = ThinkingEffort.fromWire(prefs[EFFORT]),
                webSearch = prefs[WEB_SEARCH] ?: true,
                speakReplies = prefs[SPEAK_REPLIES] ?: false,
                memoryEnabled = prefs[MEMORY_ENABLED] ?: true,
                guest = prefs[GUEST] ?: false,
                accountEmail = prefs[ACCOUNT_EMAIL] ?: "",
                accountName = prefs[ACCOUNT_NAME] ?: "",
            )
            val next = transform(current)
            prefs[THEME_MODE] = next.themeMode.name
            prefs[STYLE] = next.style.name
            prefs[ACCENT] = next.accentArgb
            prefs[FONT_SCALE] = next.fontScale
            prefs[DENSITY] = next.density.name
            prefs[REDUCE_MOTION] = next.reduceMotion
            prefs[BACKEND_URL] = next.backendUrl.trim().trimEnd('/')
            prefs[MODEL_ID] = next.modelId
            prefs[MODE] = next.mode.wire
            prefs[EFFORT] = next.effort.wire
            prefs[WEB_SEARCH] = next.webSearch
            prefs[SPEAK_REPLIES] = next.speakReplies
            prefs[MEMORY_ENABLED] = next.memoryEnabled
            prefs[GUEST] = next.guest
            prefs[ACCOUNT_EMAIL] = next.accountEmail
            prefs[ACCOUNT_NAME] = next.accountName
        }
    }

    suspend fun reset() {
        context.dataStore.edit { it.clear() }
    }

    private fun String?.toThemeMode(): ThemeMode =
        ThemeMode.entries.firstOrNull { it.name == this } ?: ThemeMode.System

    private fun String?.toUiStyle(): UiStyle =
        UiStyle.entries.firstOrNull { it.name == this } ?: UiStyle.Classic

    private fun String?.toDensity(): MessageDensity =
        MessageDensity.entries.firstOrNull { it.name == this } ?: MessageDensity.Comfortable

    private companion object {
        const val DEFAULT_ACCENT = 0xFF5B8CFF
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val STYLE = stringPreferencesKey("ui_style")
        val ACCENT = longPreferencesKey("accent_argb")
        val FONT_SCALE = floatPreferencesKey("font_scale")
        val DENSITY = stringPreferencesKey("density")
        val REDUCE_MOTION = booleanPreferencesKey("reduce_motion")
        val BACKEND_URL = stringPreferencesKey("backend_url")
        val MODEL_ID = stringPreferencesKey("model_id")
        val MODE = stringPreferencesKey("mode")
        val EFFORT = stringPreferencesKey("effort")
        val WEB_SEARCH = booleanPreferencesKey("web_search")
        val SPEAK_REPLIES = booleanPreferencesKey("speak_replies")
        val MEMORY_ENABLED = booleanPreferencesKey("memory_enabled")
        val GUEST = booleanPreferencesKey("guest")
        val ACCOUNT_EMAIL = stringPreferencesKey("account_email")
        val ACCOUNT_NAME = stringPreferencesKey("account_name")
    }
}
