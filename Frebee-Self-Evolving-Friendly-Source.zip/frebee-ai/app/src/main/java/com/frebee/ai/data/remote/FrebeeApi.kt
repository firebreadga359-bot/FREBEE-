package com.frebee.ai.data.remote

import android.content.ContentResolver
import android.net.Uri
import com.frebee.ai.BuildConfig
import com.frebee.ai.data.prefs.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.BufferedSink
import java.io.IOException
import java.util.concurrent.TimeUnit

class FrebeeApi(
    private val settings: SettingsStore,
    private val session: SessionStore,
    private val resolver: ContentResolver,
) {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val refreshMutex = Mutex()

    @Volatile
    private var activeCall: Call? = null

    fun cancelStream() {
        activeCall?.cancel()
        activeCall = null
    }

    suspend fun baseUrl(): String {
        val configured = settings.settings.first().backendUrl
        return (if (configured.isBlank()) BuildConfig.DEFAULT_BACKEND_URL else configured).trimEnd('/')
    }

    // ---------------------------------------------------------------- auth

    suspend fun register(email: String, password: String, displayName: String): TokenDto {
        val body = FrebeeJson.encodeToString(RegisterRequest(email.trim(), password, displayName.trim()))
        val token = decode(execute("POST", "/api/v1/auth/register", body, auth = false), TokenDto.serializer())
        session.save(token)
        return token
    }

    suspend fun login(email: String, password: String): TokenDto {
        val body = FrebeeJson.encodeToString(LoginRequest(email.trim(), password))
        val token = decode(execute("POST", "/api/v1/auth/login", body, auth = false), TokenDto.serializer())
        session.save(token)
        return token
    }

    suspend fun guest(): TokenDto {
        val token = decode(execute("POST", "/api/v1/auth/guest", "{}", auth = false), TokenDto.serializer())
        session.save(token)
        return token
    }

    suspend fun me(): UserDto {
        val user = decode(execute("GET", "/api/v1/auth/me"), UserDto.serializer())
        session.setUser(user)
        return user
    }

    suspend fun logout() {
        try {
            if (session.refreshToken != null) {
                execute("POST", "/api/v1/auth/logout", "{}")
            }
        } catch (_: Exception) {
            // Local sign-out must succeed even if the server is unreachable.
        } finally {
            session.clear()
        }
    }

    suspend fun verifyEmail(token: String) {
        execute("POST", "/api/v1/auth/verify-email", FrebeeJson.encodeToString(mapOf("token" to token)))
    }

    suspend fun requestPasswordReset(email: String) {
        execute("POST", "/api/v1/auth/password-reset/request", FrebeeJson.encodeToString(mapOf("email" to email)), auth = false)
    }

    suspend fun confirmPasswordReset(token: String, newPassword: String) {
        execute(
            "POST",
            "/api/v1/auth/password-reset/confirm",
            FrebeeJson.encodeToString(mapOf("token" to token, "new_password" to newPassword)),
            auth = false,
        )
    }

    suspend fun sessions(): List<SessionDto> =
        decode(execute("GET", "/api/v1/auth/sessions"), SessionListDto.serializer()).items

    suspend fun revokeSession(id: String) {
        execute("DELETE", "/api/v1/auth/sessions/$id")
    }

    suspend fun revokeAllSessions() {
        execute("POST", "/api/v1/auth/sessions/revoke-all", "{}")
    }

    suspend fun deleteAccount(password: String) {
        execute("DELETE", "/api/v1/account", FrebeeJson.encodeToString(mapOf("password" to password)))
        session.clear()
    }

    suspend fun exportAccount(): String = execute("GET", "/api/v1/account/export")

    // -------------------------------------------------------- conversations

    suspend fun conversations(query: String = "", archived: Boolean = false): List<ConversationDto> {
        val path = "/api/v1/conversations?query=${encode(query)}&archived=$archived&limit=100"
        return decode(execute("GET", path), ConversationListDto.serializer()).items
    }

    suspend fun createConversation(title: String?, projectId: String? = null): ConversationDto {
        val body = FrebeeJson.encodeToString(CreateConversationRequest(title, projectId))
        return decode(execute("POST", "/api/v1/conversations", body), ConversationDto.serializer())
    }

    suspend fun renameConversation(id: String, title: String): ConversationDto {
        val body = FrebeeJson.encodeToString(RenameConversationRequest(title))
        return decode(execute("PATCH", "/api/v1/conversations/$id", body), ConversationDto.serializer())
    }

    suspend fun setArchived(id: String, archived: Boolean) {
        execute("PATCH", "/api/v1/conversations/$id", FrebeeJson.encodeToString(mapOf("archived" to archived)))
    }

    suspend fun deleteConversation(id: String) {
        execute("DELETE", "/api/v1/conversations/$id")
    }

    suspend fun messages(conversationId: String): List<MessageDto> =
        decode(execute("GET", "/api/v1/conversations/$conversationId/messages"), MessageListDto.serializer()).items

    suspend fun deleteMessage(conversationId: String, messageId: String) {
        execute("DELETE", "/api/v1/conversations/$conversationId/messages/$messageId")
    }

    suspend fun models(): ModelsResponse = decode(execute("GET", "/api/v1/models"), ModelsResponse.serializer())

    // --------------------------------------------------------------- stream

    fun streamMessage(conversationId: String, request: MessageRequest): Flow<StreamEvent> = flow {
        val url = baseUrl() + "/api/v1/conversations/$conversationId/messages"
        val body = FrebeeJson.encodeToString(request).toRequestBody(JSON)
        val call = client.newCall(
            Request.Builder()
                .url(url)
                .header("Accept", "text/event-stream")
                .apply { session.accessToken?.let { header("Authorization", "Bearer $it") } }
                .post(body)
                .build(),
        )
        activeCall = call
        try {
            call.execute().use { response ->
                if (!response.isSuccessful) {
                    val text = response.body?.string().orEmpty()
                    throw ApiException(response.code, errorMessage(response.code, text), text)
                }
                val source = response.body?.source() ?: throw ApiException(500, "Empty response body")
                while (!source.exhausted()) {
                    val line = source.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue
                    val payload = line.removePrefix("data:").trim()
                    if (payload.isEmpty()) continue
                    val event = runCatching { FrebeeJson.decodeFromString(StreamEvent.serializer(), payload) }.getOrNull()
                        ?: continue
                    emit(event)
                    if (event.type == "done" || event.type == "error") break
                }
            }
        } catch (io: IOException) {
            if (io.message?.contains("Canceled", ignoreCase = true) == true) {
                emit(StreamEvent(type = "cancelled"))
            } else {
                throw ApiException(0, io.message ?: "Network error", null)
            }
        } finally {
            activeCall = null
        }
    }.flowOn(Dispatchers.IO)

    // ------------------------------------------------------------ providers

    suspend fun providers(): List<ProviderDto> =
        decode(execute("GET", "/api/v1/providers"), ProviderListDto.serializer()).items

    suspend fun addProvider(request: CreateProviderRequest): ProviderDto =
        decode(execute("POST", "/api/v1/providers", FrebeeJson.encodeToString(request)), ProviderDto.serializer())

    suspend fun testProvider(id: String): ProviderTestDto =
        decode(execute("POST", "/api/v1/providers/$id/test", "{}"), ProviderTestDto.serializer())

    suspend fun deleteProvider(id: String) {
        execute("DELETE", "/api/v1/providers/$id")
    }

    suspend fun setDefaultProvider(id: String) {
        execute("PATCH", "/api/v1/providers/$id", FrebeeJson.encodeToString(mapOf("is_default" to true)))
    }

    // --------------------------------------------------------------- memory

    suspend fun memories(scope: String? = null): List<MemoryDto> {
        val path = if (scope == null) "/api/v1/memory" else "/api/v1/memory?scope=$scope"
        return decode(execute("GET", path), MemoryListDto.serializer()).items
    }

    suspend fun addMemory(request: MemoryRequest): MemoryDto =
        decode(execute("POST", "/api/v1/memory", FrebeeJson.encodeToString(request)), MemoryDto.serializer())

    suspend fun updateMemory(id: String, key: String, value: String): MemoryDto =
        decode(
            execute("PATCH", "/api/v1/memory/$id", FrebeeJson.encodeToString(mapOf("key" to key, "value" to value))),
            MemoryDto.serializer(),
        )

    suspend fun deleteMemory(id: String) {
        execute("DELETE", "/api/v1/memory/$id")
    }

    suspend fun deleteAllMemory() {
        execute("DELETE", "/api/v1/memory")
    }

    // ---------------------------------------------------------------- files

    suspend fun uploadFile(uri: Uri, name: String, mime: String): FileDto = withContext(Dispatchers.IO) {
        val stream = resolver.openInputStream(uri) ?: throw ApiException(400, "Cannot read the selected file")
        val length = runCatching { resolver.openAssetFileDescriptor(uri, "r")?.length ?: -1L }.getOrDefault(-1L)
        val part = StreamRequestBody(stream, mime.toMediaType(), if (length > 0) length else null)
        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", name, part)
            .build()
        val url = baseUrl() + "/api/v1/files"
        val request = Request.Builder()
            .url(url)
            .apply { session.accessToken?.let { header("Authorization", "Bearer $it") } }
            .post(multipart)
            .build()
        val text = client.newCall(request).execute().use { response ->
            val payload = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw ApiException(response.code, errorMessage(response.code, payload), payload)
            payload
        }
        decode(text, FileDto.serializer())
    }

    // ------------------------------------------------------------- projects

    suspend fun projects(): List<ProjectDto> =
        decode(execute("GET", "/api/v1/projects"), ProjectListDto.serializer()).items

    suspend fun createProject(name: String, kind: String): ProjectDto =
        decode(
            execute("POST", "/api/v1/projects", FrebeeJson.encodeToString(mapOf("name" to name, "kind" to kind))),
            ProjectDto.serializer(),
        )

    suspend fun deleteProject(id: String) {
        execute("DELETE", "/api/v1/projects/$id")
    }

    // ------------------------------------------------------------ workspace

    suspend fun workspaceFiles(projectId: String): List<WorkspaceFileDto> =
        decode(execute("GET", "/api/v1/agent/projects/$projectId/files"), WorkspaceFilesDto.serializer()).items

    suspend fun readWorkspaceFile(projectId: String, path: String): FileContentDto =
        decode(execute("GET", "/api/v1/agent/projects/$projectId/file?path=${encode(path)}"), FileContentDto.serializer())

    suspend fun writeWorkspaceFile(projectId: String, path: String, content: String): FileContentDto =
        decode(
            execute(
                "PUT",
                "/api/v1/agent/projects/$projectId/file",
                FrebeeJson.encodeToString(WriteFileRequest(path, content)),
            ),
            FileContentDto.serializer(),
        )

    suspend fun runCommand(projectId: String, command: String, timeoutSeconds: Int = 120): CommandResultDto =
        decode(
            execute(
                "POST",
                "/api/v1/agent/projects/$projectId/run",
                FrebeeJson.encodeToString(RunCommandRequest(command, timeoutSeconds)),
            ),
            CommandResultDto.serializer(),
        )

    suspend fun downloadProjectArchive(projectId: String): ByteArray = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(baseUrl() + "/api/v1/agent/projects/$projectId/archive")
            .apply { session.accessToken?.let { header("Authorization", "Bearer $it") } }
            .get()
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val payload = response.body?.string().orEmpty()
                throw ApiException(response.code, errorMessage(response.code, payload), payload)
            }
            response.body?.bytes() ?: throw ApiException(500, "Empty archive")
        }
    }

    fun runAgentTask(projectId: String, prompt: String, mode: String): Flow<StreamEvent> = flow {
        val url = baseUrl() + "/api/v1/agent/projects/$projectId/task"
        val body = FrebeeJson.encodeToString(mapOf("prompt" to prompt, "mode" to mode)).toRequestBody(JSON)
        val call = client.newCall(
            Request.Builder()
                .url(url)
                .header("Accept", "text/event-stream")
                .apply { session.accessToken?.let { header("Authorization", "Bearer $it") } }
                .post(body)
                .build(),
        )
        activeCall = call
        try {
            call.execute().use { response ->
                if (!response.isSuccessful) {
                    val text = response.body?.string().orEmpty()
                    throw ApiException(response.code, errorMessage(response.code, text), text)
                }
                val source = response.body?.source() ?: throw ApiException(500, "Empty response body")
                while (!source.exhausted()) {
                    val line = source.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue
                    val payload = line.removePrefix("data:").trim()
                    if (payload.isEmpty()) continue
                    val event = runCatching { FrebeeJson.decodeFromString(StreamEvent.serializer(), payload) }.getOrNull()
                        ?: continue
                    emit(event)
                    if (event.type == "done" || event.type == "error") break
                }
            }
        } finally {
            activeCall = null
        }
    }.flowOn(Dispatchers.IO)

    // ------------------------------------------------------------ developer

    suspend fun apiKeys(): List<ApiKeyDto> =
        decode(execute("GET", "/api/v1/developer/keys"), ApiKeyListDto.serializer()).items

    suspend fun createApiKey(label: String, scopes: List<String>): CreatedApiKeyDto =
        decode(
            execute("POST", "/api/v1/developer/keys", FrebeeJson.encodeToString(CreateApiKeyRequest(label, scopes))),
            CreatedApiKeyDto.serializer(),
        )

    suspend fun revokeApiKey(id: String) {
        execute("DELETE", "/api/v1/developer/keys/$id")
    }

    suspend fun usage(): UsageSummaryDto = decode(execute("GET", "/api/v1/developer/usage"), UsageSummaryDto.serializer())

    // ---------------------------------------------------------------- http

    private suspend fun execute(
        method: String,
        path: String,
        body: String? = null,
        auth: Boolean = true,
        retried: Boolean = false,
    ): String {
        val url = baseUrl() + path
        val builder = Request.Builder().url(url)
        if (body != null) builder.method(method, body.toRequestBody(JSON)) else builder.method(method, null)
        if (auth) {
            val token = session.accessToken
            if (token.isNullOrBlank() && !path.endsWith("/auth/refresh")) {
                throw ApiException(401, "You are signed out. Please sign in again.")
            }
            token?.let { builder.header("Authorization", "Bearer $it") }
        }
        val text: String
        val code: Int
        try {
            client.newCall(builder.build()).execute().use { response ->
                code = response.code
                text = response.body?.string().orEmpty()
            }
        } catch (io: IOException) {
            throw ApiException(0, "Cannot reach the Frebee backend at $url. Check the server URL in Settings.", null)
        }
        if (code == 401 && auth && !retried && session.refreshToken != null) {
            if (refresh()) return execute(method, path, body, auth, retried = true)
        }
        if (code !in 200..299) throw ApiException(code, errorMessage(code, text), text)
        return text
    }

    private suspend fun refresh(): Boolean = refreshMutex.withLock {
        val refreshToken = session.refreshToken ?: return false
        val body = FrebeeJson.encodeToString(mapOf("refresh_token" to refreshToken))
        val request = Request.Builder()
            .url(baseUrl() + "/api/v1/auth/refresh")
            .post(body.toRequestBody(JSON))
            .build()
        val result = runCatching {
            client.newCall(request).execute().use { response ->
                val payload = response.body?.string().orEmpty()
                if (!response.isSuccessful) null else decode(payload, TokenDto.serializer())
            }
        }.getOrNull()
        if (result == null) {
            session.clear()
            false
        } else {
            session.save(result)
            true
        }
    }

    private fun errorMessage(code: Int, payload: String): String {
        val detail = runCatching {
            FrebeeJson.decodeFromString(ErrorBody.serializer(), payload).detail
        }.getOrNull()
        if (!detail.isNullOrBlank()) return detail
        return when (code) {
            401 -> "Authentication failed"
            403 -> "You do not have permission for this action"
            404 -> "Not found"
            413 -> "File too large"
            429 -> "Rate limit reached. Try again shortly."
            in 500..599 -> "The Frebee backend reported an error ($code)"
            else -> "Request failed ($code)"
        }
    }

    private fun encode(value: String): String =
        java.net.URLEncoder.encode(value, "UTF-8")

    private fun <T> decode(text: String, serializer: kotlinx.serialization.DeserializationStrategy<T>): T =
        FrebeeJson.decodeFromString(serializer, text)

    private class StreamRequestBody(
        private val stream: java.io.InputStream,
        private val mediaType: okhttp3.MediaType,
        private val length: Long?,
    ) : RequestBody() {
        override fun contentType() = mediaType
        override fun contentLength(): Long = length ?: -1L
        override fun writeTo(sink: BufferedSink) {
            stream.use { input ->
                val buffer = ByteArray(8 * 1024)
                while (true) {
                    val read = input.read(buffer)
                    if (read <= 0) break
                    sink.write(buffer, 0, read)
                }
            }
        }
    }

    private companion object {
        val JSON = "application/json; charset=utf-8".toMediaType()
    }
}

@kotlinx.serialization.Serializable
data class MessageListDto(val items: List<MessageDto> = emptyList())
