package com.frebee.ai.ui.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.frebee.ai.ui.AppViewModel
import com.frebee.ai.ui.common.BrandMark
import com.frebee.ai.ui.common.InlineBanner
import com.frebee.ai.ui.theme.LocalFrebeePalette

@Composable
fun AuthScreen(app: AppViewModel) {
    val palette = LocalFrebeePalette.current
    val settings by app.settings.collectAsStateWithLifecycle()
    val banner by app.banner.collectAsStateWithLifecycle()
    val busy by app.busy.collectAsStateWithLifecycle()

    var mode by remember { mutableStateOf(AuthMode.Login) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var serverUrl by remember(settings.backendUrl) { mutableStateOf(settings.backendUrl) }
    var showServer by remember { mutableStateOf(false) }
    var showReset by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(palette.background).imePadding()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(24.dp))
            BrandMark(size = 64.dp)
            Spacer(Modifier.height(12.dp))
            Text("Frebee", style = MaterialTheme.typography.headlineSmall, color = palette.onSurface)
            Text(
                "Research, reason, build.",
                style = MaterialTheme.typography.bodyMedium,
                color = palette.onSurfaceMuted,
            )
            Spacer(Modifier.height(28.dp))

            Surface(
                modifier = Modifier.widthIn(max = 460.dp).fillMaxWidth(),
                color = palette.surface,
                shape = RoundedCornerShape(20.dp),
            ) {
                Column(Modifier.padding(18.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ModeTab("Log in", mode == AuthMode.Login, Modifier.weight(1f)) { mode = AuthMode.Login }
                        ModeTab("Create account", mode == AuthMode.Register, Modifier.weight(1f)) { mode = AuthMode.Register }
                    }
                    Spacer(Modifier.height(16.dp))

                    if (mode == AuthMode.Register) {
                        OutlinedTextField(
                            value = displayName,
                            onValueChange = { displayName = it },
                            label = { Text("Display name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Spacer(Modifier.height(10.dp))
                    }

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (mode == AuthMode.Login) app.signIn(email, password)
                            else app.register(email, password, displayName.ifBlank { email.substringBefore('@') })
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                    ) {
                        if (busy) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.size(8.dp))
                        }
                        Text(if (mode == AuthMode.Login) "Log in" else "Create account")
                    }

                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { showReset = true }, modifier = Modifier.align(Alignment.Start)) {
                        Text("Forgot password?", style = MaterialTheme.typography.bodySmall)
                    }

                    Spacer(Modifier.height(4.dp))
                    OutlinedButton(
                        onClick = { app.continueAsGuest() },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                    ) {
                        Text("Continue as guest")
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Guest mode works on this device session only. Chats are not linked to a verified account, cannot be recovered, and advanced tools stay limited.",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.onSurfaceMuted,
                    )
                }
            }

            Spacer(Modifier.height(18.dp))

            TextButton(onClick = { showServer = !showServer }) {
                Text(
                    if (showServer) "Hide server settings" else "Server: ${settings.backendUrl}",
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.onSurfaceMuted,
                )
            }
            if (showServer) {
                Surface(
                    modifier = Modifier.widthIn(max = 460.dp).fillMaxWidth(),
                    color = palette.surface,
                    shape = RoundedCornerShape(16.dp),
                ) {
                    Column(Modifier.padding(14.dp)) {
                        OutlinedTextField(
                            value = serverUrl,
                            onValueChange = { serverUrl = it },
                            label = { Text("Backend URL") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = { app.updateSettings { it.copy(backendUrl = serverUrl.trim()) } },
                            shape = RoundedCornerShape(10.dp),
                        ) { Text("Save server URL") }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Emulator default is http://10.0.2.2:8000. Production deployments must use https://.",
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.onSurfaceMuted,
                        )
                    }
                }
            }

            banner?.let {
                Spacer(Modifier.height(12.dp))
                InlineBanner(text = it.text, isError = it.isError, onDismiss = { app.dismissBanner() })
            }
        }
    }

    if (showReset) {
        PasswordResetDialog(
            onDismiss = { showReset = false },
            onRequest = { app.requestPasswordReset(it) },
            onConfirm = { token, newPassword -> app.confirmPasswordReset(token, newPassword) },
        )
    }
}

private enum class AuthMode { Login, Register }

@Composable
private fun ModeTab(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val palette = LocalFrebeePalette.current
    Surface(
        color = if (selected) palette.accent.copy(alpha = 0.16f) else palette.surfaceVariant,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.clickable { onClick() },
    ) {
        Box(Modifier.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
            Text(
                label,
                style = MaterialTheme.typography.bodyMedium,
                color = if (selected) palette.accent else palette.onSurfaceMuted,
            )
        }
    }
}

@Composable
private fun PasswordResetDialog(
    onDismiss: () -> Unit,
    onRequest: (String) -> Unit,
    onConfirm: (String, String) -> Unit,
) {
    var step by remember { mutableStateOf(0) }
    var email by remember { mutableStateOf("") }
    var token by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (step == 0) "Reset password" else "Enter reset token") },
        text = {
            Column {
                if (step == 0) {
                    Text(
                        "We send a single-use reset token to your email. In a local deployment the backend prints it to its log when SMTP is not configured.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email") },
                        singleLine = true,
                    )
                } else {
                    OutlinedTextField(
                        value = token,
                        onValueChange = { token = it },
                        label = { Text("Reset token") },
                        singleLine = true,
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = newPassword,
                        onValueChange = { newPassword = it },
                        label = { Text("New password") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (step == 0) {
                    onRequest(email.trim())
                    step = 1
                } else {
                    onConfirm(token.trim(), newPassword)
                    onDismiss()
                }
            }) { Text(if (step == 0) "Send token" else "Set password") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
