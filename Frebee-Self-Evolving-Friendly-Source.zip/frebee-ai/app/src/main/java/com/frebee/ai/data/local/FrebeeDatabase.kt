package com.frebee.ai.data.local

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
    val archived: Boolean = false,
    val projectId: String? = null,
    val model: String? = null,
    val remote: Boolean = false,
)

@Entity(
    tableName = "messages",
    indices = [Index("conversationId"), Index("createdAt")],
)
data class MessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val role: String,
    val content: String,
    val createdAt: Long,
    val model: String? = null,
    val citationsJson: String? = null,
    val attachmentsJson: String? = null,
    val toolTraceJson: String? = null,
    val streaming: Boolean = false,
    val failed: Boolean = false,
)

@Entity(tableName = "memories", indices = [Index("scope"), Index(value = ["scope", "scopeId"])])
data class MemoryEntity(
    @PrimaryKey val id: String,
    val scope: String,
    val scopeId: String? = null,
    val key: String,
    val value: String,
    val updatedAt: Long,
    val dirty: Boolean = true,
)

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val kind: String,
    val createdAt: Long,
    val lastTask: String? = null,
    val remote: Boolean = false,
)

data class ConversationListRow(
    val id: String,
    val title: String,
    val updatedAt: Long,
    val archived: Boolean,
    val projectId: String?,
    @ColumnInfo(name = "preview") val preview: String,
    @ColumnInfo(name = "messageCount") val messageCount: Int,
)

@Dao
interface FrebeeDao {

    @Query(
        """
        SELECT c.id AS id, c.title AS title, c.updatedAt AS updatedAt, c.archived AS archived,
               c.projectId AS projectId,
               COALESCE((SELECT m.content FROM messages m WHERE m.conversationId = c.id
                         ORDER BY m.createdAt DESC LIMIT 1), '') AS preview,
               (SELECT COUNT(*) FROM messages m2 WHERE m2.conversationId = c.id) AS messageCount
        FROM conversations c
        WHERE (:includeArchived = 1 OR c.archived = 0)
          AND (:query = '' OR c.title LIKE '%' || :query || '%'
               OR EXISTS (SELECT 1 FROM messages m3 WHERE m3.conversationId = c.id
                          AND m3.content LIKE '%' || :query || '%'))
        ORDER BY c.updatedAt DESC
        """,
    )
    fun observeConversations(query: String, includeArchived: Int): Flow<List<ConversationListRow>>

    @Query("SELECT * FROM conversations WHERE id = :id")
    fun observeConversation(id: String): Flow<ConversationEntity?>

    @Query("SELECT * FROM conversations WHERE id = :id")
    suspend fun conversation(id: String): ConversationEntity?

    @Query("SELECT * FROM conversations ORDER BY updatedAt DESC")
    suspend fun allConversations(): List<ConversationEntity>

    @Upsert
    suspend fun upsertConversation(conversation: ConversationEntity)

    @Query("UPDATE conversations SET title = :title, updatedAt = :now WHERE id = :id")
    suspend fun renameConversation(id: String, title: String, now: Long)

    @Query("UPDATE conversations SET archived = :archived, updatedAt = :now WHERE id = :id")
    suspend fun archiveConversation(id: String, archived: Boolean, now: Long)

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun deleteConversation(id: String)

    @Query("DELETE FROM messages WHERE conversationId = :id")
    suspend fun deleteMessages(id: String)

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY createdAt ASC")
    fun observeMessages(conversationId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY createdAt ASC")
    suspend fun messages(conversationId: String): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE id = :id")
    suspend fun message(id: String): MessageEntity?

    @Upsert
    suspend fun upsertMessage(message: MessageEntity)

    @Query("DELETE FROM messages WHERE id = :id")
    suspend fun deleteMessage(id: String)

    @Query("SELECT * FROM memories ORDER BY updatedAt DESC")
    fun observeMemories(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE scope = :scope AND (scopeId IS NULL OR scopeId = :scopeId)")
    suspend fun memories(scope: String, scopeId: String?): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE key LIKE '%' || :query || '%' OR value LIKE '%' || :query || '%'")
    suspend fun searchMemories(query: String): List<MemoryEntity>

    @Upsert
    suspend fun upsertMemory(memory: MemoryEntity)

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun deleteMemory(id: String)

    @Query("SELECT * FROM projects ORDER BY createdAt DESC")
    fun observeProjects(): Flow<List<ProjectEntity>>

    @Upsert
    suspend fun upsertProject(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProject(id: String)

    @Query("DELETE FROM conversations")
    suspend fun deleteAllConversations()

    @Query("DELETE FROM messages")
    suspend fun deleteAllMessages()

    @Query("DELETE FROM memories")
    suspend fun deleteAllMemories()

    @Query("DELETE FROM projects")
    suspend fun deleteAllProjects()
}

@Database(
    entities = [
        ConversationEntity::class,
        MessageEntity::class,
        MemoryEntity::class,
        ProjectEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class FrebeeDatabase : RoomDatabase() {
    abstract fun dao(): FrebeeDao

    companion object {
        const val NAME = "frebee.db"
    }
}
