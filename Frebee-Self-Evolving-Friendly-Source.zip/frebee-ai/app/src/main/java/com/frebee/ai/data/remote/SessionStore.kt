package com.frebee.ai.data.remote

import com.frebee.ai.core.SecureStore
import kotlinx.serialization.json.Json

val FrebeeJson: Json = Json {
    ignoreUnknownKeys = true
    explicitNulls = false
    encodeDefaults = true
    isLenient = true
}

class ApiException(val status: Int, message: String, val body: String? = null) : Exception(message) {
    val isUnauthorized: Boolean get() = status == 401
    val isNetwork: Boolean get() = status == 0
}

/**
 * Holds the session tokens. The access token is short lived and kept in memory plus
 * encrypted storage so a cold start can resume without a login round trip.
 */
class SessionStore(private val secure: SecureStore) {

    @Volatile
    var accessToken: String? = secure.get(KEY_ACCESS)
        private set

    @Volatile
    var refreshToken: String? = secure.get(KEY_REFRESH)
        private set

    @Volatile
    var user: UserDto? = null
        private set

    val isSignedIn: Boolean get() = !accessToken.isNullOrBlank()

    fun save(token: TokenDto) {
        accessToken = token.accessToken
        secure.put(KEY_ACCESS, token.accessToken)
        if (token.refreshToken.isNotBlank()) {
            refreshToken = token.refreshToken
            secure.put(KEY_REFRESH, token.refreshToken)
        }
        token.user?.let { user = it }
    }

    fun setUser(value: UserDto?) {
        user = value
    }

    fun clear() {
        accessToken = null
        refreshToken = null
        user = null
        secure.remove(KEY_ACCESS)
        secure.remove(KEY_REFRESH)
    }

    private companion object {
        const val KEY_ACCESS = "access_token"
        const val KEY_REFRESH = "refresh_token"
    }
}
