package com.frebee.ai.domain

enum class ThemeMode { System, Light, Dark }

enum class UiStyle { Classic, Futuristic }

enum class MessageDensity { Comfortable, Compact }

/** Orchestration modes. Each maps to a server-side strategy, not just a prompt tweak. */
enum class ChatMode(val label: String, val wire: String, val hint: String) {
    Quick("Quick", "quick", "Lowest latency, single pass"),
    Balanced("Balanced", "balanced", "Quality, speed and cost in balance"),
    Deep("Deep", "deep", "More analysis, verification and tool use"),
    Research("Research", "research", "Gather sources, compare and cite"),
    Coding("Coding agent", "coding", "Inspect project, edit files, run tests"),
    Autonomous("Autonomous project", "autonomous", "Multi-step project work with approvals"),
    ;

    companion object {
        fun fromWire(value: String?): ChatMode = entries.firstOrNull { it.wire == value } ?: Balanced
    }
}

enum class ThinkingEffort(val label: String, val wire: String) {
    Off("Off", "off"),
    Low("Low", "low"),
    Medium("Medium", "medium"),
    High("High", "high"),
    ;

    companion object {
        fun fromWire(value: String?): ThinkingEffort = entries.firstOrNull { it.wire == value } ?: Medium
    }
}

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.System,
    val style: UiStyle = UiStyle.Classic,
    val accentArgb: Long = 0xFF5B8CFF,
    val fontScale: Float = 1f,
    val density: MessageDensity = MessageDensity.Comfortable,
    val reduceMotion: Boolean = false,
    val backendUrl: String = "",
    val modelId: String = "",
    val mode: ChatMode = ChatMode.Balanced,
    val effort: ThinkingEffort = ThinkingEffort.Medium,
    val webSearch: Boolean = true,
    val speakReplies: Boolean = false,
    val memoryEnabled: Boolean = true,
    val guest: Boolean = false,
    val accountEmail: String = "",
    val accountName: String = "",
)

data class Citation(
    val index: Int,
    val title: String,
    val url: String? = null,
    val snippet: String? = null,
)

data class Attachment(
    val id: String,
    val name: String,
    val mime: String,
    val sizeBytes: Long,
    val localUri: String? = null,
    val remoteId: String? = null,
    val uploadState: UploadState = UploadState.Pending,
) {
    val isImage: Boolean get() = mime.startsWith("image/")
}

enum class UploadState { Pending, Uploading, Uploaded, Failed }

data class ToolTraceEntry(
    val name: String,
    val detail: String,
    val ok: Boolean = true,
)

data class UiMessage(
    val id: String,
    val conversationId: String,
    val role: String,
    val content: String,
    val createdAt: Long,
    val model: String? = null,
    val citations: List<Citation> = emptyList(),
    val attachments: List<Attachment> = emptyList(),
    val toolTrace: List<ToolTraceEntry> = emptyList(),
    val streaming: Boolean = false,
    val error: Boolean = false,
) {
    val isUser: Boolean get() = role == "user"
}

data class ConversationSummary(
    val id: String,
    val title: String,
    val updatedAt: Long,
    val archived: Boolean = false,
    val projectId: String? = null,
    val preview: String = "",
    val messageCount: Int = 0,
)

data class MemoryItem(
    val id: String,
    val scope: String,
    val scopeId: String? = null,
    val key: String,
    val value: String,
    val updatedAt: Long = 0,
    val dirty: Boolean = true,
)

data class ProviderInfo(
    val id: String,
    val kind: String,
    val label: String,
    val baseUrl: String? = null,
    val maskedKey: String? = null,
    val status: String = "unconfigured",
    val defaultModel: String? = null,
    val isDefault: Boolean = false,
    val error: String? = null,
)

data class ModelInfo(
    val id: String,
    val label: String,
    val provider: String,
    val capabilities: List<String> = emptyList(),
    val contextWindow: Int? = null,
    val costNote: String? = null,
) {
    fun supports(capability: String): Boolean = capabilities.contains(capability)
}

data class ProjectInfo(
    val id: String,
    val name: String,
    val kind: String,
    val createdAt: Long = 0,
    val lastTask: String? = null,
)

data class WorkspaceFile(
    val path: String,
    val sizeBytes: Long,
    val directory: Boolean,
)

data class CommandResult(
    val exitCode: Int,
    val stdout: String,
    val stderr: String,
    val durationMs: Long,
)

data class ApiKeyInfo(
    val id: String,
    val label: String,
    val masked: String,
    val scopes: List<String>,
    val createdAt: Long,
    val lastUsedAt: Long? = null,
    val revoked: Boolean = false,
)

data class UsageSummary(
    val requests: Int = 0,
    val promptTokens: Int = 0,
    val completionTokens: Int = 0,
    val estimatedCostUsd: Double = 0.0,
)
