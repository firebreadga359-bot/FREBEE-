package com.frebee.ai.data.repo

import com.frebee.ai.data.local.ConversationEntity
import com.frebee.ai.data.local.FrebeeDao
import com.frebee.ai.data.local.MemoryEntity
import com.frebee.ai.data.local.MessageEntity
import com.frebee.ai.data.local.ProjectEntity
import com.frebee.ai.data.remote.ApiException
import com.frebee.ai.data.remote.AttachmentDto
import com.frebee.ai.data.remote.CitationDto
import com.frebee.ai.data.remote.ConversationDto
import com.frebee.ai.data.remote.FrebeeApi
import com.frebee.ai.data.remote.FrebeeJson
import com.frebee.ai.data.remote.MemoryDto
import com.frebee.ai.data.remote.MessageDto
import com.frebee.ai.data.remote.MessageRequest
import com.frebee.ai.data.remote.StreamEvent
import com.frebee.ai.data.remote.ToolCallDto
import com.frebee.ai.domain.AppSettings
import com.frebee.ai.domain.Attachment
import com.frebee.ai.domain.ChatMode
import com.frebee.ai.domain.Citation
import com.frebee.ai.domain.ConversationSummary
import com.frebee.ai.domain.MemoryItem
import com.frebee.ai.domain.ProjectInfo
import com.frebee.ai.domain.ToolTraceEntry
import com.frebee.ai.domain.UiMessage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.builtins.ListSerializer
import java.util.UUID

private val citationListSerializer = ListSerializer(CitationDto.serializer())
private val attachmentListSerializer = ListSerializer(AttachmentDto.serializer())
private val toolListSerializer = ListSerializer(ToolCallDto.serializer())

class ChatRepository(
    private val dao: FrebeeDao,
    private val api: FrebeeApi,
) {

    val conversations: Flow<List<ConversationSummary>> =
        dao.observeConversations("", 1).map { rows ->
            rows.map { row ->
                ConversationSummary(
                    id = row.id,
                    title = row.title,
                    updatedAt = row.updatedAt,
                    archived = row.archived,
                    projectId = row.projectId,
                    preview = row.preview,
                    messageCount = row.messageCount,
                )
            }
        }

    fun searchConversations(query: String): Flow<List<ConversationSummary>> =
        dao.observeConversations(query, 1).map { rows ->
            rows.map {
                ConversationSummary(it.id, it.title, it.updatedAt, it.archived, it.projectId, it.preview, it.messageCount)
            }
        }

    fun messages(conversationId: String): Flow<List<UiMessage>> =
        dao.observeMessages(conversationId).map { list -> list.map(::toUiMessage) }

    suspend fun syncConversations() {
        val remote = api.conversations()
        remote.forEach { dto ->
            dao.upsertConversation(dto.toEntity())
        }
    }

    suspend fun syncMessages(conversationId: String) {
        val remote = api.messages(conversationId)
        remote.forEach { dao.upsertMessage(it.toEntity()) }
    }

    suspend fun createConversation(projectId: String? = null): String {
        val dto = api.createConversation(null, projectId)
        dao.upsertConversation(dto.toEntity())
        return dto.id
    }

    suspend fun rename(conversationId: String, title: String) {
        val updated = api.renameConversation(conversationId, title)
        dao.upsertConversation(updated.toEntity())
    }

    suspend fun setArchived(conversationId: String, archived: Boolean) {
        api.setArchived(conversationId, archived)
        dao.archiveConversation(conversationId, archived, System.currentTimeMillis())
    }

    suspend fun delete(conversationId: String) {
        api.deleteConversation(conversationId)
        dao.deleteMessages(conversationId)
        dao.deleteConversation(conversationId)
    }

    suspend fun deleteAllLocal() {
        dao.deleteAllMessages()
        dao.deleteAllConversations()
    }

    suspend fun conversationTitle(id: String): String = dao.conversation(id)?.title ?: "Chat"

    /**
     * Persists the user turn, then streams the assistant turn into the local database so
     * the UI renders progressive text even if the process is backgrounded mid-stream.
     */
    fun sendMessage(
        conversationId: String,
        text: String,
        attachments: List<Attachment>,
        settings: AppSettings,
        appendUserMessage: Boolean = true,
    ): Flow<StreamEvent> = flow {
        val now = System.currentTimeMillis()
        val userMessageId = UUID.randomUUID().toString()
        val assistantMessageId = UUID.randomUUID().toString()

        val existing = dao.conversation(conversationId)
        val title = existing?.title?.takeIf { it.isNotBlank() && it != "New chat" }
            ?: text.trim().lineSequence().firstOrNull()?.take(64)?.ifBlank { "New chat" } ?: "New chat"
        dao.upsertConversation(
            (existing ?: ConversationEntity(conversationId, title, now, now)).copy(
                title = title,
                updatedAt = now,
            ),
        )
        if (appendUserMessage) {
            dao.upsertMessage(
                MessageEntity(
                    id = userMessageId,
                    conversationId = conversationId,
                    role = "user",
                    content = text,
                    createdAt = now,
                    attachmentsJson = FrebeeJson.encodeToString(
                        attachmentListSerializer,
                        attachments.map { AttachmentDto(it.remoteId ?: it.id, it.name, it.mime, it.sizeBytes, if (it.isImage) "image" else "file") },
                    ),
                ),
            )
        }
        dao.upsertMessage(
            MessageEntity(
                id = assistantMessageId,
                conversationId = conversationId,
                role = "assistant",
                content = "",
                createdAt = now + 1,
                streaming = true,
                model = settings.modelId.ifBlank { null },
            ),
        )
        emit(StreamEvent(type = "started", messageId = assistantMessageId, conversationId = conversationId))

        val request = MessageRequest(
            content = text,
            model = settings.modelId.ifBlank { null },
            mode = settings.mode.wire,
            effort = settings.effort.wire,
            webSearch = settings.webSearch,
            attachmentIds = attachments.mapNotNull { it.remoteId },
            projectId = existing?.projectId,
        )

        val buffer = StringBuilder()
        val citations = mutableListOf<CitationDto>()
        val tools = mutableListOf<ToolCallDto>()
        var model: String? = settings.modelId.ifBlank { null }
        var lastPersist = 0L
        var finished = false

        suspend fun persist(streaming: Boolean, failed: Boolean = false) {
            dao.upsertMessage(
                MessageEntity(
                    id = assistantMessageId,
                    conversationId = conversationId,
                    role = "assistant",
                    content = buffer.toString(),
                    createdAt = now + 1,
                    model = model,
                    citationsJson = if (citations.isEmpty()) null else FrebeeJson.encodeToString(citationListSerializer, citations),
                    toolTraceJson = if (tools.isEmpty()) null else FrebeeJson.encodeToString(toolListSerializer, tools),
                    streaming = streaming,
                    failed = failed,
                ),
            )
        }

        try {
            api.streamMessage(conversationId, request).collect { event ->
                when (event.type) {
                    "meta" -> {
                        model = event.model ?: model
                        emit(event)
                    }
                    "delta" -> {
                        buffer.append(event.text.orEmpty())
                        val clock = System.currentTimeMillis()
                        if (clock - lastPersist > 120) {
                            lastPersist = clock
                            persist(streaming = true)
                        }
                        emit(event)
                    }
                    "citation" -> {
                        event.citation?.let { citations += it }
                        emit(event)
                    }
                    "tool" -> {
                        event.tool?.let { tools += it }
                        emit(event)
                    }
                    "title" -> {
                        event.title?.let { newTitle ->
                            dao.renameConversation(conversationId, newTitle, System.currentTimeMillis())
                        }
                        emit(event)
                    }
                    "done" -> {
                        finished = true
                        persist(streaming = false)
                        emit(event)
                    }
                    "error" -> {
                        finished = true
                        val message = event.error ?: "The model returned an error"
                        if (buffer.isEmpty()) buffer.append(message)
                        persist(streaming = false, failed = true)
                        emit(event)
                    }
                    else -> emit(event)
                }
            }
            if (!finished) persist(streaming = false)
        } catch (e: ApiException) {
            val message = if (e.isUnauthorized) {
                "Your session expired. Sign in again to continue."
            } else {
                e.message ?: "Request failed"
            }
            if (buffer.isEmpty()) buffer.append(message)
            persist(streaming = false, failed = true)
            emit(StreamEvent(type = "error", error = message))
        } catch (e: Exception) {
            val message = e.message ?: "Unexpected error"
            if (buffer.isEmpty()) buffer.append(message)
            persist(streaming = false, failed = true)
            emit(StreamEvent(type = "error", error = message))
        }
    }

    private fun toUiMessage(entity: MessageEntity): UiMessage = UiMessage(
        id = entity.id,
        conversationId = entity.conversationId,
        role = entity.role,
        content = entity.content,
        createdAt = entity.createdAt,
        model = entity.model,
        citations = entity.citationsJson?.let {
            runCatching { FrebeeJson.decodeFromString(citationListSerializer, it) }.getOrNull()
        }?.map { Citation(it.index, it.title, it.url, it.snippet) } ?: emptyList(),
        attachments = entity.attachmentsJson?.let {
            runCatching { FrebeeJson.decodeFromString(attachmentListSerializer, it) }.getOrNull()
        }?.map { Attachment(it.id, it.name, it.mime, it.size, remoteId = it.id) } ?: emptyList(),
        toolTrace = entity.toolTraceJson?.let {
            runCatching { FrebeeJson.decodeFromString(toolListSerializer, it) }.getOrNull()
        }?.map { ToolTraceEntry(it.name, it.detail, it.ok) } ?: emptyList(),
        streaming = entity.streaming,
        error = entity.failed,
    )

    private fun ConversationDto.toEntity() = ConversationEntity(
        id = id,
        title = title.ifBlank { "New chat" },
        createdAt = createdAt,
        updatedAt = updatedAt,
        archived = archived,
        projectId = projectId,
        model = model,
        remote = true,
    )

    private fun MessageDto.toEntity() = MessageEntity(
        id = id,
        conversationId = conversationId,
        role = role,
        content = content,
        createdAt = createdAt,
        model = model,
        citationsJson = if (citations.isEmpty()) null else FrebeeJson.encodeToString(citationListSerializer, citations),
        attachmentsJson = if (attachments.isEmpty()) null else FrebeeJson.encodeToString(attachmentListSerializer, attachments),
        toolTraceJson = if (toolCalls.isEmpty()) null else FrebeeJson.encodeToString(toolListSerializer, toolCalls),
        failed = error,
    )
}

class MemoryRepository(
    private val dao: FrebeeDao,
    private val api: FrebeeApi,
) {

    fun observeLocal(): Flow<List<MemoryItem>> = dao.observeMemories().map { list -> list.map(::toItem) }

    suspend fun refresh(): List<MemoryItem> {
        val remote = api.memories()
        remote.forEach { dto ->
            dao.upsertMemory(
                MemoryEntity(
                    id = dto.id,
                    scope = dto.scope,
                    scopeId = dto.scopeId,
                    key = dto.key,
                    value = dto.value,
                    updatedAt = dto.updatedAt,
                    dirty = false,
                ),
            )
        }
        return remote.map { MemoryItem(it.id, it.scope, it.scopeId, it.key, it.value, it.updatedAt, false) }
    }

    suspend fun add(scope: String, scopeId: String?, key: String, value: String): MemoryItem {
        val dto = api.addMemory(com.frebee.ai.data.remote.MemoryRequest(scope, scopeId, key, value))
        val item = MemoryItem(dto.id, dto.scope, dto.scopeId, dto.key, dto.value, dto.updatedAt, false)
        dao.upsertMemory(MemoryEntity(dto.id, dto.scope, dto.scopeId, dto.key, dto.value, dto.updatedAt, false))
        return item
    }

    suspend fun update(id: String, key: String, value: String) {
        val dto: MemoryDto = api.updateMemory(id, key, value)
        dao.upsertMemory(MemoryEntity(dto.id, dto.scope, dto.scopeId, dto.key, dto.value, dto.updatedAt, false))
    }

    suspend fun delete(id: String) {
        api.deleteMemory(id)
        dao.deleteMemory(id)
    }

    suspend fun deleteAll() {
        api.deleteAllMemory()
        dao.deleteAllMemories()
    }

    private fun toItem(entity: MemoryEntity) = MemoryItem(
        id = entity.id,
        scope = entity.scope,
        scopeId = entity.scopeId,
        key = entity.key,
        value = entity.value,
        updatedAt = entity.updatedAt,
        dirty = entity.dirty,
    )
}

class ProjectRepository(
    private val dao: FrebeeDao,
    private val api: FrebeeApi,
) {
    fun observeLocal(): Flow<List<ProjectInfo>> = dao.observeProjects().map { list ->
        list.map { ProjectInfo(it.id, it.name, it.kind, it.createdAt, it.lastTask) }
    }

    suspend fun refresh() {
        api.projects().forEach { dto ->
            dao.upsertProject(ProjectEntity(dto.id, dto.name, dto.kind, dto.createdAt, dto.lastTask, true))
        }
    }

    suspend fun create(name: String, kind: String): ProjectInfo {
        val dto = api.createProject(name, kind)
        dao.upsertProject(ProjectEntity(dto.id, dto.name, dto.kind, dto.createdAt, dto.lastTask, true))
        return ProjectInfo(dto.id, dto.name, dto.kind, dto.createdAt, dto.lastTask)
    }

    suspend fun delete(id: String) {
        api.deleteProject(id)
        dao.deleteProject(id)
    }
}

/** Shared helper so the composer and the repository agree on mode labels. */
fun ChatMode.describe(): String = label
