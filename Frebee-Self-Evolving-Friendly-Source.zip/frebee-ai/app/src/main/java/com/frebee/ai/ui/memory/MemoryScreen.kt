package com.frebee.ai.ui.memory

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.frebee.ai.ui.AppViewModel
import com.frebee.ai.ui.common.InlineBanner
import com.frebee.ai.ui.common.ToggleRow
import com.frebee.ai.ui.theme.LocalFrebeePalette

@Composable
fun MemoryScreen(app: AppViewModel, onBack: () -> Unit) {
    val palette = LocalFrebeePalette.current
    val memories by app.memories.collectAsStateWithLifecycle()
    val settings by app.settings.collectAsStateWithLifecycle()
    val banner by app.banner.collectAsStateWithLifecycle()

    var showAdd by remember { mutableStateOf(false) }
    var showClear by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 4.dp, top = 8.dp, end = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = palette.onSurface)
            }
            Column(Modifier.weight(1f)) {
                Text("Memory", style = MaterialTheme.typography.titleLarge, color = palette.onSurface)
                Text(
                    "Preferences Frebee may use across chats",
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.onSurfaceMuted,
                )
            }
        }

        banner?.let { current ->
            Column(Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) {
                InlineBanner(text = current.text, isError = current.isError, onDismiss = { app.dismissBanner() })
            }
        }

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item("toggle") {
                Surface(color = palette.surface, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        ToggleRow(
                            title = "Persistent memory",
                            subtitle = "When off, Frebee answers without recalling saved items",
                            checked = settings.memoryEnabled,
                            onCheckedChange = { value -> app.updateSettings { it.copy(memoryEnabled = value) } },
                        )
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { showAdd = true }, shape = RoundedCornerShape(10.dp)) { Text("Add memory") }
                            OutlinedButton(onClick = { app.refreshMemories() }, shape = RoundedCornerShape(10.dp)) {
                                Text("Refresh")
                            }
                            OutlinedButton(onClick = { showClear = true }, shape = RoundedCornerShape(10.dp)) {
                                Text("Clear all")
                            }
                        }
                    }
                }
            }

            if (memories.isEmpty()) {
                item("empty") {
                    Text(
                        "Nothing saved yet. Memory entries are visible, editable and deletable — Frebee never stores hidden profile data.",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.onSurfaceMuted,
                    )
                }
            }

            items(memories, key = { it.id }) { memory ->
                Surface(color = palette.surface, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(memory.key, style = MaterialTheme.typography.bodyMedium, color = palette.onSurface)
                            Text(memory.value, style = MaterialTheme.typography.bodySmall, color = palette.onSurfaceMuted)
                            Text(memory.scope, style = MaterialTheme.typography.labelSmall, color = palette.accent)
                        }
                        IconButton(onClick = { app.deleteMemory(memory.id) }) {
                            Icon(
                                Icons.Default.Delete,
                                contentDescription = "Delete memory",
                                tint = palette.onSurfaceMuted,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        var key by remember { mutableStateOf("") }
        var value by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Add memory") },
            text = {
                Column {
                    OutlinedTextField(
                        value = key,
                        onValueChange = { key = it },
                        label = { Text("Label, e.g. Preferred language") },
                        singleLine = true,
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = value,
                        onValueChange = { value = it },
                        label = { Text("Value, e.g. Kotlin") },
                        maxLines = 3,
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    app.addMemory(key, value)
                    showAdd = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } },
        )
    }

    if (showClear) {
        AlertDialog(
            onDismissRequest = { showClear = false },
            title = { Text("Delete all memory?") },
            text = { Text("Every saved memory entry for your account is removed from the server and this device.") },
            confirmButton = {
                TextButton(onClick = {
                    app.clearMemory()
                    showClear = false
                }) { Text("Delete", color = palette.danger) }
            },
            dismissButton = { TextButton(onClick = { showClear = false }) { Text("Cancel") } },
        )
    }
}
