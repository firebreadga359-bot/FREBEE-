package com.frebee.ai.ui.chat

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.frebee.ai.AppContainer
import com.frebee.ai.data.remote.ApiException
import com.frebee.ai.domain.Attachment
import com.frebee.ai.domain.UiMessage
import com.frebee.ai.domain.UploadState
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(private val container: AppContainer) : ViewModel() {

    private val repo = container.chat

    private val _activeConversationId = MutableStateFlow<String?>(null)
    val activeConversationId: StateFlow<String?> = _activeConversationId.asStateFlow()

    private val _title = MutableStateFlow("New chat")
    val title: StateFlow<String> = _title.asStateFlow()

    val messages: StateFlow<List<UiMessage>> = _activeConversationId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repo.messages(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _streaming = MutableStateFlow(false)
    val streaming: StateFlow<Boolean> = _streaming.asStateFlow()

    private val _statusLine = MutableStateFlow<String?>(null)
    val statusLine: StateFlow<String?> = _statusLine.asStateFlow()

    private val _attachments = MutableStateFlow<List<Attachment>>(emptyList())
    val attachments: StateFlow<List<Attachment>> = _attachments.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _suggestions = MutableStateFlow(DEFAULT_SUGGESTIONS)
    val suggestions: StateFlow<List<String>> = _suggestions.asStateFlow()

    fun dismissError() {
        _error.value = null
    }

    fun newChat() {
        container.api.cancelStream()
        _streaming.value = false
        _statusLine.value = null
        _attachments.value = emptyList()
        _activeConversationId.value = null
        _title.value = "New chat"
    }

    fun select(conversationId: String, title: String) {
        if (_activeConversationId.value == conversationId) return
        container.api.cancelStream()
        _streaming.value = false
        _statusLine.value = null
        _attachments.value = emptyList()
        _activeConversationId.value = conversationId
        _title.value = title
        viewModelScope.launch {
            runCatching { repo.syncMessages(conversationId) }
        }
    }

    fun send(text: String) {
        val content = text.trim()
        if (content.isEmpty() || _streaming.value) return
        viewModelScope.launch {
            _streaming.value = true
            _error.value = null
            _statusLine.value = "Thinking…"
            try {
                val settings = container.settings.settings.first()
                val conversationId = _activeConversationId.value ?: repo.createConversation().also {
                    _activeConversationId.value = it
                    _title.value = content.lineSequence().firstOrNull()?.take(64) ?: "New chat"
                }
                val pending = _attachments.value.filter { it.remoteId != null }
                _attachments.value = emptyList()
                repo.sendMessage(conversationId, content, pending, settings).collect { event ->
                    when (event.type) {
                        "started" -> _statusLine.value = "Thinking…"
                        "delta" -> _statusLine.value = null
                        "citation" -> _statusLine.value = "Checking sources…"
                        "tool" -> _statusLine.value = event.tool?.let { "${it.name}…" }
                        "title" -> event.title?.let { _title.value = it }
                        "error" -> _error.value = event.error
                        "done" -> _statusLine.value = null
                        else -> Unit
                    }
                }
            } catch (e: ApiException) {
                _error.value = e.message ?: "Request failed"
            } catch (e: Exception) {
                _error.value = e.message ?: "Unexpected error"
            } finally {
                _streaming.value = false
                _statusLine.value = null
            }
        }
    }

    fun stop() {
        container.api.cancelStream()
        _streaming.value = false
        _statusLine.value = null
    }

    fun regenerate() {
        val conversationId = _activeConversationId.value ?: return
        if (_streaming.value) return
        viewModelScope.launch {
            val history = repo.messages(conversationId).first()
            val lastUser = history.lastOrNull { it.role == "user" } ?: return@launch
            val lastAssistant = history.lastOrNull { it.role == "assistant" }
            _streaming.value = true
            _statusLine.value = "Regenerating…"
            try {
                if (lastAssistant != null) {
                    runCatching { container.api.deleteMessage(conversationId, lastAssistant.id) }
                    container.dao.deleteMessage(lastAssistant.id)
                }
                val settings = container.settings.settings.first()
                repo.sendMessage(conversationId, lastUser.content, lastUser.attachments, settings, appendUserMessage = false)
                    .collect { event ->
                        if (event.type == "error") _error.value = event.error
                    }
            } catch (e: Exception) {
                _error.value = e.message ?: "Could not regenerate"
            } finally {
                _streaming.value = false
                _statusLine.value = null
            }
        }
    }

    fun editAndResend(message: UiMessage, newContent: String) {
        val conversationId = _activeConversationId.value ?: return
        viewModelScope.launch {
            runCatching { container.api.deleteMessage(conversationId, message.id) }
            container.dao.deleteMessage(message.id)
            send(newContent)
        }
    }

    fun attach(uri: Uri, displayName: String, mime: String, sizeBytes: Long) {
        val local = Attachment(
            id = UUID.randomUUID().toString(),
            name = displayName,
            mime = mime,
            sizeBytes = sizeBytes,
            localUri = uri.toString(),
            uploadState = UploadState.Uploading,
        )
        _attachments.value = _attachments.value + local
        viewModelScope.launch {
            try {
                val uploaded = container.api.uploadFile(uri, displayName, mime)
                _attachments.value = _attachments.value.map {
                    if (it.id == local.id) {
                        it.copy(remoteId = uploaded.id, uploadState = UploadState.Uploaded, name = uploaded.name, mime = uploaded.mime)
                    } else {
                        it
                    }
                }
            } catch (e: Exception) {
                _attachments.value = _attachments.value.map {
                    if (it.id == local.id) it.copy(uploadState = UploadState.Failed) else it
                }
                _error.value = e.message ?: "Upload failed"
            }
        }
    }

    fun removeAttachment(id: String) {
        _attachments.value = _attachments.value.filterNot { it.id == id }
    }

    fun rename(title: String) {
        val conversationId = _activeConversationId.value ?: return
        if (title.isBlank()) return
        viewModelScope.launch {
            runCatching { repo.rename(conversationId, title) }
                .onSuccess { _title.value = title }
                .onFailure { _error.value = it.message ?: "Rename failed" }
        }
    }

    fun archive() {
        val conversationId = _activeConversationId.value ?: return
        viewModelScope.launch {
            runCatching { repo.setArchived(conversationId, true) }
                .onSuccess { newChat() }
                .onFailure { _error.value = it.message ?: "Archive failed" }
        }
    }

    fun delete() {
        val conversationId = _activeConversationId.value ?: return
        viewModelScope.launch {
            runCatching { repo.delete(conversationId) }
                .onSuccess { newChat() }
                .onFailure { _error.value = it.message ?: "Delete failed" }
        }
    }

    fun clearAllLocal() {
        viewModelScope.launch { repo.deleteAllLocal() }
    }

    private companion object {
        val DEFAULT_SUGGESTIONS = listOf(
            "Explain this error and how to fix it",
            "Research the latest changes in a framework I use",
            "Build a small REST API with tests",
            "Summarise a PDF I attach",
        )
    }
}
