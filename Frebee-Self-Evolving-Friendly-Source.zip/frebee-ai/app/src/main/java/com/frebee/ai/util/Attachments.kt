package com.frebee.ai.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import java.io.File

data class PickedFile(val uri: Uri, val name: String, val mime: String, val size: Long)

/**
 * Attachment plumbing shared by the picker, the camera and drag-free file selection.
 * Content type is verified from the resolver rather than trusting the file extension.
 */
object Attachments {

    const val MAX_UPLOAD_BYTES = 25L * 1024 * 1024

    private val ALLOWED_PREFIXES = listOf(
        "image/",
        "text/",
        "audio/",
        "video/",
        "application/pdf",
        "application/json",
        "application/zip",
        "application/x-zip-compressed",
        "application/msword",
        "application/vnd.openxmlformats-officedocument",
        "application/vnd.oasis.opendocument",
        "application/octet-stream",
    )

    fun describe(context: Context, uri: Uri): PickedFile? {
        val resolver = context.contentResolver
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: "attachment"
        var size = -1L
        runCatching {
            resolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex >= 0) cursor.getString(nameIndex)?.let { name = it }
                    if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
                }
            }
        }
        val mime = resolver.getType(uri) ?: guessMime(name)
        if (!isSupportedMime(mime)) return null
        if (size > MAX_UPLOAD_BYTES) return null
        return PickedFile(uri, name, mime, size)
    }

    fun isSupportedMime(mime: String): Boolean =
        ALLOWED_PREFIXES.any { prefix -> mime.startsWith(prefix) }

    fun guessMime(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "gif" -> "image/gif"
        "pdf" -> "application/pdf"
        "json" -> "application/json"
        "md" -> "text/markdown"
        "txt", "log" -> "text/plain"
        "csv" -> "text/csv"
        "kt", "kts" -> "text/x-kotlin"
        "py" -> "text/x-python"
        "js", "mjs" -> "text/javascript"
        "ts", "tsx" -> "text/typescript"
        "html" -> "text/html"
        "css" -> "text/css"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "zip" -> "application/zip"
        else -> "application/octet-stream"
    }

    /** Creates the target Uri for ACTION_IMAGE_CAPTURE through the app FileProvider. */
    fun createCaptureUri(context: Context): Uri? {
        val dir = File(context.cacheDir, "captures").apply { mkdirs() }
        val file = File(dir, "capture-${System.currentTimeMillis()}.jpg")
        return runCatching {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }.getOrNull()
    }

    fun humanSize(bytes: Long): String = when {
        bytes < 0 -> ""
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        else -> String.format("%.1f MB", bytes / (1024.0 * 1024.0))
    }
}
