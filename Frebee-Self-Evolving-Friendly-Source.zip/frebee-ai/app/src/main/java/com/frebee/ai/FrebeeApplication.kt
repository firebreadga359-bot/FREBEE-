package com.frebee.ai

import android.app.Application
import android.content.Context
import androidx.room.Room
import com.frebee.ai.core.SecureStore
import com.frebee.ai.data.local.FrebeeDatabase
import com.frebee.ai.data.prefs.SettingsStore
import com.frebee.ai.data.remote.FrebeeApi
import com.frebee.ai.data.remote.SessionStore
import com.frebee.ai.data.repo.ChatRepository
import com.frebee.ai.data.repo.MemoryRepository
import com.frebee.ai.data.repo.ProjectRepository

class FrebeeApplication : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

/**
 * Manual dependency container. Keeping it explicit (instead of annotation processing
 * based injection) keeps cold start cheap on low-end devices and the wiring readable.
 */
class AppContainer(context: Context) {

    private val appContext = context.applicationContext

    val secureStore = SecureStore(appContext)
    val session = SessionStore(secureStore)
    val settings = SettingsStore(appContext)

    private val database: FrebeeDatabase = Room.databaseBuilder(
        appContext,
        FrebeeDatabase::class.java,
        FrebeeDatabase.NAME,
    ).fallbackToDestructiveMigration().build()

    val api = FrebeeApi(settings, session, appContext.contentResolver)

    val chat = ChatRepository(database.dao(), api)
    val memory = MemoryRepository(database.dao(), api)
    val projects = ProjectRepository(database.dao(), api)

    val dao = database.dao()
}
