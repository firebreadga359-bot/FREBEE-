package com.frebee.ai.ui.settings

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.frebee.ai.domain.ChatMode
import com.frebee.ai.domain.MessageDensity
import com.frebee.ai.domain.ThemeMode
import com.frebee.ai.domain.ThinkingEffort
import com.frebee.ai.domain.UiStyle
import com.frebee.ai.ui.AppViewModel
import com.frebee.ai.ui.common.ChoiceRow
import com.frebee.ai.ui.common.InlineBanner
import com.frebee.ai.ui.common.SectionHeader
import com.frebee.ai.ui.common.SettingRow
import com.frebee.ai.ui.common.ToggleRow
import com.frebee.ai.ui.theme.LocalFrebeePalette
import com.frebee.ai.ui.theme.paletteFor

private val ACCENTS = listOf(
    "Frebee blue" to 0xFF5B8CFF,
    "Violet" to 0xFF8B5CF6,
    "Teal" to 0xFF14B8A6,
    "Amber" to 0xFFF59E0B,
    "Rose" to 0xFFF43F5E,
    "Lime" to 0xFF84CC16,
)

@Composable
fun SettingsScreen(app: AppViewModel, onBack: () -> Unit) {
    val palette = LocalFrebeePalette.current
    val context = LocalContext.current
    val settings by app.settings.collectAsStateWithLifecycle()
    val models by app.models.collectAsStateWithLifecycle()
    val providers by app.providers.collectAsStateWithLifecycle()
    val apiKeys by app.apiKeys.collectAsStateWithLifecycle()
    val usage by app.usage.collectAsStateWithLifecycle()
    val sessions by app.sessions.collectAsStateWithLifecycle()
    val session by app.session.collectAsStateWithLifecycle()
    val banner by app.banner.collectAsStateWithLifecycle()
    val busy by app.busy.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current

    var serverUrl by remember(settings.backendUrl) { mutableStateOf(settings.backendUrl) }
    var providerKind by remember { mutableStateOf("openai") }
    var providerLabel by remember { mutableStateOf("") }
    var providerKey by remember { mutableStateOf("") }
    var providerBaseUrl by remember { mutableStateOf("") }
    var providerModel by remember { mutableStateOf("") }
    var newKeySecret by remember { mutableStateOf<String?>(null) }
    var showDeleteAccount by remember { mutableStateOf(false) }
    var deletePassword by remember { mutableStateOf("") }
    var pendingExport by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { app.loadDeveloperData() }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri ->
        val payload = pendingExport
        if (uri != null && payload != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { it.write(payload.toByteArray()) }
            }
        }
        pendingExport = null
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 4.dp, top = 8.dp, end = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = palette.onSurface)
            }
            Text("Settings", style = MaterialTheme.typography.titleLarge, color = palette.onSurface)
            Spacer(Modifier.weight(1f))
            if (busy) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
        }

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            banner?.let { current ->
                item("banner") {
                    InlineBanner(text = current.text, isError = current.isError, onDismiss = { app.dismissBanner() })
                }
            }

            // ------------------------------------------------------ appearance
            item("appearance") {
                SettingsCard("Appearance") {
                    SectionHeader("Theme")
                    ChoiceRow(
                        options = listOf("System", "Light", "Dark"),
                        selected = when (settings.themeMode) {
                            ThemeMode.System -> "System"
                            ThemeMode.Light -> "Light"
                            ThemeMode.Dark -> "Dark"
                        },
                        onSelect = { value ->
                            app.updateSettings {
                                it.copy(
                                    themeMode = when (value) {
                                        "Light" -> ThemeMode.Light
                                        "Dark" -> ThemeMode.Dark
                                        else -> ThemeMode.System
                                    },
                                )
                            }
                        },
                    )
                    Spacer(Modifier.height(12.dp))
                    SectionHeader("Interface style")
                    ChoiceRow(
                        options = listOf("Classic", "Futuristic"),
                        selected = if (settings.style == UiStyle.Classic) "Classic" else "Futuristic",
                        onSelect = { value ->
                            app.updateSettings { it.copy(style = if (value == "Classic") UiStyle.Classic else UiStyle.Futuristic) }
                        },
                    )
                    Spacer(Modifier.height(12.dp))
                    SectionHeader("Accent colour")
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ACCENTS.forEach { (name, value) ->
                            val selected = settings.accentArgb == value
                            Box(
                                Modifier
                                    .size(32.dp)
                                    .background(Color(value), CircleShape)
                                    .clickable { app.updateSettings { it.copy(accentArgb = value) } },
                                contentAlignment = Alignment.Center,
                            ) {
                                if (selected) {
                                    Icon(Icons.Default.Check, contentDescription = name, tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    SectionHeader("Font size", "${(settings.fontScale * 100).toInt()}%")
                    Slider(
                        value = settings.fontScale,
                        onValueChange = { value -> app.updateSettings { it.copy(fontScale = value) } },
                        valueRange = 0.85f..1.35f,
                        steps = 9,
                    )
                    SectionHeader("Message density")
                    ChoiceRow(
                        options = listOf("Comfortable", "Compact"),
                        selected = if (settings.density == MessageDensity.Compact) "Compact" else "Comfortable",
                        onSelect = { value ->
                            app.updateSettings {
                                it.copy(density = if (value == "Compact") MessageDensity.Compact else MessageDensity.Comfortable)
                            }
                        },
                    )
                    Spacer(Modifier.height(8.dp))
                    ToggleRow(
                        title = "Reduce motion",
                        subtitle = "Disables animated transitions and auto-scroll",
                        checked = settings.reduceMotion,
                        onCheckedChange = { value -> app.updateSettings { it.copy(reduceMotion = value) } },
                    )
                    Spacer(Modifier.height(8.dp))
                    ThemePreview(settings.style, settings.accentArgb)
                }
            }

            // ------------------------------------------------------ model setup
            item("model") {
                SettingsCard("Model & reasoning") {
                    SectionHeader("Default model")
                    ChoiceRow(
                        options = listOf("Auto", "Manual"),
                        selected = if (settings.modelId.isBlank()) "Auto" else "Manual",
                        onSelect = { value -> if (value == "Auto") app.updateSettings { it.copy(modelId = "") } },
                    )
                    if (models.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        models.take(8).forEach { model ->
                            SettingRow(
                                title = model.label,
                                subtitle = "${model.provider} · ${model.capabilities.joinToString(", ").ifBlank { "text" }}",
                                trailing = {
                                    if (settings.modelId == model.id) {
                                        Icon(Icons.Default.Check, contentDescription = "Selected", tint = palette.accent)
                                    }
                                },
                                onClick = { app.updateSettings { it.copy(modelId = model.id) } },
                            )
                        }
                    } else {
                        Text(
                            "No models listed yet. Add a provider key below, then run a connection test.",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.onSurfaceMuted,
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    SectionHeader("Thinking mode")
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        ChatMode.entries.forEach { mode ->
                            SettingRow(
                                title = mode.label,
                                subtitle = mode.hint,
                                trailing = {
                                    if (settings.mode == mode) {
                                        Icon(Icons.Default.Check, contentDescription = "Selected", tint = palette.accent)
                                    }
                                },
                                onClick = { app.updateSettings { it.copy(mode = mode) } },
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    SectionHeader("Reasoning effort")
                    ChoiceRow(
                        options = ThinkingEffort.entries.map { it.label },
                        selected = settings.effort.label,
                        onSelect = { label ->
                            app.updateSettings { it.copy(effort = ThinkingEffort.entries.first { it.label == label }) }
                        },
                    )
                    Spacer(Modifier.height(8.dp))
                    ToggleRow(
                        title = "Web research",
                        subtitle = "Allow Frebee to search the web and cite sources",
                        checked = settings.webSearch,
                        onCheckedChange = { value -> app.updateSettings { it.copy(webSearch = value) } },
                    )
                    ToggleRow(
                        title = "Speak replies aloud",
                        subtitle = "Uses the device text-to-speech engine",
                        checked = settings.speakReplies,
                        onCheckedChange = { value -> app.updateSettings { it.copy(speakReplies = value) } },
                    )
                }
            }

            // ------------------------------------------------------ connection
            item("connection") {
                SettingsCard("Backend connection") {
                    OutlinedTextField(
                        value = serverUrl,
                        onValueChange = { serverUrl = it },
                        label = { Text("Backend URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { app.updateSettings { it.copy(backendUrl = serverUrl.trim()) }; app.bootstrap() },
                            shape = RoundedCornerShape(10.dp),
                        ) { Text("Save & reconnect") }
                        OutlinedButton(
                            onClick = { app.refreshModels(); app.refreshProviders(); app.refreshConversations() },
                            shape = RoundedCornerShape(10.dp),
                        ) { Text("Test") }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Use http://10.0.2.2:8000 from the Android emulator, or your HTTPS deployment URL on a device.",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.onSurfaceMuted,
                    )
                }
            }

            // ------------------------------------------------------- providers
            item("providers") {
                SettingsCard("AI providers") {
                    if (providers.isEmpty()) {
                        Text(
                            "No provider credentials yet. Frebee never ships with a built-in key; add your own below.",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.onSurfaceMuted,
                        )
                    }
                    providers.forEach { provider ->
                        Column(Modifier.padding(vertical = 6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier.size(8.dp).background(
                                        when (provider.status) {
                                            "ok" -> palette.success
                                            "error" -> palette.danger
                                            else -> palette.onSurfaceMuted
                                        },
                                        CircleShape,
                                    ),
                                )
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        "${provider.label} (${provider.kind})",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = palette.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Text(
                                        provider.maskedKey ?: "no key",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = palette.onSurfaceMuted,
                                    )
                                    provider.error?.let {
                                        Text(it, style = MaterialTheme.typography.labelSmall, color = palette.danger)
                                    }
                                }
                            }
                            Row {
                                TextButton(onClick = { app.testProvider(provider.id) }) { Text("Test") }
                                TextButton(onClick = { app.makeProviderDefault(provider.id) }) {
                                    Text(if (provider.isDefault) "Default ✓" else "Make default")
                                }
                                TextButton(onClick = { app.removeProvider(provider.id) }) {
                                    Text("Remove", color = palette.danger)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    SectionHeader("Add a provider")
                    ChoiceRow(
                        options = listOf("OpenAI", "Anthropic", "Gemini"),
                        selected = when (providerKind) {
                            "anthropic" -> "Anthropic"
                            "gemini" -> "Gemini"
                            else -> "OpenAI"
                        },
                        onSelect = { value ->
                            providerKind = when (value) {
                                "Anthropic" -> "anthropic"
                                "Gemini" -> "gemini"
                                else -> "openai"
                            }
                        },
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { providerKind = "openai_compatible" },
                            shape = RoundedCornerShape(10.dp),
                        ) { Text("OpenAI-compatible / local") }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = providerLabel,
                        onValueChange = { providerLabel = it },
                        label = { Text("Label") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = providerKey,
                        onValueChange = { providerKey = it },
                        label = { Text("API key (stored encrypted on the server)") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = providerBaseUrl,
                        onValueChange = { providerBaseUrl = it },
                        label = { Text("Base URL (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = providerModel,
                        onValueChange = { providerModel = it },
                        label = { Text("Default model id (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = {
                            app.addProvider(providerKind, providerLabel.ifBlank { providerKind }, providerKey, providerBaseUrl, providerModel)
                            providerKey = ""
                            providerLabel = ""
                            providerBaseUrl = ""
                            providerModel = ""
                        },
                        enabled = providerKey.isNotBlank() || providerKind in setOf("openai_compatible"),
                        shape = RoundedCornerShape(10.dp),
                    ) { Text("Save provider") }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Keys are encrypted at rest with a server-side key and never returned to the app in plain text. Local runtimes such as Ollama need no key.",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.onSurfaceMuted,
                    )
                }
            }

            // ------------------------------------------------------- developer
            item("developer") {
                SettingsCard("Developer & API keys") {
                    SectionHeader("Frebee API keys", "For apps that call the Frebee backend")
                    if (apiKeys.isEmpty()) {
                        Text(
                            "No Frebee API keys yet.",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.onSurfaceMuted,
                        )
                    }
                    apiKeys.forEach { key ->
                        Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(key.label, style = MaterialTheme.typography.bodyMedium, color = palette.onSurface)
                                Text(
                                    "${key.masked} · ${key.scopes.joinToString(",")}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = palette.onSurfaceMuted,
                                )
                            }
                            TextButton(onClick = { app.revokeApiKey(key.id) }) {
                                Text("Revoke", color = palette.danger)
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Button(
                        onClick = { app.createApiKey("Frebee app key") { secret -> newKeySecret = secret } },
                        shape = RoundedCornerShape(10.dp),
                    ) { Text("Create API key") }
                    Spacer(Modifier.height(10.dp))
                    SectionHeader("Usage")
                    Text(
                        "${usage.requests} requests · ${usage.promptTokens} prompt tokens · ${usage.completionTokens} completion tokens · \$${String.format("%.4f", usage.estimatedCostUsd)} estimated",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.onSurfaceMuted,
                    )
                    Spacer(Modifier.height(10.dp))
                    SectionHeader("Active sessions")
                    sessions.forEach { item ->
                        Row(Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    item.userAgent?.take(38) ?: "Unknown device",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.onSurface,
                                )
                                Text(
                                    if (item.current) "This device" else "Session ${item.id.take(8)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = palette.onSurfaceMuted,
                                )
                            }
                            if (!item.current) {
                                TextButton(onClick = { app.revokeSession(item.id) }) { Text("Revoke") }
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    OutlinedButton(onClick = { app.revokeAllSessions() }, shape = RoundedCornerShape(10.dp)) {
                        Text("Sign out everywhere")
                    }
                }
            }

            // --------------------------------------------------------- privacy
            item("privacy") {
                SettingsCard("Privacy & account") {
                    ToggleRow(
                        title = "Persistent memory",
                        subtitle = "Let Frebee remember preferences you approve",
                        checked = settings.memoryEnabled,
                        onCheckedChange = { value -> app.updateSettings { it.copy(memoryEnabled = value) } },
                    )
                    SettingRow(
                        title = "Email",
                        subtitle = if (session.guest) "Guest session" else session.email.ifBlank { "Not signed in" },
                    )
                    SettingRow(
                        title = "Verification",
                        subtitle = when {
                            session.guest -> "Not available for guest sessions"
                            session.emailVerified -> "Verified"
                            else -> "Not verified — check your inbox"
                        },
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                app.exportData { payload ->
                                    pendingExport = payload
                                    exportLauncher.launch("frebee-export.json")
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                        ) { Text("Export my data") }
                        OutlinedButton(
                            onClick = { app.signOut() },
                            shape = RoundedCornerShape(10.dp),
                        ) { Text("Sign out") }
                    }
                    Spacer(Modifier.height(10.dp))
                    TextButton(onClick = { showDeleteAccount = true }) {
                        Text("Delete my account", color = palette.danger)
                    }
                    Text(
                        "Deleting the account removes conversations, files, memories and API keys. This cannot be undone.",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.onSurfaceMuted,
                    )
                }
            }

            // ----------------------------------------------------------- about
            item("about") {
                SettingsCard("About") {
                    SettingRow("Frebee AI", "Version 0.1.0 · Android")
                    SettingRow("Licence", "Source available in this repository")
                    SettingRow(
                        "Documentation",
                        "See docs/ in the repository for setup, API and security notes",
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = {
                            runCatching {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://github.com/firebreadga359-bot/frebee-android")),
                                )
                            }
                        }) { Text("Repository") }
                    }
                }
            }

            item("footer") {
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    newKeySecret?.let { secret ->
        AlertDialog(
            onDismissRequest = { newKeySecret = null },
            title = { Text("Copy your API key now") },
            text = {
                Column {
                    Text("This is the only time the full secret is shown.", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(10.dp))
                    Surface(color = palette.surfaceVariant, shape = RoundedCornerShape(8.dp)) {
                        Text(
                            secret,
                            modifier = Modifier.padding(10.dp),
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = com.frebee.ai.ui.theme.MonospaceFamily,
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    clipboard.setText(AnnotatedString(secret))
                    newKeySecret = null
                }) { Text("Copy") }
            },
            dismissButton = { TextButton(onClick = { newKeySecret = null }) { Text("Done") } },
        )
    }

    if (showDeleteAccount) {
        AlertDialog(
            onDismissRequest = { showDeleteAccount = false },
            title = { Text("Delete account") },
            text = {
                Column {
                    Text("Enter your password to confirm. This permanently deletes your data.")
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = deletePassword,
                        onValueChange = { deletePassword = it },
                        label = { Text("Password") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    app.deleteAccount(deletePassword)
                    deletePassword = ""
                    showDeleteAccount = false
                }) { Text("Delete", color = palette.danger) }
            },
            dismissButton = { TextButton(onClick = { showDeleteAccount = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    val palette = LocalFrebeePalette.current
    Surface(color = palette.surface, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = palette.onSurface)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun ThemePreview(style: UiStyle, accentArgb: Long) {
    val palette = paletteFor(style, dark = true, accentArgb = accentArgb)
    Column(
        Modifier
            .fillMaxWidth()
            .background(palette.background, RoundedCornerShape(14.dp))
            .padding(12.dp),
    ) {
        Text("Preview", style = MaterialTheme.typography.labelSmall, color = palette.onSurfaceMuted)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Text(
                "How does routing work?",
                modifier = Modifier
                    .background(palette.userBubble, RoundedCornerShape(12.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                style = MaterialTheme.typography.bodySmall,
                color = palette.userBubbleText,
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "Frebee picks a model that fits the task, then verifies the answer.",
            modifier = Modifier
                .background(palette.assistantBubble, RoundedCornerShape(12.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            style = MaterialTheme.typography.bodySmall,
            color = palette.onSurface,
        )
    }
}
