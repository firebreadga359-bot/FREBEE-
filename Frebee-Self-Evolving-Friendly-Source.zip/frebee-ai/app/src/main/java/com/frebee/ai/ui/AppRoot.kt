package com.frebee.ai.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModel
import com.frebee.ai.FrebeeApplication
import com.frebee.ai.domain.AppSettings
import com.frebee.ai.domain.ConversationSummary
import com.frebee.ai.domain.UiStyle
import com.frebee.ai.ui.auth.AuthScreen
import com.frebee.ai.ui.chat.ChatScreen
import com.frebee.ai.ui.chat.ChatViewModel
import com.frebee.ai.ui.common.BrandMark
import com.frebee.ai.ui.common.InlineBanner
import com.frebee.ai.ui.common.StatusDot
import com.frebee.ai.ui.memory.MemoryScreen
import com.frebee.ai.ui.settings.SettingsScreen
import com.frebee.ai.ui.theme.FrebeeTheme
import com.frebee.ai.ui.theme.LocalFrebeePalette
import com.frebee.ai.ui.workspace.WorkspaceScreen
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Destination { Chat, Settings, Workspace, Memory }

@Composable
fun FrebeeRoot(app: AppViewModel) {
    val settings by app.settings.collectAsStateWithLifecycle()
    val session by app.session.collectAsStateWithLifecycle()

    FrebeeTheme(settings) {
        when {
            session.loading -> SplashScreen()
            !session.signedIn -> AuthScreen(app)
            else -> SignedInShell(app, settings)
        }
    }
}

@Composable
private fun SplashScreen() {
    val palette = LocalFrebeePalette.current
    Box(
        Modifier.fillMaxSize().background(palette.background),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            BrandMark(size = 64.dp)
            Spacer(Modifier.height(14.dp))
            Text("Frebee", style = MaterialTheme.typography.headlineSmall, color = palette.onSurface)
            Spacer(Modifier.height(16.dp))
            CircularProgressIndicator(color = palette.accent, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun SignedInShell(app: AppViewModel, settings: AppSettings) {
    val container = (LocalContext.current.applicationContext as FrebeeApplication).container
    val chatVm: ChatViewModel = viewModel(factory = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = ChatViewModel(container) as T
    })

    var destination by remember { mutableStateOf(Destination.Chat) }
    var drawerOpen by remember { mutableStateOf(false) }
    val snackbarHost = remember { SnackbarHostState() }
    val banner by app.banner.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val palette = LocalFrebeePalette.current

    LaunchedEffect(banner) {
        banner?.let {
            scope.launch { snackbarHost.showSnackbar(it.text) }
            app.dismissBanner()
        }
    }

    BackHandler(enabled = drawerOpen || destination != Destination.Chat) {
        if (drawerOpen) drawerOpen = false else destination = Destination.Chat
    }

    val drawerState = androidx.compose.material3.rememberDrawerState(
        initialValue = androidx.compose.material3.DrawerValue.Closed,
    )
    LaunchedEffect(drawerOpen) {
        if (drawerOpen) drawerState.open() else drawerState.close()
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = destination == Destination.Chat,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = palette.surface) {
                DrawerContent(
                    app = app,
                    style = settings.style,
                    onNewChat = {
                        chatVm.newChat()
                        destination = Destination.Chat
                        drawerOpen = false
                    },
                    onOpenConversation = { conversation ->
                        chatVm.select(conversation.id, conversation.title)
                        destination = Destination.Chat
                        drawerOpen = false
                    },
                    onOpen = { target ->
                        destination = target
                        drawerOpen = false
                    },
                )
            }
        },
    ) {
        Scaffold(
            containerColor = palette.background,
            snackbarHost = { SnackbarHost(snackbarHost) },
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (destination) {
                    Destination.Chat -> ChatScreen(
                        app = app,
                        chatVm = chatVm,
                        onOpenDrawer = { drawerOpen = true },
                    )
                    Destination.Settings -> SettingsScreen(app = app, onBack = { destination = Destination.Chat })
                    Destination.Workspace -> WorkspaceScreen(app = app, onBack = { destination = Destination.Chat })
                    Destination.Memory -> MemoryScreen(app = app, onBack = { destination = Destination.Chat })
                }
            }
        }
    }
}

@Composable
private fun DrawerContent(
    app: AppViewModel,
    style: UiStyle,
    onNewChat: () -> Unit,
    onOpenConversation: (ConversationSummary) -> Unit,
    onOpen: (Destination) -> Unit,
) {
    val palette = LocalFrebeePalette.current
    val conversations by app.conversations.collectAsStateWithLifecycle()
    val projects by app.projects.collectAsStateWithLifecycle()
    val session by app.session.collectAsStateWithLifecycle()
    val backend by app.backendStatus.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    var renameTarget by remember { mutableStateOf<ConversationSummary?>(null) }
    var deleteTarget by remember { mutableStateOf<ConversationSummary?>(null) }

    val filtered = remember(conversations, query) {
        if (query.isBlank()) conversations
        else conversations.filter { it.title.contains(query, ignoreCase = true) || it.preview.contains(query, ignoreCase = true) }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 24.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BrandMark(size = 28.dp, style = style)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Frebee", style = MaterialTheme.typography.titleMedium, color = palette.onSurface)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusDot(
                        color = when (backend) {
                            BackendStatus.Online -> palette.success
                            BackendStatus.Offline -> palette.danger
                            BackendStatus.Unknown -> palette.onSurfaceMuted
                        },
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        when (backend) {
                            BackendStatus.Online -> "Connected"
                            BackendStatus.Offline -> "Offline"
                            BackendStatus.Unknown -> "Checking"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.onSurfaceMuted,
                    )
                }
            }
        }

        Button(
            onClick = onNewChat,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(12.dp),
        ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("New chat")
        }

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            placeholder = { Text("Search conversations") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
        )

        Spacer(Modifier.height(8.dp))

        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            item {
                Text(
                    "CHATS",
                    modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 4.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.onSurfaceMuted,
                )
            }
            if (filtered.isEmpty()) {
                item {
                    Text(
                        if (conversations.isEmpty()) "No conversations yet" else "No matches",
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.onSurfaceMuted,
                    )
                }
            }
            items(filtered, key = { it.id }) { conversation ->
                ConversationRow(
                    conversation = conversation,
                    onClick = { onOpenConversation(conversation) },
                    onRename = { renameTarget = conversation },
                    onDelete = { deleteTarget = conversation },
                )
            }
            if (projects.isNotEmpty()) {
                item {
                    Text(
                        "PROJECTS",
                        modifier = Modifier.padding(start = 20.dp, top = 14.dp, bottom = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.onSurfaceMuted,
                    )
                }
                items(projects, key = { it.id }) { project ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onOpen(Destination.Workspace) }
                            .padding(horizontal = 20.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Default.Build, contentDescription = null, tint = palette.onSurfaceMuted, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(project.name, style = MaterialTheme.typography.bodyMedium, color = palette.onSurface)
                    }
                }
            }
        }

        Box(Modifier.fillMaxWidth().height(1.dp).background(palette.outline))

        DrawerLink(Icons.Default.Psychology, "Memory") { onOpen(Destination.Memory) }
        DrawerLink(Icons.Default.Build, "Coding workspace") { onOpen(Destination.Workspace) }
        DrawerLink(Icons.Default.Settings, "Settings") { onOpen(Destination.Settings) }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(30.dp).background(palette.accent.copy(alpha = 0.16f), RoundedCornerShape(15.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    (session.name.ifBlank { "F" }).take(1).uppercase(),
                    style = MaterialTheme.typography.labelLarge,
                    color = palette.accent,
                )
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    session.name.ifBlank { "Signed in" },
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    if (session.guest) "Guest session" else session.email,
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.onSurfaceMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            IconButton(onClick = { app.signOut() }) {
                Icon(Icons.Default.Logout, contentDescription = "Sign out", tint = palette.onSurfaceMuted, modifier = Modifier.size(18.dp))
            }
        }
    }

    renameTarget?.let { target ->
        var value by remember(target.id) { mutableStateOf(target.title) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename conversation") },
            text = { OutlinedTextField(value = value, onValueChange = { value = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    app.renameConversation(target.id, value)
                    renameTarget = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Cancel") } },
        )
    }

    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete conversation?") },
            text = { Text("\"${target.title}\" and its messages will be removed from the server and this device.") },
            confirmButton = {
                TextButton(onClick = {
                    app.deleteConversation(target.id)
                    deleteTarget = null
                }) { Text("Delete", color = palette.danger) }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun DrawerLink(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
) {
    val palette = LocalFrebeePalette.current
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = palette.onSurfaceMuted, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = palette.onSurface)
    }
}

@Composable
private fun ConversationRow(
    conversation: ConversationSummary,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
) {
    val palette = LocalFrebeePalette.current
    var menuOpen by remember { mutableStateOf(false) }
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp).clickable { onClick() },
        color = Color.Transparent,
        shape = RoundedCornerShape(10.dp),
    ) {
        Row(Modifier.padding(start = 10.dp, end = 2.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    conversation.title.ifBlank { "New chat" },
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Row {
                    Text(
                        relativeTime(conversation.updatedAt),
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.onSurfaceMuted,
                    )
                    if (conversation.preview.isNotBlank()) {
                        Text(
                            " · " + conversation.preview.replace('\n', ' ').take(38),
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.onSurfaceMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
            Box {
                IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.MoreVert, contentDescription = "More", tint = palette.onSurfaceMuted, modifier = Modifier.size(16.dp))
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(text = { Text("Rename") }, onClick = { menuOpen = false; onRename() })
                    DropdownMenuItem(
                        text = { Text("Delete") },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null) },
                        onClick = { menuOpen = false; onDelete() },
                    )
                }
            }
        }
    }
}

private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
private val dateFormat = SimpleDateFormat("d MMM", Locale.getDefault())

fun relativeTime(epochMillis: Long): String {
    if (epochMillis <= 0) return ""
    val now = System.currentTimeMillis()
    val diff = now - epochMillis
    return when {
        diff < 60_000 -> "now"
        diff < 3_600_000 -> "${diff / 60_000}m"
        diff < 86_400_000 -> timeFormat.format(Date(epochMillis))
        diff < 7 * 86_400_000L -> "${diff / 86_400_000}d"
        else -> dateFormat.format(Date(epochMillis))
    }
}
