package com.frebee.ai

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.frebee.ai.ui.AppViewModel
import com.frebee.ai.ui.FrebeeRoot

class MainActivity : ComponentActivity() {

    private val appViewModel: AppViewModel by viewModels {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                AppViewModel((application as FrebeeApplication).container) as T
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleDeepLink(intent)
        setContent { FrebeeRoot(appViewModel) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleDeepLink(intent)
    }

    private fun handleDeepLink(intent: Intent?) {
        val data = intent?.data ?: return
        if (data.scheme == "frebee" && data.host == "verify") {
            data.getQueryParameter("token")?.let { appViewModel.verifyEmail(it) }
        }
        if (data.scheme == "frebee" && data.host == "reset") {
            data.getQueryParameter("token")?.let { /* surfaced in the reset dialog */ }
        }
    }
}
