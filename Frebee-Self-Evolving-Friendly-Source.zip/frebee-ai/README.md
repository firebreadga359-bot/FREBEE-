# Frebee AI

**Research, reason, build.** An Android app, a web dashboard and a Python backend that
together form a working AI assistant: streaming chat, web research with citations,
file and image understanding, voice, persistent memory, a knowledge workspace, a
sandboxed coding agent and a project builder.

This repository contains three parts:

| Part | Path | Stack |
| --- | --- | --- |
| Android app | `app/` | Kotlin, Jetpack Compose, Room, DataStore, OkHttp |
| Backend API | `backend/` | FastAPI, SQLAlchemy, httpx, cryptography |
| Web dashboard | `backend/app/web/` | Static HTML/CSS/JS served by the backend |

## Run it free, with no API key

The backend can generate answers itself, from an open-weights model loaded in the
process, and it can search the web through public APIs that need no key. Both are
off by default for paid deployments, so enable them explicitly:

```bash
# 1. optional: the runtime that loads GGUF models
pip install -r backend/requirements-local.txt
#    CPU-only wheels:
pip install --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu llama-cpp-python

# 2. fetch an instruct model (2.1 GB, runs on 4 CPU cores at ~12 tok/s)
mkdir -p models && curl -L -o models/qwen2.5-3b-instruct-q4_k_m.gguf \
  https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/main/qwen2.5-3b-instruct-q4_k_m.gguf

# 3. run the backend against it
FREBEE_LOCAL_MODEL_PATH=$PWD/models/qwen2.5-3b-instruct-q4_k_m.gguf \
FREBEE_LOCAL_MODEL_THREADS=4 \
FREBEE_LOCAL_MODEL_CONTEXT=4096 \
FREBEE_DEFAULT_PROVIDER=local_gguf \
FREEBEE_ALLOW_KEYLESS_SEARCH=true \
  python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

`GET /health` then reports `"local_model": true` and the dashboard shows the model
name in the header. Any GGUF file works: larger models answer better and slower.

**Speed and model choice.** On a 4-core CPU box the 3B model reads the prompt at
~60 tokens/s and answers at 5-14 tokens/s, so a long reply takes 40-80 s;
Qwen2.5-1.5B is roughly twice as fast with noticeably weaker multi-step edits. The
default is whatever `FREBEE_LOCAL_MODEL_PATH` points at, every other `*.gguf` in that
folder appears in the model picker with its size, and the heavy modes (coding, deep,
research, council, autonomous) automatically take the largest installed model while
quick and balanced chat stay on the default. On this hardware a chat reply lands in
10-30 s; a GPU-backed or hosted provider removes the trade-off entirely.

The orchestrator keeps the prompt small on purpose: retrieved pages and search
results ride on the final user turn so the system prompt and history stay a stable
prefix (llama.cpp reuses its KV cache between turns instead of re-reading the whole
conversation), the prompt is measured with the model's own tokenizer before it is
sent, local history is capped at about 4 000 characters with a one-line recap of the
requests that fell out of the window, and follow-up instructions ("do it again", "now
add a header") skip web research because the answer is in the conversation, not on
the web.

Keyless research queries DuckDuckGo's HTML endpoint where the host can reach it,
plus Wikipedia, Stack Exchange, arXiv and Crossref, and cites whatever it actually
fetched. Those endpoints are rate limited and may refuse traffic; set
`FREBEE_TAVILY_API_KEY`, `FREEBEE_SEARXNG_URL` or `FREEBEE_BRAVE_API_KEY` for a
supported search contract.

Neither path changes model weights. Frebee learns about *your* material through the
knowledge workspace, the memory store and a shared cache of fetched public pages —
not by retraining the model. Model quality is upgraded by pointing Frebee at a
better model, not by claiming the old weights improved.

## How answers get better over time

Four mechanisms, all inspection-friendly:

| Mechanism | What it does | Where it lives |
| --- | --- | --- |
| Explicit memory | Sentences such as "my name is Asha", "I prefer short answers", "I'm building TripKit" are stored as user memory and injected into later prompts. Deterministic extraction, no model guessing, user can edit or delete every row. | `services/orchestrator.capture_memory`, `PUT /v1/memory` |
| Research-then-answer | Questions about changing facts (latest, version, price, "who is", a year) trigger a search; if the model answers that it cannot know, Frebee searches and rewrites the answer with dated sources and `[n]` citations. | `services/research.py`, `should_research`, `looks_uncertain` |
| Shared page cache | Fetched public pages are stored once and become retrievable for every user. Public web text only — no queries, no user ids, no files. Disable with `FREBEE_SHARED_WEB_CACHE=false`. | `retrieval.cache_web_pages`, `web_pages` table |
| Council mode | A second pass — a different configured provider when one exists, otherwise a fresh pass of the same model — reviews the draft and answers `KEEP` when it has nothing to fix. A revision replaces the draft only when it is a real rewrite, not an echo or a truncation, and the swap is announced with a `reset` event. | `services/orchestrator.stream_reply` |

Turning a second AI provider on (any OpenAI-compatible endpoint) is what makes
council mode a genuine cross-model review instead of a same-model second pass.

## What works today

| Area | State |
| --- | --- |
| Streaming chat (SSE) with markdown, code blocks, copy, regenerate | Implemented and tested |
| Seven thinking modes (quick, balanced, deep, research, council, coding, autonomous) | Implemented and tested; modes change orchestration and prompting, not the model itself |
| Multi-provider adapters: OpenAI-compatible, Anthropic, Gemini, local endpoints | Implemented and tested against the provider protocol (live calls need your key) |
| In-process open-weights model (GGUF via llama.cpp) | Implemented and verified: Qwen2.5-3B-Instruct answers with streaming, no key or network needed |
| Automatic research on changing facts, with inline `[n]` citations | Implemented and verified live (e.g. "newest Python release" answered from python.org sources) |
| Memory capture from ordinary sentences, editable per row | Implemented and tested |
| Shared public-page cache across users | Implemented and tested (9 pages cached from live research) |
| Accounts: register, login, refresh rotation, logout, guest mode | Implemented and tested |
| Email verification, password reset, session list/revoke, data export, account deletion | Implemented and tested (email delivery needs SMTP) |
| Conversations, messages, search, rename, archive, delete | Implemented and tested |
| Memory: user, project and conversation scopes, editable and deletable | Implemented and tested |
| File uploads: text, code, PDF, DOCX, images, audio | Implemented and tested for text and size limits |
| "+" attach menu: camera, photos, files, with upload progress and removable chips | Implemented; verified in the browser (camera capture needs a device with a camera) |
| Image text extraction with tesseract OCR | Implemented and tested; feeds the extracted text to any model, vision-capable or not |
| Vision input to vision-capable models | Implemented; requires a vision model |
| Multi-turn continuity: earlier turns stay in the prompt, follow-ups build on them | Implemented and verified (turn 2 edits turn 1's code, keeping its names) |
| Web research with citations | Implemented; works with no key via Wikipedia, Stack Exchange, arXiv and Crossref (Tavily, Brave or SearXNG optional) |
| Knowledge workspace with hybrid retrieval and RAG | Implemented and tested |
| Voice: speech-to-text and text-to-speech | Implemented; needs an OpenAI key |
| Realtime voice sessions | Not implemented (backend reports `realtime: false`) |
| Coding agent: read, write, run commands in a sandbox, report steps | Implemented and tested with the mock provider |
| Project builder: scaffolds web/API/Python/Android projects, zip download | Implemented and tested |
| Provider keys stored encrypted, masked on read | Implemented and tested |
| Frebee API keys: hashed, scoped, revocable, usage counted | Implemented and tested |
| Evaluations: citation format, retrieval, sandbox guards, prompt injection | Implemented and tested |
| Admin dashboard API: health, metrics, audit, feature flags | Implemented; requires `role=admin` |
| Automatic self-modifying code changes | Not implemented (deliberately out of scope) |
| Google sign-in, passkeys | Not implemented |

Anything marked "needs a key" fails with a clear message rather than pretending to work.

## Quick start (backend + web dashboard)

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env          # then edit the two secrets
python -m uvicorn app.main:app --reload --port 8000
```

Open <http://localhost:8000> for the dashboard, <http://localhost:8000/api/docs> for
the interactive API reference, and <http://localhost:8000/health> for a health check.

Without any provider key the backend starts, accounts work, and chat returns a clear
"no provider configured" error. Add a key in Settings, or set `FREBEE_OPENAI_API_KEY`
(or Anthropic/Gemini) on the server.

## Quick start (Android)

```bash
./gradlew :app:assembleDebug        # APK at app/build/outputs/apk/debug/app-debug.apk
./gradlew :app:testDebugUnitTest    # unit tests
```

The app defaults to `http://10.0.2.2:8000` (the host machine from an emulator). Change
it on the sign-in screen ("Server") or in Settings. For a physical device use your
machine's LAN address, and serve the backend over HTTPS in any real deployment.

## Tests

```bash
cd backend && python -m pytest -q          # 35 backend tests
./gradlew :app:testDebugUnitTest           # Android unit tests
```

A debug APK built in this environment is committed at `dist/frebee-0.1.0-debug.apk`
(19 MB, `com.frebee.ai` 0.1.0, minSdk 26, targetSdk 35). A running backend serves it at
`/download/frebee-debug.apk`. CI builds a fresh one on every push; see
`docs/BUILD_REPORT.md`.

## Documentation

- [docs/API.md](docs/API.md) — endpoints, payloads, streaming format
- [docs/SECURITY.md](docs/SECURITY.md) — threat model, secrets, limits
- [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) — free-first hosting, TLS, backups
- [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) — common failures
- [docs/BUILD_REPORT.md](docs/BUILD_REPORT.md) — what was built, tested and verified
- [backend/.env.example](backend/.env.example) — every configuration value

## Layout

```
app/src/main/java/com/frebee/ai/
  data/      remote API client, DTOs, session store, Room cache, preferences
  domain/    models, modes, theme options
  ui/        chat, auth, settings, memory, workspace screens and view models
  voice/     speech recognition and playback
  core/      encrypted local storage
backend/app/
  api/       auth, chat, workspace, knowledge, settings routers
  services/  orchestrator, retrieval, research, sandbox, coding agent, builder, evals
  providers/ openai-compatible, anthropic, gemini, mock adapters + registry
  web/       dashboard
```

## Licence and brand

Frebee is original work. No third-party brand assets are used.

## Conversation style

Frebee's assistant instructions are designed to be warm, casual, patient, and context-aware.
They encourage natural emoji use when it fits the user's tone, playful responses to harmless
jokes, empathetic responses to frustration, and a calmer style for serious topics. Emojis are
not forced into every answer or into code. The actual response quality still depends on the
selected AI provider/model and the backend being configured correctly.

## Self-evolution (experimental foundation)

The backend includes `backend/app/services/evolution.py`, a conservative lifecycle for proposing major model upgrades. It records only high-confidence evidence, deduplicates repeated evidence from the same source, opens a proposal after a configurable evidence threshold, records benchmark outcomes, and requires explicit approval before changing the active version marker. Failed candidates are rejected and the previous version is recorded for rollback planning.

**Important limitation:** this is the upgrade-governance foundation, not an autonomous neural-network trainer. Saving memories or facts does not change model weights. To actually create a new model, a deployment still needs a compatible training/fine-tuning pipeline, permitted and privacy-reviewed training data, suitable compute/storage, benchmark datasets, and model artifact loading/rollback integration. The current app does not train a new model by itself, and this module does not automatically replace the model used for chat.
