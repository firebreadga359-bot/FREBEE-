package com.frebee.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FrebeeApp() }
    }
}

private data class ChatMessage(val role: String, val text: String)

@Composable
private fun FrebeeApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("frebee_settings", 0) }
    var futuristic by remember { mutableStateOf(prefs.getBoolean("futuristic", false)) }
    var roast by remember { mutableFloatStateOf(prefs.getFloat("roast", 25f)) }
    var provider by remember { mutableStateOf("Demo mode") }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini") }
    var apiKey by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Hey! I'm Frebee 😄 Connect a model or try demo mode.") }
    var speakReplies by remember { mutableStateOf(prefs.getBoolean("speak_replies", true)) }
    var speechRate by remember { mutableFloatStateOf(prefs.getFloat("speech_rate", 1f)) }
    var voiceNames by remember { mutableStateOf(emptyList<String>()) }
    var selectedVoice by remember { mutableStateOf(prefs.getString("voice", "") ?: "") }
    var showVoiceMenu by remember { mutableStateOf(false) }
    val messages = remember {
        mutableStateListOf<ChatMessage>().apply {
            add(ChatMessage("assistant", "Hey! I'm Frebee ✨ What's on your mind?"))
        }
    }
    val scope = rememberCoroutineScope()
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsReady by remember { mutableStateOf(false) }

    val bg = if (futuristic) Color(0xFF080D1A) else Color(0xFFF5F6FB)
    val panel = if (futuristic) Color(0xFF121B30) else Color.White
    val ink = if (futuristic) Color(0xFFEAF1FF) else Color(0xFF172033)
    val accent = if (futuristic) Color(0xFF54E5FF) else Color(0xFF635BFF)

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            prompt = listOf(prompt.trim(), spoken.trim()).filter { it.isNotBlank() }.joinToString(" ")
            status = "Got it 🎙️ Check the text, then tap send."
        } else status = "I didn't catch that — try again when you're ready."
    }
    val startVoiceInput = {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Frebee")
        }
        try { speechLauncher.launch(intent) }
        catch (_: Exception) { status = "Voice recognition isn't available on this device." }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startVoiceInput() else status = "Microphone permission is needed for voice input."
    }

    DisposableEffect(context) {
        val engine = TextToSpeech(context) { result ->
            ttsReady = result == TextToSpeech.SUCCESS
        }
        tts = engine
        engine.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {}
            override fun onError(utteranceId: String?) { }
        })
        onDispose {
            engine.stop()
            engine.shutdown()
            tts = null
            ttsReady = false
        }
    }
    LaunchedEffect(tts, ttsReady) {
        if (!ttsReady) return@LaunchedEffect
        val engine = tts ?: return@LaunchedEffect
        engine.language = Locale.getDefault()
        voiceNames = engine.voices?.filter { it.locale.language == "en" }?.map { it.name }?.distinct()?.sorted().orEmpty()
        if (selectedVoice.isNotBlank()) engine.voices?.firstOrNull { it.name == selectedVoice }?.let { engine.voice = it }
        engine.setSpeechRate(speechRate)
    }
    LaunchedEffect(speechRate, selectedVoice) {
        tts?.setSpeechRate(speechRate)
        if (selectedVoice.isNotBlank()) tts?.voices?.firstOrNull { it.name == selectedVoice }?.let { tts?.voice = it }
    }

    MaterialTheme(colorScheme = if (futuristic) darkColorScheme(primary = accent, background = bg, surface = panel, onSurface = ink, onBackground = ink)
    else lightColorScheme(primary = accent, background = bg, surface = panel, onSurface = ink, onBackground = ink)) {
        Scaffold(containerColor = bg, topBar = {
            Row(
                Modifier.fillMaxWidth().background(panel).padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(42.dp).background(accent, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.AutoAwesome, null, tint = if (futuristic) Color.Black else Color.White)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Frebee", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = ink)
                    Text(if (provider == "Demo mode") "Your AI workspace · Demo" else "Cloud · $model", fontSize = 11.sp, color = ink.copy(alpha = .65f))
                }
                IconButton(onClick = {
                    futuristic = !futuristic
                    prefs.edit().putBoolean("futuristic", futuristic).apply()
                }) { Icon(if (futuristic) Icons.Default.LightMode else Icons.Default.Bolt, "Switch theme", tint = accent) }
                IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Tune, "Settings", tint = ink) }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp)) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(onClick = { provider = "Demo mode"; status = "Demo mode: no API key required" }, label = { Text("Demo") }, leadingIcon = { Icon(Icons.Default.Chat, null) })
                    AssistChip(onClick = { provider = "Cloud API"; showSettings = true }, label = { Text("Cloud API") }, leadingIcon = { Icon(Icons.Default.Cloud, null) })
                }
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Mood Studio", fontWeight = FontWeight.SemiBold, color = ink, modifier = Modifier.weight(1f))
                            Text("${roast.toInt()}% playful", color = accent, fontSize = 12.sp)
                        }
                        Slider(value = roast, onValueChange = { roast = it; prefs.edit().putFloat("roast", it).apply() }, valueRange = 0f..100f)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Gentle", color = ink.copy(alpha = .7f), fontSize = 11.sp)
                            Text("Playful", color = ink.copy(alpha = .7f), fontSize = 11.sp)
                            Text("Roasty", color = ink.copy(alpha = .7f), fontSize = 11.sp)
                        }
                    }
                }
                Text(status, fontSize = 11.sp, color = ink.copy(alpha = .7f), modifier = Modifier.padding(start = 4.dp, top = 6.dp))
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    itemsIndexed(messages) { _, msg ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.role == "user") Arrangement.End else Arrangement.Start) {
                            Surface(color = if (msg.role == "user") accent else panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.widthIn(max = 320.dp)) {
                                Text(msg.text, Modifier.padding(13.dp), color = if (msg.role == "user") Color.White else ink, fontSize = 14.sp)
                            }
                        }
                    }
                    if (busy) item { Text("Frebee is thinking… 💭", color = accent, modifier = Modifier.padding(8.dp)) }
                }
                Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(bottom = 10.dp)) {
                    OutlinedTextField(value = prompt, onValueChange = { prompt = it }, modifier = Modifier.weight(1f),
                        placeholder = { Text("Message Frebee…") }, maxLines = 5, shape = RoundedCornerShape(22.dp))
                    Spacer(Modifier.width(4.dp))
                    IconButton(onClick = {
                        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVoiceInput()
                        else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }) { Icon(Icons.Default.Mic, "Speak to Frebee", tint = accent) }
                    FilledIconButton(enabled = prompt.isNotBlank() && !busy, onClick = {
                        val text = prompt.trim()
                        prompt = ""
                        messages.add(ChatMessage("user", text))
                        busy = true
                        scope.launch {
                            val answer = if (provider == "Cloud API") withContext(Dispatchers.IO) { callCloud(endpoint, model, apiKey, messages.toList(), roast) }
                                else demoReply(text, roast)
                            messages.add(ChatMessage("assistant", answer))
                            status = if (answer.startsWith("Connection error:")) answer.take(100) else "Ready ✨"
                            if (speakReplies && !answer.startsWith("Connection error:")) tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "frebee_reply")
                            busy = false
                        }
                    }, modifier = Modifier.size(52.dp)) { Icon(Icons.Default.Send, "Send") }
                }
            }
        }
        if (showSettings) {
            AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("Frebee settings") }, text = {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.heightIn(max = 520.dp)) {
                    Text("Cloud model", fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(endpoint, { endpoint = it }, label = { Text("Chat Completions endpoint") }, singleLine = true)
                    OutlinedTextField(model, { model = it }, label = { Text("Model ID") }, singleLine = true)
                    OutlinedTextField(apiKey, { apiKey = it }, label = { Text("API key (session only)") }, singleLine = true)
                    Divider()
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Speak replies", fontWeight = FontWeight.SemiBold)
                            Text("Uses your Android speech engine", fontSize = 11.sp)
                        }
                        Switch(speakReplies, {
                            speakReplies = it
                            prefs.edit().putBoolean("speak_replies", it).apply()
                        })
                    }
                    Text("Voice", fontWeight = FontWeight.SemiBold)
                    Box {
                        TextButton(onClick = { showVoiceMenu = true }) {
                            Text(if (selectedVoice.isBlank()) "System default" else selectedVoice)
                            Icon(Icons.Default.ArrowDropDown, null)
                        }
                        DropdownMenu(expanded = showVoiceMenu, onDismissRequest = { showVoiceMenu = false }) {
                            DropdownMenuItem(text = { Text("System default") }, onClick = {
                                selectedVoice = ""
                                prefs.edit().remove("voice").apply()
                                showVoiceMenu = false
                            })
                            voiceNames.forEach { voice ->
                                DropdownMenuItem(text = { Text(voice) }, onClick = {
                                    selectedVoice = voice
                                    prefs.edit().putString("voice", voice).apply()
                                    showVoiceMenu = false
                                })
                            }
                        }
                    }
                    Text("Speech speed: ${String.format(Locale.US, "%.2fx", speechRate)}", fontSize = 12.sp)
                    Slider(speechRate, { speechRate = it; prefs.edit().putFloat("speech_rate", it).apply() }, valueRange = .75f..1.25f)
                    Text("Voice input uses Android's speech-recognition service. This is not continuous, low-latency live audio like ChatGPT Voice.", fontSize = 11.sp)
                    Text("Keep API keys private. This starter keeps the key in memory only; a production app should use a secure backend.", fontSize = 11.sp)
                }
            }, confirmButton = {
                TextButton(onClick = {
                    prefs.edit().putString("endpoint", endpoint).putString("model", model).apply()
                    provider = "Cloud API"
                    status = if (apiKey.isBlank()) "Cloud selected — enter an API key" else "Cloud configured for $model"
                    showSettings = false
                }) { Text("Save") }
            }, dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } })
        }
    }
}


private fun demoReply(text: String, roast: Float): String {
    val intro = when {
        roast < 20 -> "Of course — I'm here to help. "
        roast < 55 -> "Alright, let's figure this out 😄 "
        roast < 80 -> "Okay, chaos coordinator 😂 "
        else -> "Playful roast mode activated 🔥 "
    }
    return intro + "I'm in demo mode, so a real AI model isn't connected yet. Connect a compatible model in Settings to get real AI answers."
}

private fun callCloud(endpoint: String, model: String, key: String, messages: List<ChatMessage>, roast: Float): String {
    if (key.isBlank()) return "Connection error: add an API key in Settings. Keep it private."
    return try {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection)
        connection.requestMethod = "POST"
        connection.connectTimeout = 15000
        connection.readTimeout = 60000
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json")
        connection.setRequestProperty("Authorization", "Bearer $key")
        val mood = when {
            roast < 20 -> "Be kind, patient, and supportive."
            roast < 55 -> "Be warm, conversational, and lightly humorous."
            roast < 80 -> "Use playful wit, never slurs or personal degradation."
            else -> "Use bold but harmless comedy; never use slurs, threats, or degrading abuse."
        }
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content",
            "You are Frebee, a warm, friendly, emotionally aware conversational assistant. Match the user's language, tone, and detail level. Use emojis naturally when they fit, especially if the user uses them, but don't force them. Be patient and encouraging; acknowledge frustration; explain things simply when needed. Never pretend you performed actions you did not perform. $mood"))
        messages.takeLast(24).forEach { arr.put(JSONObject().put("role", it.role).put("content", it.text)) }
        val body = JSONObject().put("model", model).put("messages", arr).put("temperature", 0.7).toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        connection.disconnect()
        if (code !in 200..299) "Connection error: HTTP $code — ${response.take(300)}"
        else JSONObject(response).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
            ?: "The provider returned an unexpected response format."
    } catch (e: Exception) {
        "Connection error: ${e.message ?: "Unknown network error"}"
    }
}
