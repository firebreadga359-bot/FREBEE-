# Frebee Android — voice and conversation upgrade

This source bundle restructures the starter into a standard Android Gradle project.

## Included
- Compose chat interface with light/futuristic themes and a playful mood slider.
- Android speech-recognition intent for tap-to-dictate.
- Android TextToSpeech replies, voice selection where the device exposes voices, and speech-rate controls.
- Friendly conversational system prompt for compatible Chat Completions APIs.
- Session-only API key handling and settings persisted without storing the key.
- GitHub Actions workflow that builds `:app:assembleDebug` and uploads the APK artifact.

## Honest limitations
- This is not continuous real-time duplex voice. Android recognition is turn-based and TTS is device-generated.
- Demo mode is not a language model.
- A compatible cloud API and valid API key are required for real model responses.
- No autonomous neural-network training, full image/file understanding, account sync, or plugin framework is implemented in this starter.
- The project has not been compiled or device-tested in this environment. CI is intended to validate the Android build.

## Build
Run `gradle :app:assembleDebug` with Java 17 and Android SDK platform/build tools 35 installed.
